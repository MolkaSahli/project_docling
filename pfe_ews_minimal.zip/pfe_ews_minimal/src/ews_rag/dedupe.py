from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable
from typing import Any

from rapidfuzz.fuzz import token_set_ratio

from ews_rag.schemas import (
    OFFICIAL_STATUS_CATEGORIES,
    DatePrecision,
    EventCategory,
    Evidence,
    Severity,
    TimelineEvent,
)


DATE_PRECISION_RANK = {
    DatePrecision.UNKNOWN: 0,
    DatePrecision.PERIOD: 1,
    DatePrecision.YEAR: 2,
    DatePrecision.QUARTER: 3,
    DatePrecision.MONTH: 4,
    DatePrecision.EXACT_DAY: 5,
}

SEVERITY_RANK = {
    Severity.UNKNOWN: 0,
    Severity.LOW: 1,
    Severity.MEDIUM: 2,
    Severity.HIGH: 3,
}


def _normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(char for char in text if not unicodedata.combining(char))
    text = re.sub(r"[^a-z0-9%]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _quote_is_grounded(quote: str, chunk_text: str) -> bool:
    """Tolere seulement les differences d espaces et de diacritiques."""
    normalized_quote = _normalize(quote)
    normalized_chunk = _normalize(chunk_text)
    return bool(normalized_quote) and normalized_quote in normalized_chunk


def _dates_compatible(left: str | None, right: str | None) -> bool:
    if left is None or right is None:
        return True
    if left == right:
        return True
    return left.startswith(right) or right.startswith(left)


def sanitize_event(
    event: TimelineEvent,
    *,
    chunks_by_id: dict[str, dict[str, Any]],
) -> TimelineEvent | None:
    valid_evidence: list[Evidence] = []
    seen: set[tuple[str, str]] = set()

    for evidence in event.evidence:
        chunk = chunks_by_id.get(evidence.source_chunk_id)
        quote = evidence.quote.strip()
        if chunk is None or not quote:
            continue
        if not _quote_is_grounded(quote, str(chunk.get("text", ""))):
            continue
        key = (evidence.source_chunk_id, _normalize(quote))
        if key in seen:
            continue
        seen.add(key)
        valid_evidence.append(
            Evidence(
                source_chunk_id=evidence.source_chunk_id,
                source_file=chunk["source_file"],
                page_numbers=list(chunk.get("page_numbers", [])),
                quote=quote,
            )
        )

    # Une sortie sans preuve citable n'est pas exploitable dans ce prototype.
    if not valid_evidence:
        return None

    updates: dict[str, Any] = {"evidence": valid_evidence}
    if event.category in OFFICIAL_STATUS_CATEGORIES:
        updates.update(
            is_ews_candidate=False,
            is_official_status_marker=True,
        )
    elif event.category == EventCategory.INTERNAL_RATING:
        updates.update(
            is_ews_candidate=False,
            is_official_status_marker=False,
        )
    else:
        updates["is_official_status_marker"] = False

    return event.model_copy(update=updates)


def _is_duplicate(left: TimelineEvent, right: TimelineEvent) -> bool:
    if left.category != right.category:
        return False
    if not _dates_compatible(left.event_date, right.event_date):
        return False

    left_chunks = {e.source_chunk_id for e in left.evidence}
    right_chunks = {e.source_chunk_id for e in right.evidence}
    evidence_overlap = bool(left_chunks & right_chunks)

    left_text = _normalize(f"{left.title} {left.description}")
    right_text = _normalize(f"{right.title} {right.description}")
    similarity = token_set_ratio(left_text, right_text)
    return evidence_overlap or similarity >= 88


def _unique_strings(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = _normalize(value)
        if normalized and normalized not in seen:
            seen.add(normalized)
            result.append(value)
    return result


def _merge_events(left: TimelineEvent, right: TimelineEvent) -> TimelineEvent:
    preferred, other = (left, right) if left.confidence >= right.confidence else (right, left)

    event_date = preferred.event_date
    date_precision = preferred.date_precision
    if DATE_PRECISION_RANK[other.date_precision] > DATE_PRECISION_RANK[date_precision]:
        event_date = other.event_date
        date_precision = other.date_precision
    elif event_date is None and other.event_date is not None:
        event_date = other.event_date
        date_precision = other.date_precision

    severity = max((left.severity, right.severity), key=SEVERITY_RANK.__getitem__)

    evidence_map: dict[tuple[str, str], Evidence] = {}
    for evidence in [*left.evidence, *right.evidence]:
        evidence_map[(evidence.source_chunk_id, _normalize(evidence.quote))] = evidence

    return preferred.model_copy(
        update={
            "event_date": event_date,
            "date_precision": date_precision,
            "severity": severity,
            "is_ews_candidate": left.is_ews_candidate or right.is_ews_candidate,
            "is_official_status_marker": (
                left.is_official_status_marker or right.is_official_status_marker
            ),
            "rating_before": preferred.rating_before or other.rating_before,
            "rating_after": preferred.rating_after or other.rating_after,
            "risk_mechanism": preferred.risk_mechanism or other.risk_mechanism,
            "quantitative_facts": _unique_strings(
                [*left.quantitative_facts, *right.quantitative_facts]
            ),
            "evidence": list(evidence_map.values()),
            "confidence": max(left.confidence, right.confidence),
        }
    )


def deduplicate_events(events: list[TimelineEvent]) -> list[TimelineEvent]:
    merged: list[TimelineEvent] = []
    for event in events:
        for index, existing in enumerate(merged):
            if _is_duplicate(existing, event):
                merged[index] = _merge_events(existing, event)
                break
        else:
            merged.append(event)

    return sorted(
        merged,
        key=lambda event: (
            event.event_date is None,
            event.event_date or "9999",
            event.category.value,
            event.title.lower(),
        ),
    )

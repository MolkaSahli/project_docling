from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EventCategory(str, Enum):
    EVENTS = "events"
    GOVERNANCE_GEOPOLITICAL_EIS = "governance_geopolitical_eis"
    FINANCIALS = "financials"
    ESG = "esg"
    COVENANT_FBE = "covenant_fbe"
    CORPORATE_LEVERAGE = "corporate_leverage"
    INTERNAL_RATING = "internal_rating"
    UTP = "utp"
    GREY_LIST = "grey_list"
    WATCHLIST = "watchlist"
    NPE = "npe"
    PD_100 = "pd_100"
    NEW_POTENTIAL_RISK_DRIVER = "new_potential_risk_driver"


OFFICIAL_STATUS_CATEGORIES = {
    EventCategory.UTP,
    EventCategory.GREY_LIST,
    EventCategory.WATCHLIST,
    EventCategory.NPE,
    EventCategory.PD_100,
}


class DatePrecision(str, Enum):
    EXACT_DAY = "exact_day"
    MONTH = "month"
    QUARTER = "quarter"
    YEAR = "year"
    PERIOD = "period"
    UNKNOWN = "unknown"


class Direction(str, Enum):
    NEGATIVE = "negative"
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    MIXED = "mixed"
    UNKNOWN = "unknown"


class EventStatus(str, Enum):
    REALIZED = "realized"
    ONGOING = "ongoing"
    EXPECTED = "expected"
    PLANNED = "planned"
    RESOLVED = "resolved"
    RUMORED = "rumored"
    UNKNOWN = "unknown"


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    UNKNOWN = "unknown"


class Evidence(StrictModel):
    source_chunk_id: str = Field(description="Identifiant exact du chunk fourni.")
    source_file: str = Field(description="Nom exact du fichier source fourni.")
    page_numbers: list[int] = Field(description="Pages source connues; liste vide si inconnues.")
    quote: str = Field(
        description="Court extrait textuel exact du contexte, sans reformulation."
    )


class TimelineEvent(StrictModel):
    event_date: str | None = Field(
        description=(
            "Date ISO YYYY-MM-DD si exacte; YYYY-MM si mois; YYYY si annee; "
            "texte de periode si necessaire; null si absente."
        )
    )
    date_precision: DatePrecision
    category: EventCategory
    subcategory: str | None
    title: str
    description: str
    risk_mechanism: str | None = Field(
        description="Lien factuel avec le risque de credit; null si non etabli par la source."
    )
    direction: Direction
    status: EventStatus
    severity: Severity
    is_ews_candidate: bool = Field(
        description="Vrai uniquement pour un signal candidat precedant ou pouvant annoncer une degradation."
    )
    is_official_status_marker: bool = Field(
        description="Vrai pour UTP, Grey list, Watchlist/WL, NPE ou PD=100%."
    )
    rating_before: str | None
    rating_after: str | None
    quantitative_facts: list[str]
    evidence: list[Evidence]
    confidence: float = Field(ge=0.0, le=1.0)


class EWSExtraction(StrictModel):
    counterparty: str
    events: list[TimelineEvent]
    extraction_notes: list[str]


class RetrievedChunk(StrictModel):
    chunk_id: str
    document_id: str
    counterparty: str
    source_file: str
    document_type: str
    chunk_index: int
    text: str
    raw_text: str
    page_numbers: list[int]
    headings: list[str]
    labels: list[str]
    is_table: bool
    matched_queries: list[str]
    retrieval_score: float
    metadata: dict[str, Any]

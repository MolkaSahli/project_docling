"""Pipeline minimal Docling + RAG + LLM pour le PFE EWS."""

__version__ = "0.1.0"

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from docling.datamodel.accelerator_options import AcceleratorDevice, AcceleratorOptions
from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import (
    EasyOcrOptions,
    PdfPipelineOptions,
    TableFormerMode,
)
from docling.document_converter import DocumentConverter, PdfFormatOption
from docling_core.types.doc import DoclingDocument

from ews_rag.config import Settings
from ews_rag.utils import sha256_file, slugify, write_json, write_jsonl

LOGGER = logging.getLogger(__name__)


DOCUMENT_TYPE_PATTERNS: list[tuple[str, tuple[str, ...]]] = [
    ("local_minutes", ("local minute", "local_minutes", "minutes", "minute")),
    ("provisioning_note", ("provision", "provisioning")),
    ("credit_decision", ("credit decision", "credit_decision", "decision")),
    ("individual_note", ("individual note", "individual_note")),
    ("financials", ("financial", "accounts", "annual report", "financials")),
]


def infer_document_type(filename: str) -> str:
    normalized = filename.lower().replace("-", " ").replace("_", " ")
    for document_type, patterns in DOCUMENT_TYPE_PATTERNS:
        if any(pattern in normalized for pattern in patterns):
            return document_type
    return "unknown"


def infer_counterparty(pdf_path: Path, input_dir: Path, fallback: str) -> str:
    relative = pdf_path.relative_to(input_dir)
    if len(relative.parts) >= 2:
        return relative.parts[0]
    return fallback


def create_converter(settings: Settings) -> DocumentConverter:
    pipeline_options = PdfPipelineOptions()
    pipeline_options.do_ocr = settings.do_ocr
    pipeline_options.do_table_structure = True
    pipeline_options.table_structure_options.mode = TableFormerMode.ACCURATE
    pipeline_options.table_structure_options.do_cell_matching = settings.do_cell_matching
    pipeline_options.accelerator_options = AcceleratorOptions(
        num_threads=settings.docling_threads,
        device=AcceleratorDevice.AUTO,
    )

    if settings.do_ocr:
        pipeline_options.ocr_options = EasyOcrOptions(
            lang=list(settings.ocr_languages) or ["fr", "en"]
        )

    return DocumentConverter(
        allowed_formats=[InputFormat.PDF],
        format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
        },
    )


def _quality_metrics(markdown: str, pages: int, tables: int) -> dict[str, Any]:
    chars = len(markdown)
    chars_per_page = round(chars / max(pages, 1), 2)
    flags: list[str] = []
    if chars_per_page < 100:
        flags.append("low_text_density")
    if tables > 0 and "|" not in markdown:
        flags.append("tables_detected_but_no_markdown_pipe_table")
    return {
        "markdown_chars": chars,
        "chars_per_page": chars_per_page,
        "quality_flags": flags,
    }


def extract_pdfs(
    settings: Settings,
    *,
    input_dir: Path | None = None,
    default_counterparty: str = "unknown",
    force: bool = False,
) -> list[dict[str, Any]]:
    settings.ensure_directories()
    input_dir = (input_dir or settings.input_dir).resolve()
    if not input_dir.exists():
        raise FileNotFoundError(f"Dossier PDF introuvable: {input_dir}")

    pdf_paths = sorted(path for path in input_dir.rglob("*.pdf") if path.is_file())
    if not pdf_paths:
        raise FileNotFoundError(
            f"Aucun PDF trouve dans {input_dir}. Placez-les par exemple dans "
            "data/input_pdfs/NOM_CONTREPARTIE/."
        )

    converter = create_converter(settings)
    manifest_rows: list[dict[str, Any]] = []

    for pdf_path in pdf_paths:
        file_hash = sha256_file(pdf_path)
        document_id = file_hash[:16]
        counterparty = infer_counterparty(
            pdf_path,
            input_dir,
            fallback=default_counterparty,
        )
        counterparty_slug = slugify(counterparty)
        base_name = f"{counterparty_slug}__{slugify(pdf_path.stem)}__{document_id}"
        json_path = settings.extracted_dir / f"{base_name}.docling.json"
        markdown_path = settings.extracted_dir / f"{base_name}.md"

        common = {
            "document_id": document_id,
            "counterparty": counterparty,
            "source_file": pdf_path.name,
            "source_path": str(pdf_path),
            "relative_path": str(pdf_path.relative_to(input_dir)),
            "document_type": infer_document_type(pdf_path.name),
            "sha256": file_hash,
            "docling_json": str(json_path),
            "markdown_file": str(markdown_path),
        }

        if not force and json_path.exists() and markdown_path.exists():
            LOGGER.info("Extraction deja presente, fichier ignore: %s", pdf_path.name)
            existing_markdown = markdown_path.read_text(encoding="utf-8")
            existing_doc = DoclingDocument.load_from_json(json_path)
            num_pages = len(existing_doc.pages)
            num_tables = len(existing_doc.tables)
            num_text_items = len(existing_doc.texts)
            manifest_rows.append(
                {
                    **common,
                    "status": "skipped_existing",
                    "num_pages": num_pages,
                    "num_tables": num_tables,
                    "num_text_items": num_text_items,
                    **_quality_metrics(existing_markdown, num_pages, num_tables),
                    "error": None,
                }
            )
            continue

        LOGGER.info("Conversion Docling: %s", pdf_path)
        try:
            result = converter.convert(pdf_path)
            document = result.document
            markdown = document.export_to_markdown()
            doc_dict = document.export_to_dict()

            write_json(json_path, doc_dict)
            markdown_path.write_text(markdown, encoding="utf-8")

            num_pages = len(document.pages)
            num_tables = len(document.tables)
            num_text_items = len(document.texts)
            manifest_rows.append(
                {
                    **common,
                    "status": "success",
                    "num_pages": num_pages,
                    "num_tables": num_tables,
                    "num_text_items": num_text_items,
                    **_quality_metrics(markdown, num_pages, num_tables),
                    "error": None,
                }
            )
        except Exception as exc:  # noqa: BLE001 - journaliser et continuer le lot
            LOGGER.exception("Echec de conversion de %s", pdf_path)
            manifest_rows.append(
                {
                    **common,
                    "status": "error",
                    "num_pages": None,
                    "num_tables": None,
                    "num_text_items": None,
                    "markdown_chars": 0,
                    "chars_per_page": 0,
                    "quality_flags": ["conversion_error"],
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )

    manifest_path = settings.extracted_dir / "manifest.jsonl"
    write_jsonl(manifest_path, manifest_rows)
    LOGGER.info("Manifest ecrit: %s", manifest_path)
    return manifest_rows

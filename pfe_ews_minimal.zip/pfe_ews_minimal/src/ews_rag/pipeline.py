from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ews_rag.chunking import build_chunks
from ews_rag.config import Settings
from ews_rag.dedupe import deduplicate_events, sanitize_event
from ews_rag.exporters import export_timeline_csv
from ews_rag.ingest import extract_pdfs
from ews_rag.llm import OpenAIEWSExtractor
from ews_rag.prompting import batch_chunks
from ews_rag.schemas import EWSExtraction, TimelineEvent
from ews_rag.utils import slugify, write_json
from ews_rag.vector_store import LocalVectorStore, build_embeddings

LOGGER = logging.getLogger(__name__)


def analyze_counterparty(
    settings: Settings,
    *,
    counterparty: str,
) -> tuple[EWSExtraction, Path, Path]:
    settings.ensure_directories()
    store = LocalVectorStore(settings)
    if counterparty not in store.counterparties:
        available = ", ".join(store.counterparties) or "aucune"
        raise ValueError(
            f"Contrepartie {counterparty!r} absente de l'index. Disponibles: {available}"
        )

    retrieved = store.multi_query_search(counterparty=counterparty)
    if not retrieved:
        raise ValueError(f"Aucun chunk retrouve pour {counterparty!r}.")

    output_slug = slugify(counterparty)
    audit_dir = settings.output_dir / "audit" / output_slug
    audit_dir.mkdir(parents=True, exist_ok=True)
    write_json(audit_dir / "retrieved_chunks.json", retrieved)

    batches = batch_chunks(
        retrieved,
        max_context_chars=settings.max_context_chars,
    )
    extractor = OpenAIEWSExtractor(settings)

    raw_events: list[TimelineEvent] = []
    notes: list[str] = []
    for batch_no, batch in enumerate(batches, start=1):
        LOGGER.info(
            "Extraction LLM lot %d/%d (%d chunks)",
            batch_no,
            len(batches),
            len(batch),
        )
        batch_result = extractor.extract(counterparty=counterparty, chunks=batch)
        raw_events.extend(batch_result.events)
        notes.extend(batch_result.extraction_notes)
        write_json(
            audit_dir / f"llm_batch_{batch_no:03d}.json",
            batch_result.model_dump(mode="json"),
        )

    chunks_by_id: dict[str, dict[str, Any]] = {
        chunk["chunk_id"]: chunk for chunk in retrieved
    }
    sanitized: list[TimelineEvent] = []
    dropped_without_evidence = 0
    for event in raw_events:
        clean = sanitize_event(event, chunks_by_id=chunks_by_id)
        if clean is None:
            dropped_without_evidence += 1
            continue
        sanitized.append(clean)

    final_events = deduplicate_events(sanitized)
    notes = [
        f"Retrieved chunks: {len(retrieved)}",
        f"LLM batches: {len(batches)}",
        f"Raw extracted events: {len(raw_events)}",
        f"Events dropped for missing/invalid evidence: {dropped_without_evidence}",
        f"Events after deduplication: {len(final_events)}",
        *notes,
    ]
    result = EWSExtraction(
        counterparty=counterparty,
        events=final_events,
        extraction_notes=notes,
    )

    json_path = settings.output_dir / f"{output_slug}_ews_timeline.json"
    csv_path = settings.output_dir / f"{output_slug}_ews_timeline.csv"
    write_json(json_path, result.model_dump(mode="json"))
    export_timeline_csv(result, csv_path)
    LOGGER.info("Resultats: %s et %s", json_path, csv_path)
    return result, json_path, csv_path


def run_all(
    settings: Settings,
    *,
    counterparty: str,
    input_dir: Path | None = None,
    force: bool = False,
) -> tuple[EWSExtraction, Path, Path]:
    extract_pdfs(
        settings,
        input_dir=input_dir,
        default_counterparty=counterparty,
        force=force,
    )
    build_chunks(settings)
    build_embeddings(settings)
    return analyze_counterparty(settings, counterparty=counterparty)

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from sentence_transformers import SentenceTransformer

from ews_rag.config import Settings
from ews_rag.queries import RETRIEVAL_QUERIES
from ews_rag.utils import read_json, read_jsonl, write_json

LOGGER = logging.getLogger(__name__)


def _uses_e5_prefix(model_name: str) -> bool:
    return "e5" in model_name.lower()


def _passage_text(model_name: str, text: str) -> str:
    return f"passage: {text}" if _uses_e5_prefix(model_name) else text


def _query_text(model_name: str, text: str) -> str:
    return f"query: {text}" if _uses_e5_prefix(model_name) else text


def build_embeddings(
    settings: Settings,
    *,
    chunks_path: Path | None = None,
) -> dict[str, Any]:
    settings.ensure_directories()
    chunks_path = chunks_path or settings.index_dir / "chunks.jsonl"
    if not chunks_path.exists():
        raise FileNotFoundError(
            f"Chunks absents: {chunks_path}. Lancez d'abord la commande chunk."
        )

    chunks = list(read_jsonl(chunks_path))
    if not chunks:
        raise ValueError("Aucun chunk a indexer.")

    LOGGER.info("Chargement du modele d'embeddings: %s", settings.embedding_model)
    model = SentenceTransformer(settings.embedding_model)
    passages = [_passage_text(settings.embedding_model, row["text"]) for row in chunks]

    embeddings = model.encode(
        passages,
        batch_size=settings.embedding_batch_size,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=True,
    ).astype(np.float32)

    embeddings_path = settings.index_dir / "embeddings.npy"
    np.save(embeddings_path, embeddings)

    metadata = {
        "embedding_model": settings.embedding_model,
        "chunk_count": len(chunks),
        "dimension": int(embeddings.shape[1]),
        "normalized": True,
        "similarity": "dot_product_equivalent_to_cosine",
        "chunks_path": str(chunks_path),
        "embeddings_path": str(embeddings_path),
        "query_prefix": "query: " if _uses_e5_prefix(settings.embedding_model) else "",
        "passage_prefix": "passage: " if _uses_e5_prefix(settings.embedding_model) else "",
    }
    write_json(settings.index_dir / "index_meta.json", metadata)
    LOGGER.info("Index local ecrit: %s", embeddings_path)
    return metadata


class LocalVectorStore:
    """Index vectoriel local minimal base sur NumPy et le produit scalaire."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        chunks_path = settings.index_dir / "chunks.jsonl"
        embeddings_path = settings.index_dir / "embeddings.npy"
        meta_path = settings.index_dir / "index_meta.json"

        for required in (chunks_path, embeddings_path, meta_path):
            if not required.exists():
                raise FileNotFoundError(
                    f"Index incomplet, fichier manquant: {required}. Lancez build-index."
                )

        self.chunks = list(read_jsonl(chunks_path))
        self.embeddings = np.load(embeddings_path, mmap_mode="r")
        self.meta = read_json(meta_path)
        if len(self.chunks) != self.embeddings.shape[0]:
            raise ValueError("Le nombre de chunks ne correspond pas au nombre d'embeddings.")

        indexed_model = self.meta["embedding_model"]
        if indexed_model != settings.embedding_model:
            raise ValueError(
                "Le modele d'embeddings configure differe de celui de l'index: "
                f"{settings.embedding_model!r} != {indexed_model!r}. Reconstruisez l'index."
            )
        self.model = SentenceTransformer(indexed_model)

    @property
    def counterparties(self) -> list[str]:
        return sorted({str(row["counterparty"]) for row in self.chunks})

    def search(
        self,
        query: str,
        *,
        top_k: int,
        counterparty: str | None = None,
    ) -> list[dict[str, Any]]:
        query_embedding = self.model.encode(
            [_query_text(self.settings.embedding_model, query)],
            convert_to_numpy=True,
            normalize_embeddings=True,
        )[0].astype(np.float32)

        if counterparty is None:
            candidate_indices = np.arange(len(self.chunks))
        else:
            candidate_indices = np.array(
                [
                    i
                    for i, chunk in enumerate(self.chunks)
                    if chunk["counterparty"] == counterparty
                ],
                dtype=np.int64,
            )

        if candidate_indices.size == 0:
            return []

        candidate_embeddings = self.embeddings[candidate_indices]
        scores = candidate_embeddings @ query_embedding
        top_k = min(top_k, candidate_indices.size)
        local_order = np.argsort(scores)[::-1][:top_k]

        results: list[dict[str, Any]] = []
        for local_idx in local_order:
            global_idx = int(candidate_indices[int(local_idx)])
            results.append(
                {
                    **self.chunks[global_idx],
                    "retrieval_score": float(scores[int(local_idx)]),
                }
            )
        return results

    def multi_query_search(
        self,
        *,
        queries: dict[str, str] | None = None,
        counterparty: str,
        top_k_per_query: int | None = None,
        max_chunks: int | None = None,
    ) -> list[dict[str, Any]]:
        queries = queries or RETRIEVAL_QUERIES
        top_k_per_query = top_k_per_query or self.settings.top_k_per_query
        max_chunks = max_chunks or self.settings.max_retrieved_chunks

        merged: dict[str, dict[str, Any]] = {}
        for query_name, query_text in queries.items():
            for hit in self.search(
                query_text,
                top_k=top_k_per_query,
                counterparty=counterparty,
            ):
                chunk_id = hit["chunk_id"]
                if chunk_id not in merged:
                    merged[chunk_id] = {
                        **hit,
                        "matched_queries": [query_name],
                    }
                else:
                    merged[chunk_id]["matched_queries"].append(query_name)
                    merged[chunk_id]["retrieval_score"] = max(
                        merged[chunk_id]["retrieval_score"],
                        hit["retrieval_score"],
                    )

        ranked = sorted(
            merged.values(),
            key=lambda row: (row["retrieval_score"], len(row["matched_queries"])),
            reverse=True,
        )[:max_chunks]

        # Pour l'extraction, on restaure ensuite un ordre documentaire plus coherent.
        ranked.sort(
            key=lambda row: (
                row["source_file"],
                min(row["page_numbers"]) if row["page_numbers"] else 10**9,
                row["chunk_index"],
            )
        )
        return ranked


def unique_counterparties(chunks: Iterable[dict[str, Any]]) -> list[str]:
    return sorted({str(chunk["counterparty"]) for chunk in chunks})

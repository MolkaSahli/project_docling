from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path
from typing import Sequence

from ews_rag.chunking import build_chunks
from ews_rag.config import Settings
from ews_rag.ingest import extract_pdfs
from ews_rag.pipeline import analyze_counterparty, run_all
from ews_rag.vector_store import LocalVectorStore, build_embeddings


def _configure_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ews-rag",
        description="Pipeline minimal Docling + RAG + LLM pour les Early Warning Signals.",
    )
    parser.add_argument("--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)

    extract = sub.add_parser("extract", help="Explorer et convertir les PDF avec Docling.")
    extract.add_argument("--input-dir", type=Path, default=None)
    extract.add_argument("--counterparty", default="unknown")
    extract.add_argument("--force", action="store_true")

    sub.add_parser("chunk", help="Creer les chunks Docling HybridChunker.")
    sub.add_parser("build-index", help="Calculer et sauvegarder les embeddings locaux.")

    retrieve = sub.add_parser("retrieve", help="Tester le retrieval sur une question.")
    retrieve.add_argument("--counterparty", required=True)
    retrieve.add_argument("--question", required=True)
    retrieve.add_argument("--top-k", type=int, default=8)

    sub.add_parser("list-counterparties", help="Lister les contreparties indexees.")

    analyze = sub.add_parser("analyze", help="Extraire et consolider les evenements EWS.")
    analyze.add_argument("--counterparty", required=True)

    all_cmd = sub.add_parser("run-all", help="Executer extraction, chunking, index et LLM.")
    all_cmd.add_argument("--counterparty", required=True)
    all_cmd.add_argument("--input-dir", type=Path, default=None)
    all_cmd.add_argument("--force", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    parser = _parser()
    args = parser.parse_args(argv)
    _configure_logging(args.verbose)
    settings = Settings()

    if args.command == "extract":
        rows = extract_pdfs(
            settings,
            input_dir=args.input_dir,
            default_counterparty=args.counterparty,
            force=args.force,
        )
        summary = {
            "documents": len(rows),
            "success": sum(row["status"] in {"success", "skipped_existing"} for row in rows),
            "errors": sum(row["status"] == "error" for row in rows),
            "manifest": str(settings.extracted_dir / "manifest.jsonl"),
        }
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return

    if args.command == "chunk":
        chunks = build_chunks(settings)
        print(json.dumps({"chunks": len(chunks)}, indent=2))
        return

    if args.command == "build-index":
        metadata = build_embeddings(settings)
        print(json.dumps(metadata, ensure_ascii=False, indent=2))
        return

    if args.command == "retrieve":
        store = LocalVectorStore(settings)
        hits = store.search(
            args.question,
            top_k=args.top_k,
            counterparty=args.counterparty,
        )
        compact = [
            {
                "score": round(hit["retrieval_score"], 4),
                "chunk_id": hit["chunk_id"],
                "source_file": hit["source_file"],
                "pages": hit["page_numbers"],
                "headings": hit["headings"],
                "text_preview": hit["text"][:700],
            }
            for hit in hits
        ]
        print(json.dumps(compact, ensure_ascii=False, indent=2))
        return

    if args.command == "list-counterparties":
        store = LocalVectorStore(settings)
        print(json.dumps(store.counterparties, ensure_ascii=False, indent=2))
        return

    if args.command == "analyze":
        result, json_path, csv_path = analyze_counterparty(
            settings,
            counterparty=args.counterparty,
        )
        print(
            json.dumps(
                {
                    "counterparty": result.counterparty,
                    "events": len(result.events),
                    "json": str(json_path),
                    "csv": str(csv_path),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return

    if args.command == "run-all":
        result, json_path, csv_path = run_all(
            settings,
            counterparty=args.counterparty,
            input_dir=args.input_dir,
            force=args.force,
        )
        print(
            json.dumps(
                {
                    "counterparty": result.counterparty,
                    "events": len(result.events),
                    "json": str(json_path),
                    "csv": str(csv_path),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return

    parser.error(f"Commande inconnue: {args.command}")

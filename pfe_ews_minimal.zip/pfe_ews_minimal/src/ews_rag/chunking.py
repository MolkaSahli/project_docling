from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from docling.chunking import HybridChunker
from docling_core.transforms.chunker.tokenizer.huggingface import HuggingFaceTokenizer
from docling_core.types.doc import DoclingDocument
from transformers import AutoTokenizer

from ews_rag.config import Settings
from ews_rag.utils import enum_value, read_jsonl, stable_id, write_jsonl

LOGGER = logging.getLogger(__name__)


def _page_numbers(chunk: Any) -> list[int]:
    pages: set[int] = set()
    for item in getattr(chunk.meta, "doc_items", []) or []:
        for prov in getattr(item, "prov", []) or []:
            page_no = getattr(prov, "page_no", None)
            if isinstance(page_no, int):
                pages.add(page_no)
    return sorted(pages)


def _labels(chunk: Any) -> list[str]:
    labels: list[str] = []
    for item in getattr(chunk.meta, "doc_items", []) or []:
        label = getattr(item, "label", None)
        if label is not None:
            labels.append(enum_value(label))
    return sorted(set(labels))


def _headings(chunk: Any) -> list[str]:
    values = getattr(chunk.meta, "headings", None) or []
    return [str(value) for value in values if str(value).strip()]


def build_chunks(
    settings: Settings,
    *,
    manifest_path: Path | None = None,
) -> list[dict[str, Any]]:
    settings.ensure_directories()
    manifest_path = manifest_path or settings.extracted_dir / "manifest.jsonl"
    if not manifest_path.exists():
        raise FileNotFoundError(
            f"Manifest absent: {manifest_path}. Lancez d'abord la commande extract."
        )

    hf_tokenizer = AutoTokenizer.from_pretrained(settings.embedding_model)
    tokenizer = HuggingFaceTokenizer(
        tokenizer=hf_tokenizer,
        max_tokens=settings.chunk_max_tokens,
    )
    chunker = HybridChunker(
        tokenizer=tokenizer,
        merge_peers=True,
        repeat_table_header=True,
        omit_header_on_overflow=False,
    )

    chunks: list[dict[str, Any]] = []
    successful_statuses = {"success", "skipped_existing"}

    for manifest in read_jsonl(manifest_path):
        if manifest.get("status") not in successful_statuses:
            continue

        json_path = Path(manifest["docling_json"])
        if not json_path.exists():
            LOGGER.warning("Docling JSON manquant: %s", json_path)
            continue

        doc = DoclingDocument.load_from_json(json_path)
        LOGGER.info("Chunking: %s", manifest["source_file"])

        for chunk_index, chunk in enumerate(chunker.chunk(dl_doc=doc)):
            contextualized = chunker.contextualize(chunk=chunk).strip()
            raw_text = (getattr(chunk, "text", None) or "").strip()
            if not contextualized:
                continue

            labels = _labels(chunk)
            pages = _page_numbers(chunk)
            headings = _headings(chunk)
            chunk_id = stable_id(
                manifest["document_id"],
                chunk_index,
                contextualized,
            )
            meta = chunk.meta.model_dump(mode="json")

            chunks.append(
                {
                    "chunk_id": chunk_id,
                    "document_id": manifest["document_id"],
                    "counterparty": manifest["counterparty"],
                    "source_file": manifest["source_file"],
                    "document_type": manifest["document_type"],
                    "chunk_index": chunk_index,
                    "text": contextualized,
                    "raw_text": raw_text,
                    "page_numbers": pages,
                    "headings": headings,
                    "labels": labels,
                    "is_table": "table" in labels,
                    "metadata": meta,
                }
            )

    chunks_path = settings.index_dir / "chunks.jsonl"
    write_jsonl(chunks_path, chunks)
    LOGGER.info("%d chunks ecrits dans %s", len(chunks), chunks_path)
    return chunks

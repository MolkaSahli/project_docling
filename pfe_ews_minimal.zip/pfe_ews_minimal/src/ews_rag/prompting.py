from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

from ews_rag.config import Settings


def load_system_prompt(settings: Settings) -> str:
    path = settings.project_root / "prompts" / "ews_system_prompt.txt"
    return path.read_text(encoding="utf-8")


def format_chunk(chunk: dict[str, Any]) -> str:
    pages = ",".join(str(p) for p in chunk.get("page_numbers", [])) or "unknown"
    headings = " > ".join(chunk.get("headings", [])) or "none"
    matched = ",".join(chunk.get("matched_queries", [])) or "manual_query"
    return (
        f"[CHUNK id={chunk['chunk_id']} | file={chunk['source_file']} | "
        f"pages={pages} | document_type={chunk['document_type']} | "
        f"headings={headings} | matched_queries={matched}]\n"
        f"{chunk['text']}\n"
        "[/CHUNK]"
    )


def build_user_prompt(
    *,
    counterparty: str,
    chunks: Iterable[dict[str, Any]],
    output_language: str,
) -> str:
    context = "\n\n".join(format_chunk(chunk) for chunk in chunks)
    return f"""
COUNTERPARTY: {counterparty}
OUTPUT LANGUAGE FOR TITLES, DESCRIPTIONS AND NOTES: {output_language}

Extract all supported timeline items from the context below. Preserve evidence quotes in their original language. The top-level counterparty field must be exactly: {counterparty}

RETRIEVED CONTEXT
{context}
""".strip()


def batch_chunks(
    chunks: list[dict[str, Any]],
    *,
    max_context_chars: int,
) -> list[list[dict[str, Any]]]:
    batches: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    current_chars = 0

    for chunk in chunks:
        chunk_chars = len(format_chunk(chunk)) + 2
        if current and current_chars + chunk_chars > max_context_chars:
            batches.append(current)
            current = []
            current_chars = 0
        current.append(chunk)
        current_chars += chunk_chars

    if current:
        batches.append(current)
    return batches

from __future__ import annotations

import os

from openai import OpenAI

from ews_rag.config import Settings
from ews_rag.prompting import build_user_prompt, load_system_prompt
from ews_rag.schemas import EWSExtraction


class OpenAIEWSExtractor:
    def __init__(self, settings: Settings) -> None:
        if not os.getenv("OPENAI_API_KEY"):
            raise EnvironmentError(
                "OPENAI_API_KEY est absent. Copiez .env.example vers .env puis renseignez la cle, "
                "uniquement si l'envoi d'extraits vers ce service est autorise."
            )
        self.settings = settings
        self.client = OpenAI()
        self.system_prompt = load_system_prompt(settings)

    def extract(
        self,
        *,
        counterparty: str,
        chunks: list[dict],
    ) -> EWSExtraction:
        user_prompt = build_user_prompt(
            counterparty=counterparty,
            chunks=chunks,
            output_language=self.settings.output_language,
        )
        response = self.client.responses.parse(
            model=self.settings.openai_model,
            instructions=self.system_prompt,
            input=user_prompt,
            text_format=EWSExtraction,
            store=False,
        )
        parsed = response.output_parsed
        if parsed is None:
            raise RuntimeError("Le LLM n'a pas retourne de sortie structuree exploitable.")
        return parsed

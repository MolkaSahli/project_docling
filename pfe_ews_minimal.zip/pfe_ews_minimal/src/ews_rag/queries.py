from __future__ import annotations


# Les requetes sont volontairement bilingues et complementaires. Le but est de
# maximiser le rappel avant l'extraction LLM, pas de produire une reponse finale.
RETRIEVAL_QUERIES: dict[str, str] = {
    "events": (
        "Material adverse events and important developments affecting the counterparty: "
        "operational disruption, litigation, fraud, incident, customer or supplier loss, "
        "project delay, restructuring, default, deterioration. Evenements significatifs, "
        "incident, litige, fraude, interruption, perte de client ou fournisseur, retard, "
        "restructuration, degradation de la contrepartie."
    ),
    "governance_geopolitical_eis": (
        "Governance, management, ownership, geopolitical and EIS risk: management change, "
        "shareholder conflict, weak controls, sanctions, war, political instability, country "
        "risk, investigation, compliance failure. Gouvernance, changement de direction, "
        "conflit actionnarial, sanctions, risque pays, instabilite politique, EIS."
    ),
    "financials": (
        "Financial deterioration and warning indicators: revenue decline, EBITDA or margin "
        "pressure, losses, negative cash flow, liquidity stress, cash burn, working capital, "
        "arrears, missed payment, forecast downgrade, profitability deterioration. Baisse du "
        "chiffre d'affaires, marge, pertes, tresorerie, liquidite, cash-flow, retards de paiement."
    ),
    "esg": (
        "ESG and sustainability risk events: environmental accident, emissions, pollution, "
        "climate exposure, labor dispute, health and safety, social controversy, governance ESG, "
        "regulatory non-compliance. Risque ESG, environnement, social, securite, controverse, "
        "non-conformite."
    ),
    "covenant_fbe": (
        "Covenant and FBE information: covenant breach, waiver, headroom, test failure, trigger, "
        "FBE date, cure, amendment, compliance certificate. Covenant, breach, waiver, headroom, "
        "FBE, non-respect, remediation."
    ),
    "corporate_leverage": (
        "Corporate leverage and funding risk: debt increase, net debt, leverage ratio, debt to "
        "EBITDA, refinancing, maturity wall, funding gap, interest burden, capital structure, "
        "shareholder loan. Endettement, levier, refinancement, maturite, cout des interets."
    ),
    "internal_rating": (
        "Internal credit rating and rating migration: internal grade, downgrade, upgrade, PD, "
        "rating change, score, outlook. Notation interne, baisse ou hausse de rating, migration, PD."
    ),
    "official_status": (
        "Official credit status and reference dates: UTP, unlikely to pay, Grey list, Watchlist, "
        "WL, NPE, non-performing exposure, PD 100 percent. Statut officiel UTP, liste grise, "
        "watchlist, WL, NPE, PD 100%."
    ),
    "forward_looking_alerts": (
        "Forward-looking risks, potential alerts and emerging risk drivers: forecast, expected, "
        "may, could, uncertainty, pressure, concern, downside, pending decision, concentration, "
        "dependency, vulnerability. Risques potentiels, alerte, prevision, incertitude, pression, "
        "dependance, vulnerabilite, facteur de risque emergent."
    ),
    "dates_and_timeline": (
        "Dates and periods associated with material events, rating changes, covenant or FBE, ESG, "
        "UTP, Grey list, Watchlist and NPE. Dates, trimestres, annees et periodes des evenements."
    ),
}

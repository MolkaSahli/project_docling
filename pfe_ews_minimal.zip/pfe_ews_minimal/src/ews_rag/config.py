from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / ".env")


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError(f"La variable {name} doit etre un entier, valeur recue: {raw!r}") from exc


@dataclass(frozen=True)
class Settings:
    project_root: Path = PROJECT_ROOT
    input_dir: Path = PROJECT_ROOT / "data" / "input_pdfs"
    extracted_dir: Path = PROJECT_ROOT / "data" / "extracted"
    index_dir: Path = PROJECT_ROOT / "data" / "index"
    output_dir: Path = PROJECT_ROOT / "data" / "outputs"

    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
    embedding_model: str = os.getenv(
        "EMBEDDING_MODEL", "intfloat/multilingual-e5-base"
    )
    chunk_max_tokens: int = _env_int("CHUNK_MAX_TOKENS", 480)
    embedding_batch_size: int = _env_int("EMBEDDING_BATCH_SIZE", 16)

    top_k_per_query: int = _env_int("TOP_K_PER_QUERY", 8)
    max_retrieved_chunks: int = _env_int("MAX_RETRIEVED_CHUNKS", 72)
    max_context_chars: int = _env_int("MAX_CONTEXT_CHARS", 60_000)

    do_ocr: bool = _env_bool("DO_OCR", True)
    ocr_languages: tuple[str, ...] = tuple(
        x.strip() for x in os.getenv("OCR_LANGUAGES", "fr,en").split(",") if x.strip()
    )
    do_cell_matching: bool = _env_bool("DO_CELL_MATCHING", True)
    docling_threads: int = _env_int("DOCLING_THREADS", 4)
    output_language: str = os.getenv("OUTPUT_LANGUAGE", "fr")

    def ensure_directories(self) -> None:
        for path in (
            self.input_dir,
            self.extracted_dir,
            self.index_dir,
            self.output_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)

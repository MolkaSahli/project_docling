from __future__ import annotations

import csv
from pathlib import Path

from ews_rag.schemas import EWSExtraction, EventCategory, TimelineEvent


BUSINESS_COLUMNS = [
    "dates",
    "internal rating",
    "events",
    "governance/ geopolitical/EIS",
    "Financials",
    "ESG",
    "Covenant/FBE",
    "corporate leverage",
    "UTP",
    "Grey list",
    "WL",
    "NPE",
    "PD=100%",
    "New potential risk drivers/alerts",
]

AUDIT_COLUMNS = [
    "category",
    "is_ews_candidate",
    "is_official_status_marker",
    "direction",
    "status",
    "severity",
    "confidence",
    "source_files",
    "pages",
    "chunk_ids",
    "evidence_quotes",
    "quantitative_facts",
]

CATEGORY_TO_COLUMN = {
    EventCategory.EVENTS: "events",
    EventCategory.GOVERNANCE_GEOPOLITICAL_EIS: "governance/ geopolitical/EIS",
    EventCategory.FINANCIALS: "Financials",
    EventCategory.ESG: "ESG",
    EventCategory.COVENANT_FBE: "Covenant/FBE",
    EventCategory.CORPORATE_LEVERAGE: "corporate leverage",
    EventCategory.UTP: "UTP",
    EventCategory.GREY_LIST: "Grey list",
    EventCategory.WATCHLIST: "WL",
    EventCategory.NPE: "NPE",
    EventCategory.PD_100: "PD=100%",
    EventCategory.NEW_POTENTIAL_RISK_DRIVER: "New potential risk drivers/alerts",
}


def _event_text(event: TimelineEvent) -> str:
    text = f"{event.title}: {event.description}"
    if event.risk_mechanism:
        text += f" | Risk mechanism: {event.risk_mechanism}"
    return text


def _event_to_row(event: TimelineEvent) -> dict[str, str | bool | float]:
    row: dict[str, str | bool | float] = {column: "" for column in BUSINESS_COLUMNS}
    row["dates"] = event.event_date or ""

    if event.category == EventCategory.INTERNAL_RATING:
        transition = ""
        if event.rating_before or event.rating_after:
            transition = f"{event.rating_before or '?'} -> {event.rating_after or '?'} | "
        row["internal rating"] = transition + _event_text(event)
    else:
        business_column = CATEGORY_TO_COLUMN.get(event.category, "events")
        row[business_column] = _event_text(event)

    source_files = sorted({e.source_file for e in event.evidence})
    pages = sorted({page for e in event.evidence for page in e.page_numbers})
    chunk_ids = [e.source_chunk_id for e in event.evidence]
    quotes = [e.quote for e in event.evidence]

    row.update(
        {
            "category": event.category.value,
            "is_ews_candidate": event.is_ews_candidate,
            "is_official_status_marker": event.is_official_status_marker,
            "direction": event.direction.value,
            "status": event.status.value,
            "severity": event.severity.value,
            "confidence": round(event.confidence, 4),
            "source_files": " | ".join(source_files),
            "pages": ",".join(str(page) for page in pages),
            "chunk_ids": " | ".join(chunk_ids),
            "evidence_quotes": " || ".join(quotes),
            "quantitative_facts": " | ".join(event.quantitative_facts),
        }
    )
    return row


def export_timeline_csv(result: EWSExtraction, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [*BUSINESS_COLUMNS, *AUDIT_COLUMNS]
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for event in result.events:
            writer.writerow(_event_to_row(event))

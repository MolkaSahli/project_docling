from __future__ import annotations

import unittest

from ews_rag.dedupe import deduplicate_events, sanitize_event
from ews_rag.schemas import (
    DatePrecision,
    Direction,
    EventCategory,
    EventStatus,
    Evidence,
    Severity,
    TimelineEvent,
)


def make_event(
    *,
    category: EventCategory,
    title: str,
    chunk_id: str = "chunk-1",
    event_date: str | None = "2025",
    candidate: bool = True,
) -> TimelineEvent:
    return TimelineEvent(
        event_date=event_date,
        date_precision=DatePrecision.YEAR if event_date else DatePrecision.UNKNOWN,
        category=category,
        subcategory=None,
        title=title,
        description="Description factuelle du test.",
        risk_mechanism="Mecanisme de risque.",
        direction=Direction.NEGATIVE,
        status=EventStatus.REALIZED,
        severity=Severity.MEDIUM,
        is_ews_candidate=candidate,
        is_official_status_marker=False,
        rating_before=None,
        rating_after=None,
        quantitative_facts=[],
        evidence=[
            Evidence(
                source_chunk_id=chunk_id,
                source_file="invented.pdf",
                page_numbers=[999],
                quote="verbatim evidence",
            )
        ],
        confidence=0.8,
    )


class BusinessRulesTests(unittest.TestCase):
    def setUp(self) -> None:
        self.chunks = {
            "chunk-1": {
                "source_file": "source.pdf",
                "page_numbers": [3],
                "text": "Context before. Verbatim evidence. Context after.",
            },
            "chunk-2": {
                "source_file": "source.pdf",
                "page_numbers": [4],
                "text": "Another passage containing verbatim evidence.",
            },
        }

    def test_official_status_is_never_candidate(self) -> None:
        event = make_event(category=EventCategory.UTP, title="UTP classification")
        clean = sanitize_event(event, chunks_by_id=self.chunks)
        self.assertIsNotNone(clean)
        assert clean is not None
        self.assertFalse(clean.is_ews_candidate)
        self.assertTrue(clean.is_official_status_marker)
        self.assertEqual(clean.evidence[0].source_file, "source.pdf")
        self.assertEqual(clean.evidence[0].page_numbers, [3])

    def test_rating_is_parallel_not_candidate(self) -> None:
        event = make_event(
            category=EventCategory.INTERNAL_RATING,
            title="Rating downgrade",
        )
        clean = sanitize_event(event, chunks_by_id=self.chunks)
        self.assertIsNotNone(clean)
        assert clean is not None
        self.assertFalse(clean.is_ews_candidate)
        self.assertFalse(clean.is_official_status_marker)

    def test_event_without_known_evidence_is_dropped(self) -> None:
        event = make_event(
            category=EventCategory.FINANCIALS,
            title="Liquidity pressure",
            chunk_id="unknown",
        )
        self.assertIsNone(sanitize_event(event, chunks_by_id=self.chunks))

    def test_hallucinated_quote_is_dropped(self) -> None:
        event = make_event(
            category=EventCategory.FINANCIALS,
            title="Liquidity pressure",
        )
        event = event.model_copy(
            update={
                "evidence": [
                    Evidence(
                        source_chunk_id="chunk-1",
                        source_file="source.pdf",
                        page_numbers=[3],
                        quote="This sentence is not in the source chunk.",
                    )
                ]
            }
        )
        self.assertIsNone(sanitize_event(event, chunks_by_id=self.chunks))

    def test_similar_events_are_deduplicated(self) -> None:
        first = make_event(
            category=EventCategory.FINANCIALS,
            title="Liquidity pressure",
            chunk_id="chunk-1",
        )
        second = make_event(
            category=EventCategory.FINANCIALS,
            title="Pressure on liquidity",
            chunk_id="chunk-2",
        ).model_copy(update={"description": "Description factuelle du test."})

        first_clean = sanitize_event(first, chunks_by_id=self.chunks)
        second_clean = sanitize_event(second, chunks_by_id=self.chunks)
        assert first_clean is not None and second_clean is not None
        merged = deduplicate_events([first_clean, second_clean])
        self.assertEqual(len(merged), 1)
        self.assertEqual(len(merged[0].evidence), 2)


if __name__ == "__main__":
    unittest.main()

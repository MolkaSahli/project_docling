# Prototype minimal PFE — Docling + RAG + LLM pour les Early Warning Signals

Ce dépôt fournit un premier pipeline testable, volontairement limité à quatre briques :

1. **Docling** pour explorer et convertir les PDF ;
2. **TableFormer Accurate** pour la structure des tableaux ;
3. **Docling HybridChunker** pour produire des chunks conservant titres, tableaux et provenance ;
4. **RAG local + LLM** pour retrouver les passages pertinents et extraire une timeline structurée.

Le prototype ne contient pas encore OpenCV, VLM, agents spécialisés, base vectorielle serveur ni interface web. Son objectif est d'obtenir rapidement une première mesure de bout en bout avant de complexifier l'architecture.

## 1. Règles métier intégrées

Les catégories de sortie reprennent celles définies pour le PFE :

- dates ;
- internal rating ;
- events ;
- governance / geopolitical / EIS ;
- Financials ;
- ESG ;
- Covenant / FBE ;
- corporate leverage ;
- UTP ;
- Grey list ;
- WL ;
- NPE ;
- New potential risk drivers / alerts.

Le pipeline impose aussi les distinctions suivantes :

- **UTP, Grey list, Watchlist/WL, NPE et PD=100%** sont enregistrés comme marqueurs officiels, mais ne sont jamais classés comme signaux EWS candidats ;
- les observations de **rating interne** sont conservées sur la timeline parallèle, mais ne sont pas classées comme EWS candidates ;
- chaque événement doit garder au moins un `chunk_id`, un fichier, une page si disponible et une citation textuelle ;
- la citation doit réellement apparaître dans le texte du chunk référencé, à de simples différences d’espaces ou d’accents près ;
- un événement sans preuve rattachable à un chunk fourni est supprimé du résultat final.

## 2. Structure du projet

```text
pfe_ews_minimal/
├── .env.example
├── pyproject.toml
├── README.md
├── prompts/
│   └── ews_system_prompt.txt
├── data/
│   ├── input_pdfs/
│   │   └── NOM_CONTREPARTIE/
│   │       ├── local_minutes.pdf
│   │       ├── credit_decision.pdf
│   │       └── financials.pdf
│   ├── extracted/
│   │   ├── manifest.jsonl
│   │   ├── *.docling.json
│   │   └── *.md
│   ├── index/
│   │   ├── chunks.jsonl
│   │   ├── embeddings.npy
│   │   └── index_meta.json
│   └── outputs/
│       ├── <contrepartie>_ews_timeline.json
│       ├── <contrepartie>_ews_timeline.csv
│       └── audit/<contrepartie>/
└── src/ews_rag/
    ├── ingest.py
    ├── chunking.py
    ├── vector_store.py
    ├── prompting.py
    ├── llm.py
    ├── schemas.py
    ├── dedupe.py
    ├── exporters.py
    ├── pipeline.py
    └── cli.py
```

## 3. Préparer l'environnement

Utiliser Python 3.10 ou supérieur. Python 3.11 ou 3.12 est un choix simple pour ce test.

### Linux / macOS

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
cp .env.example .env
```

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e .
Copy-Item .env.example .env
```

Au premier lancement, Docling, EasyOCR et le modèle d'embeddings téléchargent leurs poids. Pour une installation hors ligne, il faut d'abord précharger ces modèles dans un environnement autorisé.

## 4. Confidentialité

Docling et les embeddings s'exécutent localement. En revanche, le fichier `llm.py` fourni utilise l'API OpenAI comme exemple d'appel structuré.

Ne renseigner `OPENAI_API_KEY` et ne lancer `analyze` que si l'envoi d'extraits de documents vers ce service est autorisé par l'organisation. Le code envoie uniquement les chunks retrouvés, pas le PDF complet, et utilise `store=False`, mais il s'agit toujours d'une transmission externe.

Dans un environnement bancaire fermé, remplacer `OpenAIEWSExtractor` par un client LLM interne ou local en conservant le même schéma Pydantic `EWSExtraction`.

## 5. Préparer un premier jeu de test

Commencer avec trois à cinq documents représentatifs d'une seule contrepartie :

- un document de minutes avec tableaux complexes ;
- un document Financials ;
- une Credit Decision ;
- une Provisioning Note ;
- une Individual Note si disponible.

Les placer ainsi :

```text
data/input_pdfs/COUNTERPARTY_A/document_1.pdf
data/input_pdfs/COUNTERPARTY_A/document_2.pdf
```

Le nom du premier sous-dossier devient l'identifiant de la contrepartie. Les PDF placés directement dans `data/input_pdfs/` utilisent la valeur passée avec `--counterparty`.

## 6. Étape 1 — Exploration et extraction Docling

```bash
ews-rag extract
```

Ou, si les PDF sont directement dans un autre dossier :

```bash
ews-rag extract --input-dir /chemin/vers/pdfs --counterparty COUNTERPARTY_A
```

Cette commande :

- parcourt tous les PDF ;
- calcule un hash pour chaque fichier ;
- exécute Docling avec EasyOCR français/anglais, extraction des tableaux et `TableFormerMode.ACCURATE` ;
- conserve `do_cell_matching=true` comme baseline ;
- sauvegarde la représentation Docling lossless en JSON ;
- sauvegarde une version Markdown lisible ;
- produit `data/extracted/manifest.jsonl` avec le nombre de pages, tableaux, éléments textuels et quelques indicateurs simples.

Contrôle manuel à réaliser avant la suite : ouvrir les fichiers `.md` et comparer au PDF sur quelques pages, surtout les grands tableaux.

Pour relancer réellement l'extraction après un changement de configuration :

```bash
ews-rag extract --force
```

### Test A/B utile en cas de colonnes fusionnées

La baseline utilise :

```env
DO_CELL_MATCHING=true
```

Si TableFormer détecte bien la grille mais que le rattachement aux cellules PDF fusionne plusieurs colonnes, tester exactement le même document avec :

```env
DO_CELL_MATCHING=false
```

Puis relancer `extract --force`, sans ajouter immédiatement une correction OpenCV. Comparer le contenu des cellules et non seulement l'apparence visuelle.

## 7. Étape 2 — Chunking natif Docling

```bash
ews-rag chunk
```

Le pipeline utilise `HybridChunker` avec :

- le tokenizer du même modèle que celui utilisé pour les embeddings ;
- une limite de 480 tokens ;
- l'enrichissement par les titres et métadonnées via `contextualize()` ;
- la répétition des en-têtes lorsqu'un tableau est coupé en plusieurs chunks ;
- les pages, labels et identifiants de source dans chaque enregistrement.

Sortie :

```text
data/index/chunks.jsonl
```

Chaque ligne contient notamment :

```json
{
  "chunk_id": "...",
  "counterparty": "COUNTERPARTY_A",
  "source_file": "local_minutes.pdf",
  "page_numbers": [12],
  "headings": ["Financial performance"],
  "is_table": true,
  "text": "texte contextualisé à indexer"
}
```

## 8. Étape 3 — Construire l'index RAG local

```bash
ews-rag build-index
```

La baseline utilise `intfloat/multilingual-e5-base`, adapté à des requêtes et documents multilingues. Les passages sont préfixés par `passage:` et les requêtes par `query:`. Les vecteurs sont normalisés puis stockés dans un simple tableau NumPy.

Sorties :

```text
data/index/embeddings.npy
data/index/index_meta.json
```

Pour ce premier pilote, un produit scalaire NumPy est suffisant et évite d'ajouter FAISS, Qdrant ou une base serveur. Une base vectorielle dédiée devient utile plus tard, avec davantage de contreparties et de documents.

## 9. Étape 4 — Tester le retrieval avant le LLM

```bash
ews-rag retrieve \
  --counterparty COUNTERPARTY_A \
  --question "deterioration de liquidite, baisse d'EBITDA et risque de refinancement" \
  --top-k 10
```

Vérifier que les chunks contenant les faits attendus apparaissent dans le top-k. Cette étape permet de distinguer deux types d'erreurs :

- le fait n'est pas correctement extrait ou chunké ;
- le fait existe dans l'index mais la requête ne le retrouve pas.

## 10. Étape 5 — Extraction LLM structurée

Renseigner une clé autorisée dans `.env` :

```env
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6-luna
```

Puis lancer :

```bash
ews-rag analyze --counterparty COUNTERPARTY_A
```

Le pipeline ne fait pas une seule recherche générique. Il lance plusieurs requêtes complémentaires pour :

- events ;
- governance / geopolitical / EIS ;
- Financials ;
- ESG ;
- Covenant / FBE ;
- corporate leverage ;
- internal rating ;
- marqueurs officiels ;
- risques potentiels et forward-looking ;
- dates et périodes.

Il fusionne ensuite les chunks retrouvés, les remet dans un ordre documentaire, les envoie par lots au LLM, valide les références de chunks, applique les règles métier, puis déduplique les événements.

Sorties principales :

```text
data/outputs/counterparty-a_ews_timeline.json
data/outputs/counterparty-a_ews_timeline.csv
```

Sorties d'audit :

```text
data/outputs/audit/counterparty-a/retrieved_chunks.json
data/outputs/audit/counterparty-a/llm_batch_001.json
```

## 11. Exécuter tout le pipeline

```bash
ews-rag run-all --counterparty COUNTERPARTY_A
```

Cette commande enchaîne : extraction, chunking, embeddings, retrieval multi-requêtes, LLM, contrôle des preuves, déduplication et export.

## 12. Format de sortie JSON

Chaque événement contient notamment :

```json
{
  "event_date": "2025-Q2",
  "date_precision": "quarter",
  "category": "financials",
  "title": "Pression sur la liquidité",
  "description": "...",
  "risk_mechanism": "...",
  "direction": "negative",
  "status": "ongoing",
  "severity": "medium",
  "is_ews_candidate": true,
  "is_official_status_marker": false,
  "rating_before": null,
  "rating_after": null,
  "quantitative_facts": ["..."],
  "evidence": [
    {
      "source_chunk_id": "...",
      "source_file": "local_minutes.pdf",
      "page_numbers": [12],
      "quote": "..."
    }
  ],
  "confidence": 0.88
}
```

Le CSV reprend les colonnes métier demandées et ajoute à droite les colonnes d'audit : catégorie, statut EWS, marqueur officiel, direction, sévérité, confiance, sources, pages, chunks et citations.

## 13. Évaluation minimale recommandée

Créer manuellement un petit jeu de vérité terrain de 20 à 40 événements sur les PDF pilotes. Pour chaque événement, noter : date, catégorie, description courte, page et statut candidat/officiel.

Mesurer séparément :

1. **Qualité Docling** : texte présent, valeurs numériques correctes, relation ligne/colonne compréhensible ;
2. **Recall du retrieval** : le chunk contenant l'événement apparaît-il dans le top-k d'au moins une requête ?
3. **Précision de l'extraction** : les événements produits sont-ils réellement supportés ?
4. **Recall événementiel** : combien d'événements de référence sont retrouvés ?
5. **Exactitude de la date et de la catégorie** ;
6. **Citation correcte** : fichier, page et extrait ;
7. **Official-status leakage** : nombre de UTP/WL/NPE/Grey list/PD=100 classés à tort comme EWS candidats. La cible est zéro.

Cette décomposition montre où agir ensuite : extraction de tableau, chunking, requêtes RAG, prompt ou consolidation.

## 14. Ordre conseillé pour les améliorations

Ne pas ajouter plusieurs technologies à la fois. Après le benchmark minimal :

1. corriger les requêtes et le prompt si le retrieval est bon mais l'extraction mauvaise ;
2. ajuster taille des chunks et top-k si le bon passage n'est pas récupéré ;
3. tester `do_cell_matching=false` sur les tableaux problématiques ;
4. seulement ensuite comparer correction OpenCV, TableFormer V2, VLM ou pipeline spécialisé par type de document ;
5. introduire des agents spécialisés uniquement quand la baseline fournit des métriques reproductibles.

## 15. Commandes utiles

```bash
# Lister les contreparties présentes dans l'index
ews-rag list-counterparties

# Afficher plus de journaux
ews-rag --verbose run-all --counterparty COUNTERPARTY_A

# Tests unitaires légers
python -m unittest discover -s tests -v
```

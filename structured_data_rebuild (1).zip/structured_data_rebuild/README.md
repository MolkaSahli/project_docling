
# Structured Data Rebuild — PFE EWS

Ce package reconstruit la partie structurée du projet :
RMPM, Legal Entity, Facilities, Covenants, Assets, couverture, événements et timelines.

## Structure

structured_data_rebuild/
├── notebooks/
│   ├── 00_all_in_one.ipynb
│   ├── 01_load_explore.ipynb
│   ├── 02_clean_prepare.ipynb
│   ├── 03_coverage_quality.ipynb
│   ├── 04_rmpm_analysis.ipynb
│   ├── 05_legal_entity_analysis.ipynb
│   ├── 06_facility_analysis.ipynb
│   ├── 07_covenant_asset_analysis.ipynb
│   ├── 08_events_timeline.ipynb
│   └── 09_export_final.ipynb
├── src/
│   ├── config.py
│   └── structured_utils.py
└── requirements.txt

## Ce que tu dois modifier

Ouvre `src/config.py`.

### 1. DATA_DIR

Mets le dossier contenant tes 5 Excel :

```python
DATA_DIR = Path("/home/j31461/project/data/structured")
```

Exemple si tes fichiers sont dans `/home/j31461/project/data` :

```python
DATA_DIR = Path("/home/j31461/project/data")
```

### 2. OUTPUT_DIR

Choisis où enregistrer les résultats :

```python
OUTPUT_DIR = Path("/home/j31461/project/data/structured_outputs")
```

### 3. Noms des fichiers

Ils doivent correspondre exactement à tes fichiers :

```python
FILES = {
    "rmpm": "detail_RMPM.xlsx",
    "legal_entity": "legal_entity.xlsx",
    "facility": "facility_extract.xlsx",
    "covenant": "covenant_extract.xlsx",
    "asset": "asset_extract.xlsx",
}
```

### 4. RMPM_ID

La liste actuelle est :

```python
TARGET_RMPM_IDS = [
    "4AAJ48031",
    "4AAG00476",
    "4ABW400474",
    "4ABG553078",
    "4ABE127326",
]
```

Ne la change que si tu analyses d'autres contreparties.

## Installation

Depuis la racine :

```bash
python -m pip install -r requirements.txt
```

Puis ouvre Jupyter depuis `structured_data_rebuild` ou depuis `structured_data_rebuild/notebooks`.

## Ordre recommandé

Si tu veux contrôler chaque étape :

1. `01_load_explore.ipynb`
2. `02_clean_prepare.ipynb`
3. `03_coverage_quality.ipynb`
4. `04_rmpm_analysis.ipynb`
5. `05_legal_entity_analysis.ipynb`
6. `06_facility_analysis.ipynb`
7. `07_covenant_asset_analysis.ipynb`
8. `08_events_timeline.ipynb`
9. `09_export_final.ipynb`

Si tu veux tout exécuter directement :

`00_all_in_one.ipynb`

## Fichier Python réutilisable

`src/structured_utils.py` contient les fonctions communes :

- `load_excel`
- `clean_identifier`
- `convert_date_columns`
- `normalize_boolean_columns`
- `parse_number`
- `parse_rating`
- `build_coverage`
- `extract_changes`
- `facility_changes`
- `extract_boolean_transitions`

Donc tu ne recopies pas les mêmes fonctions dans tous les notebooks.

## Sorties

Le dossier `OUTPUT_DIR` contient notamment :

- `coverage.csv`
- `legal_entity_changes.csv`
- `facility_summary.csv`
- `facility_changes.csv`
- `events.csv`
- `structured_data_cleaned.xlsx`
- des fichiers `.pkl` intermédiaires

Les `.pkl` permettent de passer d'un notebook au suivant sans refaire toutes les étapes.

## Important

Le code conserve `FACILITY_UNIQUE_ID` comme clé Facility.
Il ne recrée pas automatiquement un ancien `FACILITY_LOCAL_ID`, car la règle exacte utilisée auparavant n'est pas récupérable avec certitude.

Après le premier lancement de `01_load_explore.ipynb`, vérifie les vrais noms de colonnes.
Si certaines colonnes ont des noms différents, adapte la liste des variables dans les notebooks correspondants.


from pathlib import Path
import re
import numpy as np
import pandas as pd

TARGET_RMPM_IDS = [
    "4AAJ48031",
    "4AAG00476",
    "4ABW400474",
    "4ABG553078",
    "4ABE127326",
]

def canonical_column_name(name):
    return re.sub(r"[^A-Z0-9]+", "_", str(name).upper()).strip("_")

def find_column(df, *candidates):
    mapping = {canonical_column_name(c): c for c in df.columns}
    for candidate in candidates:
        key = canonical_column_name(candidate)
        if key in mapping:
            return mapping[key]
    return None

def clean_identifier(series):
    series = series.astype("string").str.strip()
    return series.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "<NA>": pd.NA})

def load_excel(path):
    df = pd.read_excel(path)
    df.columns = df.columns.astype(str).str.strip()
    return df

def filter_target_counterparties(df, target_ids=None):
    target_ids = target_ids or TARGET_RMPM_IDS
    if "RMPM_ID" not in df.columns:
        return df.copy()
    return df[df["RMPM_ID"].isin(target_ids)].copy()

def convert_date_columns(df):
    df = df.copy()
    explicit = {
        "SITUATION_DATE","DATE_OF_COMMITTEE","MATURITY_DATE","CREATION_DATE",
        "FBE_ENTRY_DATE","REPORTING_DATE","DUE_DATE","RECEIPT_DATE","PERFORMED_ON"
    }
    for column in df.columns:
        canonical = canonical_column_name(column)
        if "DATE" not in canonical and canonical not in explicit and not canonical.endswith("_ON"):
            continue
        try:
            parsed = pd.to_datetime(df[column], errors="coerce", utc=True)
            df[column] = parsed.dt.tz_convert("Europe/Paris").dt.tz_localize(None)
        except Exception:
            df[column] = pd.to_datetime(df[column], errors="coerce")
    return df

TRUE_VALUES = {"1","TRUE","T","YES","Y","OUI"}
FALSE_VALUES = {"0","FALSE","F","NO","N","NON"}

def normalize_boolean_value(value):
    if pd.isna(value):
        return pd.NA
    if isinstance(value, bool):
        return value
    text = str(value).strip().upper()
    if text in TRUE_VALUES:
        return True
    if text in FALSE_VALUES:
        return False
    return pd.NA

def normalize_boolean_columns(df):
    df = df.copy()
    keywords = [
        "WATCHLIST","UTP","NPE","CLOSE_TO_DEFAULT","IS_FBE",
        "IS_SECURED","HAS_COVENANT","REVOCABLE","OPEN_ENDED",
        "CASHFLOW_REPAYMENT_DEPENDENT"
    ]
    for column in df.columns:
        canonical = canonical_column_name(column)
        if any(k in canonical for k in keywords):
            converted = df[column].map(normalize_boolean_value)
            if converted.notna().any():
                df[column] = converted.astype("boolean")
    return df

def parse_number(value):
    if pd.isna(value):
        return np.nan
    if isinstance(value, (int,float,np.integer,np.floating)):
        return float(value)
    text = str(value).strip()
    is_percentage = "%" in text
    text = text.replace("\u202f","").replace("\xa0","").replace(" ","").replace("%","").replace(",",".")
    try:
        number = float(text)
        return number / 100 if is_percentage else number
    except ValueError:
        return np.nan

def parse_rating(value):
    if pd.isna(value):
        return np.nan
    if isinstance(value, (int,float,np.integer,np.floating)):
        return float(value)
    text = str(value).strip()
    if re.fullmatch(r"[+-]?\d+(?:[.,]\d+)?", text):
        return float(text.replace(",","."))
    return np.nan

def number_rows(df, rmpm_id):
    if "RMPM_ID" not in df.columns:
        return 0
    return len(df[df["RMPM_ID"] == rmpm_id])

def number_unique(df, rmpm_id, column):
    if "RMPM_ID" not in df.columns or column not in df.columns:
        return 0
    return df.loc[df["RMPM_ID"] == rmpm_id, column].nunique()

def build_coverage(rmpm, legal_entity, facility, covenant, asset, target_ids=None):
    target_ids = target_ids or TARGET_RMPM_IDS
    rows = []
    for cp in target_ids:
        rows.append({
            "RMPM_ID": cp,
            "RMPM_rows": number_rows(rmpm, cp),
            "LegalEntity_rows": number_rows(legal_entity, cp),
            "Facility_rows": number_rows(facility, cp),
            "Facilities_n": number_unique(facility, cp, "FACILITY_UNIQUE_ID"),
            "Covenant_rows": number_rows(covenant, cp),
            "Asset_rows": number_rows(asset, cp),
        })
    out = pd.DataFrame(rows)
    for c in ["RMPM_rows","LegalEntity_rows","Facility_rows","Covenant_rows","Asset_rows"]:
        out[c.replace("_rows","_available")] = out[c] > 0
    return out

def extract_changes(df, columns, date_column="DATE_OF_COMMITTEE"):
    results = []
    for cp, group in df.groupby("RMPM_ID"):
        group = group.sort_values(date_column)
        for column in columns:
            if column not in group.columns:
                continue
            previous = group[column].shift(1)
            mask = group[column].notna() & previous.notna() & (group[column].astype(str) != previous.astype(str))
            for idx in group[mask].index:
                results.append({
                    "RMPM_ID": cp,
                    "DATE": group.loc[idx, date_column],
                    "VARIABLE": column,
                    "OLD_VALUE": previous.loc[idx],
                    "NEW_VALUE": group.loc[idx, column],
                })
    return pd.DataFrame(results)

def facility_changes(facility_df):
    events = []
    variables = [
        "FINAL_TAKE_AMOUNT","OUTSTANDING_GLOBAL","MATURITY_DATE","IS_FBE",
        "IS_SECURED","HAS_COVENANT","REVOCABLE","OPEN_ENDED",
        "CASHFLOW_REPAYMENT_DEPENDENT"
    ]
    for (cp, fid), group in facility_df.groupby(["RMPM_ID","FACILITY_UNIQUE_ID"]):
        group = group.sort_values("DATE_OF_COMMITTEE")
        for column in variables:
            if column not in group.columns:
                continue
            previous = group[column].shift(1)
            mask = group[column].notna() & previous.notna() & (group[column].astype(str) != previous.astype(str))
            for idx in group[mask].index:
                events.append({
                    "RMPM_ID": cp, "FACILITY_UNIQUE_ID": fid,
                    "DATE": group.loc[idx, "DATE_OF_COMMITTEE"],
                    "VARIABLE": column, "OLD_VALUE": previous.loc[idx],
                    "NEW_VALUE": group.loc[idx, column],
                })
    return pd.DataFrame(events)

def extract_boolean_transitions(df, column, date_column, event_on, event_off=None):
    events = []
    if column not in df.columns:
        return events
    for cp, group in df.groupby("RMPM_ID"):
        group = group.sort_values(date_column)
        current = group[column].astype("boolean")
        previous = current.shift(1)
        entry = current.eq(True).fillna(False) & ~previous.eq(True).fillna(False)
        for idx in group[entry].index:
            events.append({
                "RMPM_ID": cp, "DATE": group.loc[idx,date_column],
                "SOURCE":"LEGAL_ENTITY","EVENT_TYPE":event_on,
                "OLD_VALUE":False,"NEW_VALUE":True,"FACILITY_UNIQUE_ID":pd.NA
            })
        if event_off:
            exit_mask = current.eq(False).fillna(False) & previous.eq(True).fillna(False)
            for idx in group[exit_mask].index:
                events.append({
                    "RMPM_ID": cp, "DATE": group.loc[idx,date_column],
                    "SOURCE":"LEGAL_ENTITY","EVENT_TYPE":event_off,
                    "OLD_VALUE":True,"NEW_VALUE":False,"FACILITY_UNIQUE_ID":pd.NA
                })
    return events


from pathlib import Path

# ============================================================
# A MODIFIER
# ============================================================
DATA_DIR = Path("/home/j31461/project/data/structured")
OUTPUT_DIR = Path("/home/j31461/project/data/structured_outputs")

FILES = {
    "rmpm": "detail_RMPM.xlsx",
    "legal_entity": "legal_entity.xlsx",
    "facility": "facility_extract.xlsx",
    "covenant": "covenant_extract.xlsx",
    "asset": "asset_extract.xlsx",
}

TARGET_RMPM_IDS = [
    "4AAJ48031",
    "4AAG00476",
    "4ABW400474",
    "4ABG553078",
    "4ABE127326",
]

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

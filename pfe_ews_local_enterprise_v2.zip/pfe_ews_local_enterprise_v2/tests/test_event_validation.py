from types import SimpleNamespace

from pfe_ews.event_validation import deduplicate_events, validate_events
from pfe_ews.schemas import Evidence, TimelineEvent


def _settings():
    return SimpleNamespace(min_evidence_fuzzy_score=90)


def _event(**updates) -> TimelineEvent:
    values = {
        "event_date": "2025-Q1",
        "date_precision": "quarter",
        "category": "financials",
        "subcategory": "liquidity",
        "title": "Pression sur la liquidite",
        "description": "La liquidite disponible a fortement diminue.",
        "risk_mechanism": "Le coussin de tresorerie disponible se reduit.",
        "direction": "negative",
        "status": "occurred",
        "severity": "high",
        "is_ews_candidate": True,
        "is_official_status_marker": False,
        "rating_before": None,
        "rating_after": None,
        "quantitative_facts": ["Cash decreased from EUR 25m to EUR 14m"],
        "evidence": [
            Evidence(
                source_chunk_id="chunk-1",
                quote="Cash decreased from EUR 25m to EUR 14m.",
            )
        ],
        "confidence": 0.91,
        "source_task_id": "financials",
    }
    values.update(updates)
    return TimelineEvent(**values)


def test_official_status_is_forced_to_non_candidate():
    event = _event(
        category="watchlist",
        title="Placement en Watchlist",
        description="La contrepartie a ete placee en Watchlist.",
        evidence=[
            Evidence(
                source_chunk_id="chunk-1",
                quote="The counterparty was placed on the Watchlist.",
            )
        ],
        is_ews_candidate=True,
        is_official_status_marker=False,
    )
    chunks = {
        "chunk-1": {
            "chunk_id": "chunk-1",
            "text": "The counterparty was placed on the Watchlist.",
            "source_file": "credit_decision.pdf",
            "page_numbers": [7],
            "headings": ["Risk status"],
        }
    }
    accepted, rejected = validate_events(
        events=[event], chunk_by_id=chunks, settings=_settings()
    )
    assert not rejected
    assert len(accepted) == 1
    assert accepted[0].is_ews_candidate is False
    assert accepted[0].is_official_status_marker is True
    assert accepted[0].evidence[0].page_numbers == [7]


def test_invented_quote_is_rejected():
    event = _event(
        evidence=[
            Evidence(
                source_chunk_id="chunk-1",
                quote="The company lost its largest customer yesterday.",
            )
        ]
    )
    chunks = {
        "chunk-1": {
            "chunk_id": "chunk-1",
            "text": "EBITDA decreased while liquidity remained stable.",
            "source_file": "minutes.pdf",
            "page_numbers": [4],
        }
    }
    accepted, rejected = validate_events(
        events=[event], chunk_by_id=chunks, settings=_settings()
    )
    assert accepted == []
    assert len(rejected) == 1
    assert rejected[0]["reason"] == "aucune preuve valide"


def test_deduplication_merges_evidence_and_facts():
    first = _event(
        event_id="event-1",
        evidence=[
            Evidence(
                source_chunk_id="chunk-1",
                quote="Cash decreased from EUR 25m to EUR 14m.",
                source_file="minutes.pdf",
                page_numbers=[4],
                validation_score=100,
            )
        ],
        confidence=0.91,
    )
    second = _event(
        event_id="event-2",
        title="Forte baisse de la liquidite",
        description="La liquidite disponible a fortement baisse.",
        evidence=[
            Evidence(
                source_chunk_id="chunk-2",
                quote="Available cash fell to EUR 14m.",
                source_file="credit_decision.pdf",
                page_numbers=[8],
                validation_score=100,
            )
        ],
        quantitative_facts=["Available cash fell to EUR 14m"],
        confidence=0.88,
    )
    merged = deduplicate_events([first, second], similarity_threshold=70)
    assert len(merged) == 1
    assert len(merged[0].evidence) == 2
    assert len(merged[0].quantitative_facts) == 2
    assert merged[0].confidence == 0.91

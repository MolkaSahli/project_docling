from types import SimpleNamespace

from pfe_ews.embedding_profiles import passage_text, profile_for, query_text


def _settings(model: str, **overrides):
    values = {
        "embedding_model": model,
        "embedding_query_prefix": "",
        "embedding_passage_prefix": "",
        "embedding_query_instruction": "",
    }
    values.update(overrides)
    return SimpleNamespace(**values)


def test_bge_m3_profile_is_multilingual_and_8k():
    profile = profile_for("bge-m3-ITG")
    assert profile.family == "bge_m3"
    assert profile.multilingual is True
    assert profile.context_tokens == 8192
    assert profile.expected_dimension == 1024


def test_e5_prefixes_are_applied():
    settings = _settings("multilingual-e5-large-ITG")
    assert query_text(settings, "liquidite") == "query: liquidite"
    assert passage_text(settings, "tresorerie sous pression") == (
        "passage: tresorerie sous pression"
    )


def test_qwen_query_instruction_is_applied_only_to_query():
    settings = _settings("qwen3-embedding-8b")
    query = query_text(settings, "covenant breach")
    assert query.startswith("Instruct: ")
    assert "Query: covenant breach" in query
    assert passage_text(settings, "covenant headroom reduced") == (
        "covenant headroom reduced"
    )

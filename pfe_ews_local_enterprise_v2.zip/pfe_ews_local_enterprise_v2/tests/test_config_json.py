import os

from pfe_ews.config import _env_json_object, _env_json_string_object


def test_extra_body_json_preserves_types(monkeypatch):
    monkeypatch.setenv("TEST_JSON_BODY", '{"top_p": 1.0, "flag": true}')
    value = _env_json_object("TEST_JSON_BODY")
    assert value == {"top_p": 1.0, "flag": True}


def test_header_json_casts_values_to_strings(monkeypatch):
    monkeypatch.setenv("TEST_JSON_HEADERS", '{"X-Number": 42}')
    value = _env_json_string_object("TEST_JSON_HEADERS")
    assert value == {"X-Number": "42"}

import numpy as np

from pfe_ews.enterprise_api import (
    _normalize_vectors,
    _parse_embedding_response,
    extract_json_object,
)


def test_openai_embedding_response_is_parsed_in_index_order():
    payload = {
        "data": [
            {"index": 1, "embedding": [0.0, 2.0]},
            {"index": 0, "embedding": [3.0, 4.0]},
        ]
    }
    vectors = _parse_embedding_response(payload)
    assert vectors == [[3.0, 4.0], [0.0, 2.0]]
    matrix = _normalize_vectors(vectors)
    assert matrix.shape == (2, 2)
    np.testing.assert_allclose(np.linalg.norm(matrix, axis=1), [1.0, 1.0])


def test_json_can_be_extracted_from_code_fence():
    value = extract_json_object('```json\n{"ok": true}\n```')
    assert value == {"ok": True}

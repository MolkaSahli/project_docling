from types import SimpleNamespace

from pfe_ews.pdf_report import generate_pdf_report
from pfe_ews.schemas import CounterpartyResult, Evidence, TimelineEvent


def test_pdf_report_is_generated(tmp_path):
    event = TimelineEvent(
        event_id="evt-1",
        event_date="2025-Q1",
        date_precision="quarter",
        category="financials",
        subcategory="liquidity",
        title="Pression sur la liquidite",
        description="La liquidite disponible a diminue au premier trimestre.",
        risk_mechanism="Le coussin de liquidite disponible se reduit.",
        direction="negative",
        status="occurred",
        severity="high",
        is_ews_candidate=True,
        is_official_status_marker=False,
        quantitative_facts=["Cash: EUR 25m -> EUR 14m"],
        evidence=[
            Evidence(
                source_chunk_id="chunk-1",
                quote="Cash decreased from EUR 25m to EUR 14m.",
                source_file="local_minutes.pdf",
                page_numbers=[12],
                headings=["Liquidity"],
                validation_score=100,
            )
        ],
        confidence=0.93,
        source_task_id="financials",
    )
    result = CounterpartyResult(
        counterparty="ENTREPRISE TEST",
        generated_at_utc="2026-08-19T10:00:00+00:00",
        embedding_model="bge-m3-ITG",
        llm_model="mistral-medium-2508-ITG",
        vector_store_backend="qdrant_local",
        source_documents=["local_minutes.pdf"],
        events=[event],
    )
    settings = SimpleNamespace(
        outputs_dir=tmp_path,
        report_title="Rapport des evenements candidats Early Warning Signals",
        report_confidentiality_label=(
            "CONFIDENTIEL - PROTOTYPE PFE - A VALIDER PAR UN ANALYSTE"
        ),
    )
    output = generate_pdf_report(settings, result)
    assert output.exists()
    assert output.stat().st_size > 2000
    assert output.read_bytes().startswith(b"%PDF")

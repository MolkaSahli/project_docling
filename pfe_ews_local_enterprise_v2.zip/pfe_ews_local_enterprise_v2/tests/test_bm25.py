from pfe_ews.lexical_bm25 import BM25Index, tokenize


def test_tokenizer_preserves_banking_acronyms_and_ratios():
    tokens = tokenize("UTP NPE PD=100% Net Debt/EBITDA FBE")
    assert "utp" in tokens
    assert "npe" in tokens
    assert "pd=100%" in tokens
    assert "fbe" in tokens


def test_bm25_retrieves_exact_fbe_chunk_first():
    chunks = [
        {
            "chunk_id": "financial",
            "counterparty": "A",
            "text": "EBITDA decreased and liquidity remained limited.",
        },
        {
            "chunk_id": "fbe",
            "counterparty": "A",
            "text": "An FBE was recorded following a covenant breach and waiver request.",
        },
        {
            "chunk_id": "other",
            "counterparty": "B",
            "text": "FBE covenant breach for another counterparty.",
        },
    ]
    index = BM25Index(chunks)
    hits = index.search("FBE covenant breach", top_k=3, counterparty="A")
    assert hits
    assert hits[0]["chunk_id"] == "fbe"
    assert all(hit["counterparty"] == "A" for hit in hits)

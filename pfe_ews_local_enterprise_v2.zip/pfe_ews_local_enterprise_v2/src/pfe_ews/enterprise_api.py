from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Iterable
from urllib.parse import urljoin

import httpx
import numpy as np

from pfe_ews.config import Settings

LOGGER = logging.getLogger(__name__)


class EnterpriseAPIError(RuntimeError):
    pass


def _join_url(base_url: str, endpoint_path: str) -> str:
    if not base_url.strip():
        raise EnterpriseAPIError(
            "Base URL absente. Renseignez EMBEDDING_BASE_URL ou LLM_BASE_URL dans .env."
        )
    return urljoin(base_url.rstrip("/") + "/", endpoint_path.lstrip("/"))


def _auth_headers(
    *,
    api_key: str,
    auth_mode: str,
    api_key_header: str,
    extra_headers: dict[str, str],
) -> dict[str, str]:
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    headers.update(extra_headers)
    if auth_mode == "none":
        return headers
    if not api_key:
        raise EnterpriseAPIError(
            f"Une cle interne est requise pour le mode d'authentification {auth_mode!r}."
        )
    if auth_mode == "bearer":
        headers["Authorization"] = f"Bearer {api_key}"
    elif auth_mode == "x-api-key":
        headers["X-API-Key"] = api_key
    elif auth_mode == "custom":
        headers[api_key_header] = api_key
    else:
        raise EnterpriseAPIError(f"Mode d'authentification inconnu: {auth_mode}")
    return headers


def _extract_error_text(response: httpx.Response) -> str:
    try:
        payload = response.json()
    except Exception:
        return response.text[:2000]
    if isinstance(payload, dict):
        for key in ("error", "message", "detail"):
            value = payload.get(key)
            if isinstance(value, dict):
                return json.dumps(value, ensure_ascii=False)[:2000]
            if value:
                return str(value)[:2000]
    return json.dumps(payload, ensure_ascii=False)[:2000]


def _request_json(
    *,
    method: str,
    url: str,
    headers: dict[str, str],
    payload: dict[str, Any],
    timeout_seconds: int,
    verify: bool | str,
    max_retries: int,
    backoff_seconds: float,
) -> dict[str, Any]:
    last_error: Exception | None = None
    with httpx.Client(timeout=timeout_seconds, verify=verify) as client:
        for attempt in range(max_retries + 1):
            try:
                response = client.request(
                    method=method, url=url, headers=headers, json=payload
                )
                if response.status_code >= 400:
                    error_text = _extract_error_text(response)
                    if response.status_code in {408, 429, 500, 502, 503, 504}:
                        raise EnterpriseAPIError(
                            f"HTTP {response.status_code}: {error_text}"
                        )
                    raise EnterpriseAPIError(
                        f"Requete refusee HTTP {response.status_code}: {error_text}"
                    )
                value = response.json()
                if not isinstance(value, dict):
                    raise EnterpriseAPIError(
                        "La reponse de la passerelle n'est pas un objet JSON."
                    )
                return value
            except (httpx.HTTPError, EnterpriseAPIError) as exc:
                last_error = exc
                if attempt >= max_retries:
                    break
                delay = backoff_seconds * (2**attempt)
                LOGGER.warning(
                    "Echec API interne (tentative %d/%d): %s. Nouvel essai dans %.1fs.",
                    attempt + 1,
                    max_retries + 1,
                    exc,
                    delay,
                )
                time.sleep(delay)
    raise EnterpriseAPIError(f"Echec de l'API interne: {last_error}")


def _parse_embedding_response(payload: dict[str, Any]) -> list[list[float]]:
    vectors: Any = None
    data = payload.get("data")
    if isinstance(data, list):
        sorted_items = sorted(
            data,
            key=lambda item: int(item.get("index", 0)) if isinstance(item, dict) else 0,
        )
        vectors = [
            item.get("embedding") if isinstance(item, dict) else item
            for item in sorted_items
        ]
    elif isinstance(data, dict):
        vectors = data.get("embeddings") or data.get("vectors")
    if vectors is None:
        vectors = (
            payload.get("embeddings")
            or payload.get("vectors")
            or payload.get("embedding")
        )
    if vectors is None:
        raise EnterpriseAPIError(
            "Format de reponse embeddings inconnu. Attendu: data[].embedding ou embeddings."
        )
    if vectors and isinstance(vectors[0], (int, float)):
        vectors = [vectors]
    if not isinstance(vectors, list) or not all(isinstance(item, list) for item in vectors):
        raise EnterpriseAPIError("Les embeddings retournes ne sont pas une matrice.")
    try:
        return [[float(value) for value in row] for row in vectors]
    except (TypeError, ValueError) as exc:
        raise EnterpriseAPIError("Valeurs d'embeddings invalides.") from exc


def _normalize_vectors(vectors: list[list[float]]) -> np.ndarray:
    matrix = np.asarray(vectors, dtype=np.float32)
    if matrix.ndim != 2 or matrix.shape[1] == 0:
        raise EnterpriseAPIError("Matrice d'embeddings vide ou invalide.")
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    if np.any(norms == 0):
        raise EnterpriseAPIError("Au moins un embedding est nul.")
    return matrix / norms


@dataclass(slots=True)
class EnterpriseEmbeddingClient:
    settings: Settings

    @property
    def url(self) -> str:
        return _join_url(
            self.settings.embedding_base_url,
            self.settings.embedding_endpoint_path,
        )

    def embed(self, texts: Iterable[str]) -> np.ndarray:
        values = list(texts)
        if not values:
            return np.empty((0, 0), dtype=np.float32)
        payload: dict[str, Any] = {
            "model": self.settings.embedding_model,
            "input": values,
            **self.settings.embedding_extra_body,
        }
        if self.settings.embedding_dimensions:
            payload["dimensions"] = self.settings.embedding_dimensions
        headers = _auth_headers(
            api_key=self.settings.embedding_api_key,
            auth_mode=self.settings.embedding_auth_mode,
            api_key_header=self.settings.embedding_api_key_header,
            extra_headers=self.settings.enterprise_extra_headers,
        )
        response = _request_json(
            method="POST",
            url=self.url,
            headers=headers,
            payload=payload,
            timeout_seconds=self.settings.embedding_timeout_seconds,
            verify=self.settings.http_verify,
            max_retries=self.settings.http_max_retries,
            backoff_seconds=self.settings.http_backoff_seconds,
        )
        matrix = _normalize_vectors(_parse_embedding_response(response))
        if matrix.shape[0] != len(values):
            raise EnterpriseAPIError(
                f"Nombre de vecteurs inattendu: {matrix.shape[0]} pour {len(values)} textes."
            )
        return matrix

    def embed_batched(self, texts: list[str]) -> np.ndarray:
        batches: list[np.ndarray] = []
        batch_size = self.settings.embedding_batch_size
        for start in range(0, len(texts), batch_size):
            batch = texts[start : start + batch_size]
            LOGGER.info(
                "Embeddings %d-%d / %d",
                start + 1,
                start + len(batch),
                len(texts),
            )
            batches.append(self.embed(batch))
        if not batches:
            return np.empty((0, 0), dtype=np.float32)
        dimensions = {part.shape[1] for part in batches}
        if len(dimensions) != 1:
            raise EnterpriseAPIError(
                f"Dimensions incoherentes entre lots: {sorted(dimensions)}"
            )
        return np.vstack(batches).astype(np.float32)


def _content_to_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                value = item.get("text") or item.get("content")
                if value:
                    parts.append(str(value))
        return "\n".join(parts)
    return str(content or "")


def _parse_chat_response(payload: dict[str, Any]) -> str:
    choices = payload.get("choices")
    if isinstance(choices, list) and choices:
        first = choices[0]
        if isinstance(first, dict):
            message = first.get("message")
            if isinstance(message, dict):
                text = _content_to_text(message.get("content"))
                if text:
                    return text
            text = first.get("text")
            if text:
                return str(text)
    for key in ("output_text", "generated_text", "response", "text"):
        value = payload.get(key)
        if value:
            return _content_to_text(value)
    output = payload.get("output")
    if isinstance(output, list):
        collected: list[str] = []
        for item in output:
            if isinstance(item, dict):
                collected.append(_content_to_text(item.get("content")))
        text = "\n".join(part for part in collected if part)
        if text:
            return text
    raise EnterpriseAPIError(
        "Format de reponse LLM inconnu. Attendu: choices[0].message.content."
    )


def extract_json_object(text: str) -> dict[str, Any]:
    candidate = text.strip()
    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        candidate = "\n".join(lines).strip()
    try:
        value = json.loads(candidate)
    except json.JSONDecodeError:
        start = candidate.find("{")
        end = candidate.rfind("}")
        if start < 0 or end <= start:
            raise EnterpriseAPIError("Le LLM n'a pas retourne d'objet JSON.")
        try:
            value = json.loads(candidate[start : end + 1])
        except json.JSONDecodeError as exc:
            raise EnterpriseAPIError(
                "Le texte du LLM contient un JSON invalide."
            ) from exc
    if not isinstance(value, dict):
        raise EnterpriseAPIError("La sortie JSON du LLM doit etre un objet.")
    return value


@dataclass(slots=True)
class EnterpriseChatClient:
    settings: Settings

    @property
    def url(self) -> str:
        return _join_url(self.settings.llm_base_url, self.settings.llm_endpoint_path)

    def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        model: str | None = None,
    ) -> tuple[str, dict[str, Any]]:
        payload: dict[str, Any] = {
            "model": model or self.settings.llm_model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": self.settings.llm_temperature,
            "max_tokens": self.settings.llm_max_output_tokens,
            **self.settings.llm_extra_body,
        }
        if self.settings.llm_use_json_mode:
            payload["response_format"] = {"type": "json_object"}
        headers = _auth_headers(
            api_key=self.settings.llm_api_key,
            auth_mode=self.settings.llm_auth_mode,
            api_key_header=self.settings.llm_api_key_header,
            extra_headers=self.settings.enterprise_extra_headers,
        )
        response = _request_json(
            method="POST",
            url=self.url,
            headers=headers,
            payload=payload,
            timeout_seconds=self.settings.llm_timeout_seconds,
            verify=self.settings.http_verify,
            max_retries=self.settings.http_max_retries,
            backoff_seconds=self.settings.http_backoff_seconds,
        )
        return _parse_chat_response(response), response

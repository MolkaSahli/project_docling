from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


Category = Literal[
    "events",
    "governance_geopolitical_eis",
    "financials",
    "esg",
    "covenant_fbe",
    "corporate_leverage",
    "internal_rating",
    "utp",
    "grey_list",
    "watchlist",
    "npe",
    "pd_100",
    "new_potential_risk_driver",
]
DatePrecision = Literal[
    "day", "month", "quarter", "year", "period", "unknown"
]
Direction = Literal["negative", "positive", "mixed", "neutral", "unknown"]
EventStatus = Literal[
    "occurred", "ongoing", "expected", "planned", "resolved", "rumor", "unknown"
]
Severity = Literal["low", "medium", "high", "critical", "unknown"]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Evidence(StrictModel):
    source_chunk_id: str
    quote: str = Field(min_length=5)
    source_file: str | None = None
    page_numbers: list[int] = Field(default_factory=list)
    headings: list[str] = Field(default_factory=list)
    validation_score: float | None = Field(default=None, ge=0.0, le=100.0)


class TimelineEvent(StrictModel):
    event_id: str | None = None
    event_date: str | None = None
    date_precision: DatePrecision = "unknown"
    category: Category
    subcategory: str | None = None
    title: str = Field(min_length=3, max_length=220)
    description: str = Field(min_length=5)
    risk_mechanism: str | None = None
    direction: Direction = "unknown"
    status: EventStatus = "unknown"
    severity: Severity = "unknown"
    is_ews_candidate: bool
    is_official_status_marker: bool
    rating_before: str | None = None
    rating_after: str | None = None
    quantitative_facts: list[str] = Field(default_factory=list)
    evidence: list[Evidence] = Field(min_length=1)
    confidence: float = Field(ge=0.0, le=1.0)
    source_task_id: str | None = None
    validation_notes: list[str] = Field(default_factory=list)


class EWSExtractionBatch(StrictModel):
    counterparty: str
    task_id: str
    events: list[TimelineEvent] = Field(default_factory=list)
    extraction_notes: list[str] = Field(default_factory=list)


class CounterpartyResult(StrictModel):
    counterparty: str
    generated_at_utc: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    embedding_model: str
    llm_model: str
    vector_store_backend: str
    retrieval_mode: str = "dense_plus_local_bm25_rrf"
    source_documents: list[str] = Field(default_factory=list)
    events: list[TimelineEvent] = Field(default_factory=list)
    rejected_event_count: int = 0
    extraction_notes: list[str] = Field(default_factory=list)

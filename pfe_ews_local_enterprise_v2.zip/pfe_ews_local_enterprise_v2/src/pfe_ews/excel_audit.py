from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pfe_ews.io_utils import write_json

LOGGER = logging.getLogger(__name__)


def audit_excel_workbook(path: Path, output_path: Path) -> dict[str, Any]:
    """Cree un inventaire local du classeur sans remplacer l'extraction Docling.

    Le but est de conserver les noms de feuilles, dimensions, cellules fusionnees,
    formules et nombre de cellules non vides pour faciliter l'audit.
    """

    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError(
            "openpyxl est requis pour auditer les fichiers Excel."
        ) from exc

    workbook = load_workbook(
        filename=path,
        read_only=False,
        data_only=False,
        keep_links=True,
    )
    sheets: list[dict[str, Any]] = []

    for sheet in workbook.worksheets:
        nonempty = 0
        formulas = 0
        errors = 0
        sample_values: list[dict[str, Any]] = []
        for row in sheet.iter_rows():
            for cell in row:
                value = cell.value
                if value is None or value == "":
                    continue
                nonempty += 1
                if isinstance(value, str) and value.startswith("="):
                    formulas += 1
                if getattr(cell, "data_type", None) == "e":
                    errors += 1
                if len(sample_values) < 25:
                    sample_values.append(
                        {
                            "cell": cell.coordinate,
                            "value": str(value)[:500],
                            "data_type": str(cell.data_type),
                        }
                    )

        sheets.append(
            {
                "title": sheet.title,
                "state": sheet.sheet_state,
                "max_row": sheet.max_row,
                "max_column": sheet.max_column,
                "nonempty_cells": nonempty,
                "formula_cells": formulas,
                "error_cells": errors,
                "merged_ranges": [str(item) for item in sheet.merged_cells.ranges],
                "sample_values": sample_values,
            }
        )

    result = {
        "source_file": path.name,
        "sheet_count": len(sheets),
        "sheet_names": workbook.sheetnames,
        "sheets": sheets,
        "warning": (
            "Les formules sont conservees comme formules. Les valeurs calculees "
            "dependent du cache du classeur et de son dernier recalcul dans Excel."
        ),
    }
    write_json(output_path, result)
    LOGGER.info("Audit Excel ecrit: %s", output_path)
    return result

from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter
from typing import Any


_TOKEN_PATTERN = re.compile(
    r"[a-z0-9]+(?:[./=+%-][a-z0-9]+)*%?",
    flags=re.IGNORECASE,
)


def tokenize(text: str) -> list[str]:
    normalized = unicodedata.normalize("NFKD", text or "")
    normalized = normalized.encode("ascii", "ignore").decode("ascii").lower()
    return _TOKEN_PATTERN.findall(normalized)


class BM25Index:
    def __init__(self, chunks: list[dict[str, Any]], k1: float = 1.5, b: float = 0.75):
        self.chunks = chunks
        self.k1 = k1
        self.b = b
        self.term_frequencies: list[Counter[str]] = []
        self.doc_lengths: list[int] = []
        document_frequency: Counter[str] = Counter()

        for chunk in chunks:
            tokens = tokenize(str(chunk.get("text", "")))
            frequencies = Counter(tokens)
            self.term_frequencies.append(frequencies)
            self.doc_lengths.append(len(tokens))
            document_frequency.update(frequencies.keys())

        self.document_count = len(chunks)
        self.average_length = (
            sum(self.doc_lengths) / self.document_count if self.document_count else 0.0
        )
        self.idf = {
            term: math.log(
                1.0
                + (self.document_count - frequency + 0.5)
                / (frequency + 0.5)
            )
            for term, frequency in document_frequency.items()
        }

    def score(self, query: str, index: int) -> float:
        query_tokens = tokenize(query)
        frequencies = self.term_frequencies[index]
        length = self.doc_lengths[index]
        score = 0.0
        for term in query_tokens:
            tf = frequencies.get(term, 0)
            if tf == 0:
                continue
            denominator = tf + self.k1 * (
                1 - self.b
                + self.b * length / max(self.average_length, 1.0)
            )
            score += self.idf.get(term, 0.0) * (tf * (self.k1 + 1)) / denominator
        return score

    def search(
        self,
        query: str,
        *,
        top_k: int,
        counterparty: str | None = None,
    ) -> list[dict[str, Any]]:
        scored: list[tuple[float, int]] = []
        for index, chunk in enumerate(self.chunks):
            if counterparty is not None and chunk.get("counterparty") != counterparty:
                continue
            score = self.score(query, index)
            if score > 0:
                scored.append((score, index))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [
            {**self.chunks[index], "lexical_score": float(score)}
            for score, index in scored[:top_k]
        ]

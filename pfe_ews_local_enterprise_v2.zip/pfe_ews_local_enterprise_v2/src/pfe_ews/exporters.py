from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from pfe_ews.config import Settings
from pfe_ews.io_utils import slugify, write_json
from pfe_ews.schemas import CounterpartyResult, TimelineEvent


def _event_row(event: TimelineEvent) -> dict[str, Any]:
    source_files = list(dict.fromkeys(item.source_file or "" for item in event.evidence))
    page_values: list[str] = []
    for evidence in event.evidence:
        if evidence.page_numbers:
            page_values.append(
                f"{evidence.source_file}:" + ",".join(map(str, evidence.page_numbers))
            )
        elif evidence.headings:
            page_values.append(
                f"{evidence.source_file}:" + " > ".join(evidence.headings)
            )
    return {
        "event_id": event.event_id,
        "event_date": event.event_date,
        "date_precision": event.date_precision,
        "category": event.category,
        "subcategory": event.subcategory,
        "title": event.title,
        "description": event.description,
        "risk_mechanism": event.risk_mechanism,
        "direction": event.direction,
        "status": event.status,
        "severity": event.severity,
        "is_ews_candidate": event.is_ews_candidate,
        "is_official_status_marker": event.is_official_status_marker,
        "rating_before": event.rating_before,
        "rating_after": event.rating_after,
        "confidence": event.confidence,
        "quantitative_facts": " | ".join(event.quantitative_facts),
        "source_files": " | ".join(item for item in source_files if item),
        "source_locations": " | ".join(page_values),
        "source_chunk_ids": " | ".join(
            item.source_chunk_id for item in event.evidence
        ),
        "evidence_quotes": " | ".join(item.quote for item in event.evidence),
        "source_task_id": event.source_task_id,
        "validation_notes": " | ".join(event.validation_notes),
    }


def export_counterparty_result(
    settings: Settings, result: CounterpartyResult
) -> tuple[Path, Path]:
    output_dir = settings.outputs_dir / slugify(result.counterparty)
    output_dir.mkdir(parents=True, exist_ok=True)
    base = f"{slugify(result.counterparty)}_ews_events"
    json_path = output_dir / f"{base}.json"
    csv_path = output_dir / f"{base}.csv"

    write_json(json_path, result.model_dump(mode="json"))
    rows = [_event_row(event) for event in result.events]
    fieldnames = list(_event_row(result.events[0]).keys()) if result.events else [
        "event_id",
        "event_date",
        "date_precision",
        "category",
        "subcategory",
        "title",
        "description",
        "risk_mechanism",
        "direction",
        "status",
        "severity",
        "is_ews_candidate",
        "is_official_status_marker",
        "rating_before",
        "rating_after",
        "confidence",
        "quantitative_facts",
        "source_files",
        "source_locations",
        "source_chunk_ids",
        "evidence_quotes",
        "source_task_id",
        "validation_notes",
    ]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return json_path, csv_path

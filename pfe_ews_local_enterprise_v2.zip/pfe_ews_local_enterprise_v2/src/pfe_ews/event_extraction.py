from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from pfe_ews.config import Settings
from pfe_ews.enterprise_api import (
    EnterpriseAPIError,
    EnterpriseChatClient,
    extract_json_object,
)
from pfe_ews.event_validation import deduplicate_events, validate_events
from pfe_ews.exporters import export_counterparty_result
from pfe_ews.io_utils import read_json, slugify, write_json
from pfe_ews.prompts import (
    build_extraction_prompt,
    build_json_repair_prompt,
    load_system_prompt,
)
from pfe_ews.queries import RETRIEVAL_TASKS
from pfe_ews.retrieval import HybridRetriever
from pfe_ews.schemas import CounterpartyResult, EWSExtractionBatch, TimelineEvent

LOGGER = logging.getLogger(__name__)


def _parse_or_repair(
    *,
    client: EnterpriseChatClient,
    system_prompt: str,
    raw_text: str,
    counterparty: str,
    task_id: str,
) -> tuple[EWSExtractionBatch, str | None, dict[str, Any] | None]:
    try:
        payload = extract_json_object(raw_text)
        return EWSExtractionBatch.model_validate(payload), None, None
    except (EnterpriseAPIError, ValidationError, ValueError) as first_error:
        LOGGER.warning("JSON LLM invalide pour %s: %s", task_id, first_error)
        repair_prompt = build_json_repair_prompt(
            raw_output=raw_text,
            validation_error=str(first_error),
            counterparty=counterparty,
            task_id=task_id,
        )
        repaired_text, repaired_raw = client.complete(
            system_prompt=system_prompt,
            user_prompt=repair_prompt,
        )
        payload = extract_json_object(repaired_text)
        batch = EWSExtractionBatch.model_validate(payload)
        return batch, repaired_text, repaired_raw


def extract_counterparty(
    settings: Settings, *, counterparty: str
) -> tuple[CounterpartyResult, Path, Path]:
    settings.ensure_directories()
    system_prompt = load_system_prompt(settings)
    chat_client = EnterpriseChatClient(settings)
    retriever = HybridRetriever(settings)
    audit_dir = settings.outputs_dir / slugify(counterparty) / "audit"
    audit_dir.mkdir(parents=True, exist_ok=True)

    all_events: list[TimelineEvent] = []
    extraction_notes: list[str] = []
    retrieval_audit: dict[str, list[dict[str, Any]]] = {}
    raw_batches: list[dict[str, Any]] = []

    try:
        if counterparty not in retriever.counterparties:
            raise ValueError(
                f"Contrepartie non indexee: {counterparty}. Disponibles: {retriever.counterparties}"
            )

        for task in RETRIEVAL_TASKS:
            chunks = retriever.retrieve_task(task, counterparty=counterparty)
            retrieval_audit[task.task_id] = chunks
            if not chunks:
                extraction_notes.append(
                    f"{task.task_id}: aucun chunk retrouve; tache ignoree."
                )
                continue

            user_prompt = build_extraction_prompt(
                counterparty=counterparty,
                task=task,
                chunks=chunks,
            )
            LOGGER.info(
                "LLM %s | tache=%s | chunks=%d",
                counterparty,
                task.task_id,
                len(chunks),
            )
            raw_text, raw_response = chat_client.complete(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
            )
            batch, repaired_text, repaired_response = _parse_or_repair(
                client=chat_client,
                system_prompt=system_prompt,
                raw_text=raw_text,
                counterparty=counterparty,
                task_id=task.task_id,
            )

            if batch.counterparty != counterparty:
                extraction_notes.append(
                    f"{task.task_id}: counterparty corrigee de {batch.counterparty!r} vers {counterparty!r}."
                )
            if batch.task_id != task.task_id:
                extraction_notes.append(
                    f"{task.task_id}: task_id corrige de {batch.task_id!r}."
                )

            for event in batch.events:
                all_events.append(
                    event.model_copy(
                        update={"source_task_id": task.task_id}
                    )
                )
            extraction_notes.extend(
                f"{task.task_id}: {note}" for note in batch.extraction_notes
            )
            raw_batches.append(
                {
                    "task_id": task.task_id,
                    "model": settings.llm_model,
                    "prompt": user_prompt,
                    "raw_text": raw_text,
                    "raw_response": raw_response,
                    "repaired_text": repaired_text,
                    "repaired_response": repaired_response,
                    "parsed": batch.model_dump(mode="json"),
                }
            )

        write_json(audit_dir / "retrieved_chunks.json", retrieval_audit)
        write_json(audit_dir / "llm_batches.json", raw_batches)

        chunk_by_id = {
            chunk["chunk_id"]: chunk
            for chunks in retrieval_audit.values()
            for chunk in chunks
        }
        validated, rejected = validate_events(
            events=all_events,
            chunk_by_id=chunk_by_id,
            settings=settings,
        )
        deduplicated = deduplicate_events(
            validated,
            similarity_threshold=settings.dedupe_similarity_threshold,
        )
        write_json(audit_dir / "rejected_events.json", rejected)
        write_json(
            audit_dir / "validated_events_before_dedup.json",
            [event.model_dump(mode="json") for event in validated],
        )

        index_meta = read_json(settings.index_dir / "index_meta.json")
        source_documents = sorted(
            {
                evidence.source_file
                for event in deduplicated
                for evidence in event.evidence
                if evidence.source_file
            }
        )
        result = CounterpartyResult(
            counterparty=counterparty,
            embedding_model=settings.embedding_model,
            llm_model=settings.llm_model,
            vector_store_backend=str(index_meta["actual_backend"]),
            source_documents=source_documents,
            events=deduplicated,
            rejected_event_count=len(rejected),
            extraction_notes=extraction_notes,
        )
        json_path, csv_path = export_counterparty_result(settings, result)
        return result, json_path, csv_path
    finally:
        retriever.close()


def indexed_counterparties(settings: Settings) -> list[str]:
    chunks_path = settings.index_dir / "indexed_chunks.jsonl"
    if not chunks_path.exists():
        return []
    from pfe_ews.io_utils import read_jsonl

    return sorted({str(row["counterparty"]) for row in read_jsonl(chunks_path)})


def extract_all_counterparties(
    settings: Settings,
) -> list[tuple[CounterpartyResult, Path, Path]]:
    counterparties = indexed_counterparties(settings)
    if settings.target_counterparty:
        counterparties = [settings.target_counterparty]
    results: list[tuple[CounterpartyResult, Path, Path]] = []
    for counterparty in counterparties:
        results.append(extract_counterparty(settings, counterparty=counterparty))
    return results

from __future__ import annotations

import logging
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from pfe_ews.config import Settings
from pfe_ews.io_utils import (
    classify_document_type,
    safe_relative,
    sha256_file,
    slugify,
    stable_id,
    write_jsonl,
)

LOGGER = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {
    ".pdf",
    ".docx",
    ".doc",
    ".xlsx",
    ".xlsm",
    ".xls",
    ".csv",
}
WORD_EXTENSIONS = {".doc", ".docx"}
MODERN_EXCEL_EXTENSIONS = {".xlsx", ".xlsm"}
LEGACY_EXCEL_EXTENSIONS = {".xls"}


def _find_libreoffice(settings: Settings) -> str | None:
    if settings.libreoffice_path:
        candidate = Path(settings.libreoffice_path)
        if candidate.exists():
            return str(candidate)
        found = shutil.which(settings.libreoffice_path)
        if found:
            return found
        return None
    return shutil.which("soffice") or shutil.which("libreoffice")


def _counterparty_for(path: Path, input_dir: Path, default: str) -> str:
    relative = path.relative_to(input_dir)
    if len(relative.parts) > 1:
        return relative.parts[0]
    return default


def _convert_with_libreoffice(
    source: Path,
    output_dir: Path,
    output_format: str,
    settings: Settings,
) -> Path:
    executable = _find_libreoffice(settings)
    if not executable:
        raise FileNotFoundError(
            "LibreOffice/soffice est introuvable. Configurez LIBREOFFICE_PATH."
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="pfe_ews_lo_") as profile_dir:
        profile_uri = Path(profile_dir).resolve().as_uri()
        command = [
            executable,
            "--headless",
            "--nologo",
            "--nodefault",
            "--nofirststartwizard",
            f"-env:UserInstallation={profile_uri}",
            "--convert-to",
            output_format,
            "--outdir",
            str(output_dir),
            str(source),
        ]
        process = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=240,
        )
        if process.returncode != 0:
            raise RuntimeError(
                "Conversion LibreOffice echouee. "
                f"Code={process.returncode}; stderr={process.stderr.strip()}"
            )

    expected_suffix = ".pdf" if output_format.startswith("pdf") else ".xlsx"
    expected = output_dir / f"{source.stem}{expected_suffix}"
    if expected.exists():
        return expected

    candidates = sorted(
        output_dir.glob(f"{source.stem}.*"),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    for candidate in candidates:
        if candidate.suffix.lower() == expected_suffix:
            return candidate
    raise FileNotFoundError(
        f"LibreOffice n'a pas cree le fichier attendu pour {source.name}."
    )


def _safe_target_name(source: Path, file_hash: str, suffix: str | None = None) -> str:
    final_suffix = suffix or source.suffix.lower()
    return f"{slugify(source.stem)}__{file_hash[:10]}{final_suffix}"


def prepare_documents(settings: Settings) -> list[dict[str, Any]]:
    settings.ensure_directories()
    discovered = sorted(
        path
        for path in settings.input_dir.rglob("*")
        if path.is_file()
        and path.suffix.lower() in SUPPORTED_EXTENSIONS
        and not path.name.startswith("~$")
    )
    if settings.target_counterparty:
        discovered = [
            path
            for path in discovered
            if _counterparty_for(
                path, settings.input_dir, settings.default_counterparty
            )
            == settings.target_counterparty
        ]

    rows: list[dict[str, Any]] = []
    if not discovered:
        LOGGER.warning(
            "Aucun PDF, Word ou Excel trouve dans %s.", settings.input_dir
        )

    for source in discovered:
        counterparty = _counterparty_for(
            source, settings.input_dir, settings.default_counterparty
        )
        source_hash = sha256_file(source)
        document_id = stable_id(counterparty, source.name, source_hash)
        destination_dir = settings.prepared_dir / slugify(counterparty)
        destination_dir.mkdir(parents=True, exist_ok=True)
        extension = source.suffix.lower()

        base_row: dict[str, Any] = {
            "document_id": document_id,
            "counterparty": counterparty,
            "source_file": source.name,
            "source_path": str(source.resolve()),
            "source_relative_path": safe_relative(source, settings.project_root),
            "source_extension": extension,
            "source_sha256": source_hash,
            "document_type": classify_document_type(source.name),
            "status": "pending",
            "conversion": "none",
            "prepared_path": None,
            "prepared_extension": None,
            "error": None,
        }

        try:
            if extension == ".pdf":
                target = destination_dir / _safe_target_name(source, source_hash)
                shutil.copy2(source, target)
                conversion = "copied_pdf"

            elif extension in WORD_EXTENSIONS:
                pdf_target = destination_dir / _safe_target_name(
                    source, source_hash, ".pdf"
                )
                if pdf_target.exists() and pdf_target.stat().st_size > 0:
                    target = pdf_target
                    conversion = "word_to_pdf_cached"
                else:
                    try:
                        converted = _convert_with_libreoffice(
                            source, destination_dir, "pdf", settings
                        )
                        if converted != pdf_target:
                            if pdf_target.exists():
                                pdf_target.unlink()
                            converted.replace(pdf_target)
                        target = pdf_target
                        conversion = "word_to_pdf_libreoffice"
                    except Exception as conversion_error:
                        if settings.require_word_to_pdf:
                            raise RuntimeError(
                                "La conversion Word vers PDF est obligatoire mais a echoue. "
                                "Installez LibreOffice ou configurez LIBREOFFICE_PATH."
                            ) from conversion_error
                        if settings.allow_direct_word_fallback:
                            LOGGER.warning(
                                "Conversion Word->PDF impossible pour %s; "
                                "Docling traitera directement le Word car le repli est autorise.",
                                source,
                            )
                            target = destination_dir / _safe_target_name(
                                source, source_hash
                            )
                            shutil.copy2(source, target)
                            conversion = "direct_word_fallback"
                        else:
                            raise

            elif extension in MODERN_EXCEL_EXTENSIONS:
                target = destination_dir / _safe_target_name(source, source_hash)
                shutil.copy2(source, target)
                conversion = "copied_excel"

            elif extension in LEGACY_EXCEL_EXTENSIONS:
                xlsx_target = destination_dir / _safe_target_name(
                    source, source_hash, ".xlsx"
                )
                converted = _convert_with_libreoffice(
                    source, destination_dir, "xlsx", settings
                )
                if converted != xlsx_target:
                    if xlsx_target.exists():
                        xlsx_target.unlink()
                    converted.replace(xlsx_target)
                target = xlsx_target
                conversion = "xls_to_xlsx_libreoffice"

            elif extension == ".csv":
                target = destination_dir / _safe_target_name(source, source_hash)
                shutil.copy2(source, target)
                conversion = "copied_csv"

            else:
                raise ValueError(f"Format non gere: {extension}")

            base_row.update(
                {
                    "status": "success",
                    "conversion": conversion,
                    "prepared_path": str(target.resolve()),
                    "prepared_extension": target.suffix.lower(),
                    "prepared_sha256": sha256_file(target),
                    "prepared_size_bytes": target.stat().st_size,
                }
            )
            LOGGER.info(
                "Prepare: %s -> %s (%s)", source.name, target.name, conversion
            )
        except Exception as exc:
            LOGGER.exception("Echec de preparation: %s", source)
            base_row.update({"status": "error", "error": str(exc)})

        rows.append(base_row)

    manifest = settings.prepared_dir / "prepared_manifest.jsonl"
    write_jsonl(manifest, rows)
    return rows

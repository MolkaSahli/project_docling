from __future__ import annotations

import logging
import math
import re
from pathlib import Path
from typing import Any

from pydantic import ConfigDict

from pfe_ews.config import Settings
from pfe_ews.io_utils import enum_value, read_jsonl, stable_id, write_jsonl

LOGGER = logging.getLogger(__name__)


_WORD_OR_PUNCT = re.compile(r"\w+|[^\w\s]", flags=re.UNICODE)


def approximate_token_count(text: str) -> int:
    """Estimation conservatrice lorsque le tokenizer du modele n'est pas disponible.

    Elle ne remplace pas le tokenizer exact, mais elle permet un chunking 100 % local
    sans telechargement. La marge est volontairement prudente pour rester sous 8K.
    """

    if not text:
        return 0
    lexical = len(_WORD_OR_PUNCT.findall(text))
    char_estimate = math.ceil(len(text) / 3.5)
    return max(1, lexical, char_estimate)


def _build_tokenizer(settings: Settings):
    try:
        from docling_core.transforms.chunker.tokenizer.base import BaseTokenizer
    except ImportError as exc:
        raise RuntimeError(
            "docling-core[chunking] est requis pour le HybridChunker."
        ) from exc

    if settings.chunk_tokenizer_path:
        try:
            from docling_core.transforms.chunker.tokenizer.huggingface import (
                HuggingFaceTokenizer,
            )
            from transformers import AutoTokenizer
        except ImportError as exc:
            raise RuntimeError(
                "Le tokenizer local demande transformers/docling-core[chunking]."
            ) from exc
        hf_tokenizer = AutoTokenizer.from_pretrained(
            str(settings.chunk_tokenizer_path),
            local_files_only=True,
            trust_remote_code=True,
        )
        return HuggingFaceTokenizer(
            tokenizer=hf_tokenizer,
            max_tokens=settings.chunk_max_tokens,
        )

    class ApproximateTokenizer(BaseTokenizer):
        model_config = ConfigDict(arbitrary_types_allowed=True)
        max_tokens: int

        def count_tokens(self, text: str) -> int:
            return approximate_token_count(text)

        def get_max_tokens(self) -> int:
            return self.max_tokens

        def get_tokenizer(self):
            # semchunk accepte une fonction str -> int comme compteur de tokens.
            return approximate_token_count

    return ApproximateTokenizer(max_tokens=settings.chunk_max_tokens)


def _build_serializer_provider(settings: Settings):
    try:
        from docling_core.transforms.chunker.hierarchical_chunker import (
            ChunkingDocSerializer,
            ChunkingSerializerProvider,
        )
        from docling_core.transforms.serializer.markdown import (
            MarkdownParams,
            MarkdownTableSerializer,
        )
    except ImportError as exc:
        raise RuntimeError("Composants de serialization Docling absents.") from exc

    class EnterpriseSerializerProvider(ChunkingSerializerProvider):
        def get_serializer(self, doc):
            params = MarkdownParams(
                traverse_pictures=settings.chunk_include_picture_ocr
            )
            return ChunkingDocSerializer(
                doc=doc,
                table_serializer=MarkdownTableSerializer(),
                params=params,
            )

    return EnterpriseSerializerProvider()


def _page_numbers(chunk: Any) -> list[int]:
    pages: set[int] = set()
    meta = getattr(chunk, "meta", None)
    for item in getattr(meta, "doc_items", []) or []:
        for provenance in getattr(item, "prov", []) or []:
            page_no = getattr(provenance, "page_no", None)
            if isinstance(page_no, int):
                pages.add(page_no)
    return sorted(pages)


def _labels(chunk: Any) -> list[str]:
    values: set[str] = set()
    meta = getattr(chunk, "meta", None)
    for item in getattr(meta, "doc_items", []) or []:
        label = getattr(item, "label", None)
        if label is not None:
            values.add(enum_value(label))
    return sorted(values)


def _headings(chunk: Any) -> list[str]:
    meta = getattr(chunk, "meta", None)
    return [
        str(value).strip()
        for value in (getattr(meta, "headings", None) or [])
        if str(value).strip()
    ]


def _metadata_dump(chunk: Any) -> dict[str, Any]:
    meta = getattr(chunk, "meta", None)
    if meta is None:
        return {}
    if hasattr(meta, "model_dump"):
        return meta.model_dump(mode="json")
    return {"repr": repr(meta)}


def build_chunks(settings: Settings) -> list[dict[str, Any]]:
    settings.ensure_directories()
    manifest_path = settings.extracted_dir / "extraction_manifest.jsonl"
    if not manifest_path.exists():
        raise FileNotFoundError(
            "Le manifest Docling est absent. Executez scripts/02_extract_with_docling.py."
        )

    try:
        from docling.chunking import HybridChunker
        from docling_core.types.doc import DoclingDocument
    except ImportError as exc:
        raise RuntimeError(
            "Docling et docling-core[chunking] doivent etre installes."
        ) from exc

    tokenizer = _build_tokenizer(settings)
    serializer_provider = _build_serializer_provider(settings)
    chunker = HybridChunker(
        tokenizer=tokenizer,
        merge_peers=True,
        repeat_table_header=True,
        omit_header_on_overflow=False,
        serializer_provider=serializer_provider,
    )

    accepted_statuses = {"success", "skipped_existing"}
    documents = [
        row
        for row in read_jsonl(manifest_path)
        if row.get("extraction_status") in accepted_statuses
    ]
    if settings.target_counterparty:
        documents = [
            row
            for row in documents
            if row.get("counterparty") == settings.target_counterparty
        ]

    all_chunks: list[dict[str, Any]] = []
    for manifest in documents:
        docling_json = Path(str(manifest["docling_json"]))
        if not docling_json.exists():
            LOGGER.warning("JSON Docling absent: %s", docling_json)
            continue

        document = DoclingDocument.load_from_json(docling_json)
        document_chunks = 0
        for chunk_index, chunk in enumerate(chunker.chunk(dl_doc=document)):
            text = chunker.contextualize(chunk=chunk).strip()
            raw_text = str(getattr(chunk, "text", "") or "").strip()
            if not text:
                continue
            labels = _labels(chunk)
            pages = _page_numbers(chunk)
            headings = _headings(chunk)
            chunk_id = stable_id(
                manifest["document_id"], chunk_index, text, length=32
            )
            token_count = tokenizer.count_tokens(text)
            all_chunks.append(
                {
                    "chunk_id": chunk_id,
                    "document_id": manifest["document_id"],
                    "counterparty": manifest["counterparty"],
                    "source_file": manifest["source_file"],
                    "source_path": manifest["source_path"],
                    "prepared_path": manifest["prepared_path"],
                    "source_extension": manifest["source_extension"],
                    "prepared_extension": manifest["prepared_extension"],
                    "document_type": manifest["document_type"],
                    "chunk_index": chunk_index,
                    "text": text,
                    "raw_text": raw_text,
                    "page_numbers": pages,
                    "headings": headings,
                    "labels": labels,
                    "is_table": "table" in labels,
                    "estimated_token_count": token_count,
                    "metadata": _metadata_dump(chunk),
                }
            )
            document_chunks += 1

        LOGGER.info(
            "Chunking: %s -> %d chunks", manifest["source_file"], document_chunks
        )

    chunks_path = settings.chunks_dir / "chunks.jsonl"
    write_jsonl(chunks_path, all_chunks)
    return all_chunks

from __future__ import annotations

from collections import defaultdict
from typing import Any

from rapidfuzz import fuzz

from pfe_ews.config import Settings
from pfe_ews.io_utils import normalize_for_match, stable_id
from pfe_ews.schemas import Evidence, TimelineEvent


OFFICIAL_STATUS_CATEGORIES = {"utp", "grey_list", "watchlist", "npe", "pd_100"}


def _validate_quote(quote: str, chunk_text: str) -> float:
    normalized_quote = normalize_for_match(quote)
    normalized_chunk = normalize_for_match(chunk_text)
    if not normalized_quote or len(normalized_quote) < 5:
        return 0.0
    if normalized_quote in normalized_chunk:
        return 100.0
    return float(fuzz.partial_ratio(normalized_quote, normalized_chunk))


def validate_events(
    *,
    events: list[TimelineEvent],
    chunk_by_id: dict[str, dict[str, Any]],
    settings: Settings,
) -> tuple[list[TimelineEvent], list[dict[str, Any]]]:
    accepted: list[TimelineEvent] = []
    rejected: list[dict[str, Any]] = []

    for event in events:
        notes = list(event.validation_notes)
        valid_evidence: list[Evidence] = []
        evidence_errors: list[str] = []

        for evidence in event.evidence:
            chunk = chunk_by_id.get(evidence.source_chunk_id)
            if chunk is None:
                evidence_errors.append(
                    f"chunk inconnu: {evidence.source_chunk_id}"
                )
                continue
            score = _validate_quote(evidence.quote, str(chunk.get("text", "")))
            if score < settings.min_evidence_fuzzy_score:
                evidence_errors.append(
                    f"citation non retrouvee dans {evidence.source_chunk_id} (score={score:.1f})"
                )
                continue
            valid_evidence.append(
                Evidence(
                    source_chunk_id=evidence.source_chunk_id,
                    quote=evidence.quote.strip(),
                    source_file=str(chunk.get("source_file") or ""),
                    page_numbers=list(chunk.get("page_numbers") or []),
                    headings=list(chunk.get("headings") or []),
                    validation_score=round(score, 2),
                )
            )

        if not valid_evidence:
            rejected.append(
                {
                    "title": event.title,
                    "category": event.category,
                    "reason": "aucune preuve valide",
                    "evidence_errors": evidence_errors,
                    "raw_event": event.model_dump(mode="json"),
                }
            )
            continue

        if evidence_errors:
            notes.extend(evidence_errors)

        update: dict[str, Any] = {"evidence": valid_evidence}
        if event.category in OFFICIAL_STATUS_CATEGORIES:
            update["is_ews_candidate"] = False
            update["is_official_status_marker"] = True
            notes.append("Regle metier: statut officiel non candidat EWS.")
        elif event.category == "internal_rating":
            update["is_ews_candidate"] = False
            update["is_official_status_marker"] = False
            notes.append("Regle metier: rating conserve comme repere parallele.")
        else:
            update["is_official_status_marker"] = False
            if event.direction == "positive" and event.is_ews_candidate:
                update["is_ews_candidate"] = False
                notes.append("Regle metier: fait positif non classe candidat EWS.")

        event_id = stable_id(
            event.category,
            event.event_date or "unknown",
            normalize_for_match(event.title),
            *(item.source_chunk_id for item in valid_evidence),
            length=32,
        )
        update["event_id"] = event_id
        update["validation_notes"] = notes
        accepted.append(event.model_copy(update=update))

    return accepted, rejected


def _event_similarity(left: TimelineEvent, right: TimelineEvent) -> float:
    title_score = fuzz.token_set_ratio(
        normalize_for_match(left.title), normalize_for_match(right.title)
    )
    description_score = fuzz.token_set_ratio(
        normalize_for_match(left.description),
        normalize_for_match(right.description),
    )
    return 0.65 * title_score + 0.35 * description_score


def deduplicate_events(
    events: list[TimelineEvent], *, similarity_threshold: int
) -> list[TimelineEvent]:
    groups: dict[tuple[str, str], list[TimelineEvent]] = defaultdict(list)
    for event in events:
        groups[(event.category, event.event_date or "unknown")].append(event)

    output: list[TimelineEvent] = []
    for _, group in groups.items():
        merged: list[TimelineEvent] = []
        for event in sorted(group, key=lambda item: item.confidence, reverse=True):
            duplicate_index: int | None = None
            for index, existing in enumerate(merged):
                if _event_similarity(event, existing) >= similarity_threshold:
                    duplicate_index = index
                    break
            if duplicate_index is None:
                merged.append(event)
                continue

            existing = merged[duplicate_index]
            evidence_by_key = {
                (item.source_chunk_id, normalize_for_match(item.quote)): item
                for item in existing.evidence
            }
            for item in event.evidence:
                evidence_by_key.setdefault(
                    (item.source_chunk_id, normalize_for_match(item.quote)), item
                )
            facts = list(dict.fromkeys(existing.quantitative_facts + event.quantitative_facts))
            notes = list(
                dict.fromkeys(
                    existing.validation_notes
                    + event.validation_notes
                    + ["Doublon consolide depuis plusieurs extractions/sources."]
                )
            )
            merged[duplicate_index] = existing.model_copy(
                update={
                    "evidence": list(evidence_by_key.values()),
                    "quantitative_facts": facts,
                    "confidence": max(existing.confidence, event.confidence),
                    "validation_notes": notes,
                    "is_ews_candidate": (
                        existing.is_ews_candidate or event.is_ews_candidate
                    ),
                }
            )
        output.extend(merged)

    return sorted(
        output,
        key=lambda item: (
            item.event_date is None,
            item.event_date or "9999",
            item.category,
            item.title.lower(),
        ),
    )

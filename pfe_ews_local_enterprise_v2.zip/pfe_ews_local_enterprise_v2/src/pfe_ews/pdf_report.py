from __future__ import annotations

import html
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Iterable

from reportlab.lib import colors
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    HRFlowable,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from pfe_ews.config import Settings
from pfe_ews.io_utils import slugify
from pfe_ews.schemas import CounterpartyResult, TimelineEvent


CATEGORY_LABELS = {
    "events": "Evenements operationnels, commerciaux et juridiques",
    "governance_geopolitical_eis": "Gouvernance, geopolitique et EIS",
    "financials": "Financials",
    "esg": "ESG",
    "covenant_fbe": "Covenant / FBE",
    "corporate_leverage": "Corporate leverage et refinancement",
    "internal_rating": "Internal rating",
    "utp": "UTP",
    "grey_list": "Grey list",
    "watchlist": "Watchlist / WL",
    "npe": "NPE",
    "pd_100": "PD=100%",
    "new_potential_risk_driver": "New potential risk drivers / alerts",
}
CATEGORY_ORDER = list(CATEGORY_LABELS)
SEVERITY_LABELS = {
    "low": "Faible",
    "medium": "Moyenne",
    "high": "Elevee",
    "critical": "Critique",
    "unknown": "Non evaluee",
}
STATUS_LABELS = {
    "occurred": "Realise",
    "ongoing": "En cours",
    "expected": "Attendu",
    "planned": "Planifie",
    "resolved": "Resolu",
    "rumor": "Rumeur / non confirme",
    "unknown": "Non precise",
}

NAVY = HexColor("#17324D")
BLUE = HexColor("#2A5B84")
LIGHT_BLUE = HexColor("#EAF2F8")
PALE_BLUE = HexColor("#F5F8FB")
ORANGE = HexColor("#C86B24")
PALE_ORANGE = HexColor("#FFF3E8")
RED = HexColor("#A13A35")
PALE_RED = HexColor("#FCEDEC")
GREEN = HexColor("#3D6B57")
GRAY = HexColor("#606A73")
LIGHT_GRAY = HexColor("#E4E8EB")
VERY_LIGHT_GRAY = HexColor("#F7F8F9")


def _p(text: object) -> str:
    return html.escape(str(text or "")).replace("\n", "<br/>")


def _date_sort_key(event: TimelineEvent) -> tuple[int, str]:
    if not event.event_date:
        return (1, "9999")
    return (0, event.event_date)


def _source_location(event: TimelineEvent) -> str:
    values: list[str] = []
    for evidence in event.evidence:
        if evidence.page_numbers:
            pages = ", ".join(str(page) for page in evidence.page_numbers)
            values.append(f"{evidence.source_file} - p. {pages}")
        elif evidence.headings:
            values.append(
                f"{evidence.source_file} - {' > '.join(evidence.headings)}"
            )
        else:
            values.append(str(evidence.source_file or "source non precisee"))
    return " ; ".join(dict.fromkeys(values))


def _styles():
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="ReportTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=22,
            leading=27,
            textColor=NAVY,
            alignment=TA_LEFT,
            spaceAfter=12,
        )
    )
    styles.add(
        ParagraphStyle(
            name="ReportSubtitle",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=11,
            leading=16,
            textColor=GRAY,
            spaceAfter=16,
        )
    )
    styles.add(
        ParagraphStyle(
            name="H1Custom",
            parent=styles["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=16,
            leading=20,
            textColor=NAVY,
            spaceBefore=8,
            spaceAfter=9,
            keepWithNext=True,
        )
    )
    styles.add(
        ParagraphStyle(
            name="H2Custom",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=12.5,
            leading=16,
            textColor=BLUE,
            spaceBefore=10,
            spaceAfter=6,
            keepWithNext=True,
        )
    )
    styles.add(
        ParagraphStyle(
            name="BodyCustom",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=9.2,
            leading=13.2,
            textColor=HexColor("#26323B"),
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="SmallCustom",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=7.7,
            leading=10.5,
            textColor=GRAY,
        )
    )
    styles.add(
        ParagraphStyle(
            name="TableHeaderCustom",
            parent=styles["BodyText"],
            fontName="Helvetica-Bold",
            fontSize=7.6,
            leading=9.5,
            textColor=colors.white,
            alignment=TA_LEFT,
        )
    )
    styles.add(
        ParagraphStyle(
            name="TableCellCustom",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=7.4,
            leading=9.5,
            textColor=HexColor("#26323B"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="EventTitleCustom",
            parent=styles["Heading3"],
            fontName="Helvetica-Bold",
            fontSize=10.8,
            leading=14,
            textColor=NAVY,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            name="QuoteCustom",
            parent=styles["BodyText"],
            fontName="Helvetica-Oblique",
            fontSize=8.2,
            leading=11.2,
            textColor=HexColor("#394956"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="CoverLabel",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=8.5,
            leading=11,
            textColor=RED,
            alignment=TA_CENTER,
        )
    )
    return styles


def _header_footer(canvas, doc, settings: Settings, counterparty: str) -> None:
    canvas.saveState()
    width, height = A4
    canvas.setStrokeColor(LIGHT_GRAY)
    canvas.setLineWidth(0.5)
    canvas.line(18 * mm, height - 15 * mm, width - 18 * mm, height - 15 * mm)
    canvas.setFont("Helvetica", 7.2)
    canvas.setFillColor(GRAY)
    canvas.drawString(18 * mm, height - 11.5 * mm, str(counterparty)[:75])
    canvas.drawRightString(
        width - 18 * mm,
        height - 11.5 * mm,
        "Early Warning Signals - prototype local",
    )
    canvas.line(18 * mm, 14 * mm, width - 18 * mm, 14 * mm)
    canvas.setFont("Helvetica", 6.8)
    canvas.drawString(18 * mm, 9.5 * mm, settings.report_confidentiality_label[:95])
    canvas.drawRightString(width - 18 * mm, 9.5 * mm, f"Page {doc.page}")
    canvas.restoreState()


def _summary_cards(result: CounterpartyResult, styles) -> Table:
    candidate_count = sum(event.is_ews_candidate for event in result.events)
    official_count = sum(event.is_official_status_marker for event in result.events)
    rating_count = sum(event.category == "internal_rating" for event in result.events)
    values = [
        (str(candidate_count), "Candidats EWS"),
        (str(official_count), "Statuts officiels"),
        (str(rating_count), "Mouvements de rating"),
        (str(len(result.source_documents)), "Documents sources"),
    ]
    cells = [
        [
            Paragraph(
                f"<font size='19'><b>{_p(number)}</b></font><br/>"
                f"<font size='7.5'>{_p(label)}</font>",
                ParagraphStyle(
                    name=f"Card{index}",
                    parent=styles["BodyCustom"],
                    alignment=TA_CENTER,
                    textColor=NAVY,
                    leading=13,
                ),
            )
            for index, (number, label) in enumerate(values)
        ]
    ]
    table = Table(cells, colWidths=[40 * mm] * 4, hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), PALE_BLUE),
                ("BOX", (0, 0), (-1, -1), 0.6, LIGHT_GRAY),
                ("INNERGRID", (0, 0), (-1, -1), 0.4, LIGHT_GRAY),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 9),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
            ]
        )
    )
    return table


def _category_summary_table(events: Iterable[TimelineEvent], styles) -> Table:
    counter = Counter(event.category for event in events)
    rows = [
        [
            Paragraph("Categorie", styles["TableHeaderCustom"]),
            Paragraph("Candidats", styles["TableHeaderCustom"]),
            Paragraph("Total", styles["TableHeaderCustom"]),
        ]
    ]
    for category in CATEGORY_ORDER:
        category_events = [event for event in events if event.category == category]
        if not category_events:
            continue
        rows.append(
            [
                Paragraph(_p(CATEGORY_LABELS[category]), styles["TableCellCustom"]),
                Paragraph(
                    str(sum(event.is_ews_candidate for event in category_events)),
                    styles["TableCellCustom"],
                ),
                Paragraph(str(counter[category]), styles["TableCellCustom"]),
            ]
        )
    table = Table(rows, colWidths=[112 * mm, 24 * mm, 20 * mm], repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), NAVY),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, VERY_LIGHT_GRAY]),
                ("GRID", (0, 0), (-1, -1), 0.35, LIGHT_GRAY),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ALIGN", (1, 1), (-1, -1), "CENTER"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    return table


def _timeline_table(events: list[TimelineEvent], styles) -> Table:
    rows = [
        [
            Paragraph("Date", styles["TableHeaderCustom"]),
            Paragraph("Categorie", styles["TableHeaderCustom"]),
            Paragraph("Evenement", styles["TableHeaderCustom"]),
            Paragraph("Niveau", styles["TableHeaderCustom"]),
            Paragraph("Source", styles["TableHeaderCustom"]),
        ]
    ]
    for event in sorted(events, key=_date_sort_key):
        rows.append(
            [
                Paragraph(_p(event.event_date or "Non date"), styles["TableCellCustom"]),
                Paragraph(_p(CATEGORY_LABELS[event.category]), styles["TableCellCustom"]),
                Paragraph(_p(event.title), styles["TableCellCustom"]),
                Paragraph(_p(SEVERITY_LABELS[event.severity]), styles["TableCellCustom"]),
                Paragraph(_p(_source_location(event)), styles["TableCellCustom"]),
            ]
        )
    table = Table(
        rows,
        colWidths=[22 * mm, 36 * mm, 56 * mm, 20 * mm, 35 * mm],
        repeatRows=1,
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), NAVY),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, VERY_LIGHT_GRAY]),
                ("GRID", (0, 0), (-1, -1), 0.3, LIGHT_GRAY),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4.5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4.5),
                ("TOPPADDING", (0, 0), (-1, -1), 4.5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    return table


def _event_flowables(event: TimelineEvent, styles) -> list:
    badge_background = PALE_RED if event.is_ews_candidate else LIGHT_BLUE
    badge_color = RED if event.is_ews_candidate else BLUE
    badge_text = "CANDIDAT EWS - A VALIDER" if event.is_ews_candidate else (
        "STATUT OFFICIEL" if event.is_official_status_marker else "REPERE"
    )
    metadata = (
        f"<b>Date:</b> {_p(event.event_date or 'Non prouvee')} &nbsp;&nbsp; "
        f"<b>Statut:</b> {_p(STATUS_LABELS[event.status])} &nbsp;&nbsp; "
        f"<b>Severite:</b> {_p(SEVERITY_LABELS[event.severity])} &nbsp;&nbsp; "
        f"<b>Confiance extraction:</b> {event.confidence:.0%}"
    )

    header_table = Table(
        [
            [
                Paragraph(_p(event.title), styles["EventTitleCustom"]),
                Paragraph(
                    f"<b>{_p(badge_text)}</b>",
                    ParagraphStyle(
                        name=f"Badge{event.event_id}",
                        parent=styles["SmallCustom"],
                        alignment=TA_CENTER,
                        textColor=badge_color,
                    ),
                ),
            ]
        ],
        colWidths=[122 * mm, 44 * mm],
    )
    header_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (1, 0), (1, 0), badge_background),
                ("BOX", (1, 0), (1, 0), 0.5, badge_color),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (0, 0), 0),
                ("RIGHTPADDING", (0, 0), (0, 0), 6),
                ("LEFTPADDING", (1, 0), (1, 0), 6),
                ("RIGHTPADDING", (1, 0), (1, 0), 6),
                ("TOPPADDING", (1, 0), (1, 0), 4),
                ("BOTTOMPADDING", (1, 0), (1, 0), 4),
            ]
        )
    )

    parts: list = [header_table, Paragraph(metadata, styles["SmallCustom"]), Spacer(1, 3)]
    parts.append(Paragraph(_p(event.description), styles["BodyCustom"]))
    if event.risk_mechanism:
        parts.append(
            Paragraph(
                f"<b>Mecanisme de risque:</b> {_p(event.risk_mechanism)}",
                styles["BodyCustom"],
            )
        )
    if event.rating_before or event.rating_after:
        parts.append(
            Paragraph(
                f"<b>Rating:</b> {_p(event.rating_before or 'n/a')} -> {_p(event.rating_after or 'n/a')}",
                styles["BodyCustom"],
            )
        )
    if event.quantitative_facts:
        facts = "<br/>".join(f"- {_p(fact)}" for fact in event.quantitative_facts)
        parts.append(Paragraph(f"<b>Faits quantitatifs:</b><br/>{facts}", styles["BodyCustom"]))

    evidence_rows = []
    for evidence in event.evidence:
        location = evidence.source_file or "Source"
        if evidence.page_numbers:
            location += " - p. " + ", ".join(map(str, evidence.page_numbers))
        elif evidence.headings:
            location += " - " + " > ".join(evidence.headings)
        evidence_rows.append(
            [
                Paragraph(
                    f"<b>{_p(location)}</b><br/>\"{_p(evidence.quote)}\"",
                    styles["QuoteCustom"],
                )
            ]
        )
    evidence_table = Table(evidence_rows, colWidths=[164 * mm])
    evidence_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), PALE_BLUE),
                ("BOX", (0, 0), (-1, -1), 0.45, LIGHT_GRAY),
                ("INNERGRID", (0, 0), (-1, -1), 0.25, LIGHT_GRAY),
                ("LEFTPADDING", (0, 0), (-1, -1), 7),
                ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    parts.extend(
        [
            Paragraph("<b>Preuves documentaires</b>", styles["SmallCustom"]),
            Spacer(1, 2),
            evidence_table,
            Spacer(1, 7),
            HRFlowable(width="100%", thickness=0.5, color=LIGHT_GRAY),
            Spacer(1, 8),
        ]
    )
    return parts


def generate_pdf_report(
    settings: Settings,
    result: CounterpartyResult,
    output_path: Path | None = None,
) -> Path:
    output_dir = settings.outputs_dir / slugify(result.counterparty)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_path or output_dir / f"{slugify(result.counterparty)}_ews_report.pdf"
    styles = _styles()

    document = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        rightMargin=20 * mm,
        leftMargin=20 * mm,
        topMargin=22 * mm,
        bottomMargin=20 * mm,
        title=f"{settings.report_title} - {result.counterparty}",
        author="PFE EWS local enterprise pipeline",
        subject="Evenements candidats Early Warning Signals",
    )

    story: list = []
    story.append(Spacer(1, 12 * mm))
    story.append(Paragraph(_p(settings.report_title), styles["ReportTitle"]))
    story.append(
        Paragraph(
            f"Contrepartie: <b>{_p(result.counterparty)}</b><br/>"
            f"Generation: {_p(result.generated_at_utc)}<br/>"
            f"Modeles: {_p(result.embedding_model)} / {_p(result.llm_model)}",
            styles["ReportSubtitle"],
        )
    )
    confidentiality = Table(
        [[Paragraph(_p(settings.report_confidentiality_label), styles["CoverLabel"])]],
        colWidths=[168 * mm],
    )
    confidentiality.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), PALE_RED),
                ("BOX", (0, 0), (-1, -1), 0.7, RED),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    story.append(confidentiality)
    story.append(Spacer(1, 10 * mm))
    story.append(_summary_cards(result, styles))
    story.append(Spacer(1, 10 * mm))
    story.append(
        Paragraph(
            "Ce document est un rapport d'aide a l'analyse. Les evenements marques "
            "comme candidats ou suspects ne constituent ni un defaut confirme, ni une "
            "decision de credit. Chaque element doit etre revu avec sa preuve source.",
            styles["BodyCustom"],
        )
    )
    story.append(PageBreak())

    story.append(Paragraph("1. Synthese", styles["H1Custom"]))
    story.append(
        Paragraph(
            f"Le pipeline a consolide <b>{len(result.events)}</b> evenements ou reperes "
            f"a partir de <b>{len(result.source_documents)}</b> documents sources. "
            f"<b>{sum(event.is_ews_candidate for event in result.events)}</b> elements "
            "sont classes candidats EWS et necessitent une validation humaine.",
            styles["BodyCustom"],
        )
    )
    if result.events:
        story.append(_category_summary_table(result.events, styles))
    else:
        story.append(
            Paragraph(
                "Aucun evenement n'a passe les controles de preuve et de validation.",
                styles["BodyCustom"],
            )
        )

    candidate_events = [event for event in result.events if event.is_ews_candidate]
    story.append(Spacer(1, 8))
    story.append(Paragraph("2. Timeline des candidats EWS", styles["H1Custom"]))
    if candidate_events:
        story.append(_timeline_table(candidate_events, styles))
    else:
        story.append(
            Paragraph("Aucun candidat EWS valide pour cette contrepartie.", styles["BodyCustom"])
        )

    story.append(PageBreak())
    story.append(Paragraph("3. Evenements candidats par categorie", styles["H1Custom"]))
    candidate_by_category: dict[str, list[TimelineEvent]] = defaultdict(list)
    for event in candidate_events:
        candidate_by_category[event.category].append(event)
    for category in CATEGORY_ORDER:
        events = candidate_by_category.get(category, [])
        if not events:
            continue
        story.append(
            Paragraph(
                f"{_p(CATEGORY_LABELS[category])} ({len(events)})",
                styles["H2Custom"],
            )
        )
        for event in sorted(events, key=_date_sort_key):
            story.extend(_event_flowables(event, styles))

    markers = [
        event
        for event in result.events
        if event.is_official_status_marker or event.category == "internal_rating"
    ]
    story.append(PageBreak())
    story.append(Paragraph("4. Reperes officiels et rating", styles["H1Custom"]))
    story.append(
        Paragraph(
            "Ces elements sont importants pour positionner la trajectoire temporelle, "
            "mais ils ne sont pas consideres comme de nouveaux candidats EWS par les regles metier.",
            styles["BodyCustom"],
        )
    )
    if markers:
        for category in CATEGORY_ORDER:
            category_markers = [item for item in markers if item.category == category]
            if not category_markers:
                continue
            story.append(Paragraph(_p(CATEGORY_LABELS[category]), styles["H2Custom"]))
            for event in sorted(category_markers, key=_date_sort_key):
                story.extend(_event_flowables(event, styles))
    else:
        story.append(
            Paragraph("Aucun statut officiel ou mouvement de rating extrait.", styles["BodyCustom"])
        )

    other_non_candidates = [
        event
        for event in result.events
        if not event.is_ews_candidate
        and not event.is_official_status_marker
        and event.category != "internal_rating"
    ]
    if other_non_candidates:
        story.append(PageBreak())
        story.append(Paragraph("5. Autres faits non candidats", styles["H1Custom"]))
        for event in other_non_candidates:
            story.extend(_event_flowables(event, styles))

    story.append(PageBreak())
    story.append(Paragraph("Annexe - Methode et limites", styles["H1Custom"]))
    methodology = [
        "Preparation locale des fichiers: PDF conserves; Word convertis en PDF avec LibreOffice; Excel analyses directement.",
        "Extraction Docling locale avec reconnaissance de structure de tableaux TableFormer Accurate.",
        "Chunking structurel Docling HybridChunker avec repetition des en-tetes de tableaux.",
        "Embeddings calcules via le modele interne configure; vecteurs stockes dans Qdrant embarque local ou NumPy local.",
        "Retrieval hybride: recherche dense + BM25 local, fusionnee par Reciprocal Rank Fusion.",
        "Extraction LLM interne en JSON structure, validation des chunk_id et des citations, puis deduplication.",
    ]
    story.append(
        Paragraph(
            "<br/>".join(f"- {_p(item)}" for item in methodology),
            styles["BodyCustom"],
        )
    )
    story.append(Paragraph("Limites", styles["H2Custom"]))
    story.append(
        Paragraph(
            "La qualite depend de l'extraction du document, du recall du retrieval et de "
            "l'interpretation du LLM. Les citations valides prouvent la presence textuelle "
            "du fait, mais pas necessairement sa materialite credit. Les fichiers Excel avec "
            "formules non recalculees peuvent contenir des caches obsoletes. Les dates absentes "
            "ne sont pas inferees. Une revue analyste reste obligatoire.",
            styles["BodyCustom"],
        )
    )
    if result.extraction_notes:
        story.append(Paragraph("Notes techniques", styles["H2Custom"]))
        story.append(
            Paragraph(
                "<br/>".join(f"- {_p(note)}" for note in result.extraction_notes),
                styles["SmallCustom"],
            )
        )

    document.build(
        story,
        onFirstPage=lambda canvas, doc: _header_footer(
            canvas, doc, settings, result.counterparty
        ),
        onLaterPages=lambda canvas, doc: _header_footer(
            canvas, doc, settings, result.counterparty
        ),
    )
    return output_path

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from pfe_ews.config import Settings
from pfe_ews.excel_audit import audit_excel_workbook
from pfe_ews.io_utils import read_jsonl, slugify, write_jsonl

LOGGER = logging.getLogger(__name__)


def _build_converter(settings: Settings):
    try:
        from docling.datamodel.base_models import InputFormat
        from docling.datamodel.pipeline_options import (
            EasyOcrOptions,
            PdfPipelineOptions,
            TableFormerMode,
        )
        from docling.document_converter import DocumentConverter, PdfFormatOption
    except ImportError as exc:
        raise RuntimeError(
            "Docling n'est pas installe. Installez requirements.txt depuis le miroir interne."
        ) from exc

    kwargs: dict[str, Any] = {}
    if settings.docling_artifacts_path:
        kwargs["artifacts_path"] = settings.docling_artifacts_path
    try:
        pipeline_options = PdfPipelineOptions(**kwargs)
    except TypeError:
        pipeline_options = PdfPipelineOptions()
        if settings.docling_artifacts_path and hasattr(
            pipeline_options, "artifacts_path"
        ):
            pipeline_options.artifacts_path = settings.docling_artifacts_path

    pipeline_options.do_ocr = settings.docling_ocr_enabled
    pipeline_options.do_table_structure = True
    if hasattr(pipeline_options, "enable_remote_services"):
        pipeline_options.enable_remote_services = False

    try:
        pipeline_options.ocr_options = EasyOcrOptions(
            lang=list(settings.docling_ocr_languages),
            force_full_page_ocr=settings.docling_force_full_page_ocr,
        )
    except TypeError:
        pipeline_options.ocr_options = EasyOcrOptions(
            lang=list(settings.docling_ocr_languages)
        )
        if hasattr(pipeline_options.ocr_options, "force_full_page_ocr"):
            pipeline_options.ocr_options.force_full_page_ocr = (
                settings.docling_force_full_page_ocr
            )

    pipeline_options.table_structure_options.mode = TableFormerMode.ACCURATE
    pipeline_options.table_structure_options.do_cell_matching = (
        settings.docling_do_cell_matching
    )

    return DocumentConverter(
        format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
        }
    )


def _safe_count(document: Any, attribute: str) -> int:
    value = getattr(document, attribute, None)
    if value is None:
        return 0
    try:
        return len(value)
    except TypeError:
        return 0


def extract_documents(settings: Settings) -> list[dict[str, Any]]:
    settings.ensure_directories()
    prepared_manifest = settings.prepared_dir / "prepared_manifest.jsonl"
    if not prepared_manifest.exists():
        raise FileNotFoundError(
            "Le manifest prepare est absent. Executez d'abord scripts/01_prepare_documents.py."
        )

    rows = [
        row
        for row in read_jsonl(prepared_manifest)
        if row.get("status") == "success"
    ]
    if not rows:
        raise ValueError("Aucun document prepare avec succes.")

    converter = _build_converter(settings)
    extraction_rows: list[dict[str, Any]] = []

    for prepared in rows:
        prepared_path = Path(str(prepared["prepared_path"]))
        counterparty_slug = slugify(str(prepared["counterparty"]))
        output_dir = settings.extracted_dir / counterparty_slug
        output_dir.mkdir(parents=True, exist_ok=True)
        base_name = f"{prepared['document_id']}__{slugify(str(prepared['source_file']))}"
        json_path = output_dir / f"{base_name}.docling.json"
        markdown_path = output_dir / f"{base_name}.md"
        html_path = output_dir / f"{base_name}.html"
        excel_audit_path = output_dir / f"{base_name}.excel_audit.json"

        record: dict[str, Any] = {
            **prepared,
            "docling_json": str(json_path.resolve()),
            "markdown": str(markdown_path.resolve()),
            "html": str(html_path.resolve()),
            "excel_audit": None,
            "extraction_status": "pending",
            "extraction_seconds": None,
            "num_pages": 0,
            "num_tables": 0,
            "num_text_items": 0,
            "error": None,
        }

        if (
            not settings.force_reextract
            and json_path.exists()
            and markdown_path.exists()
            and html_path.exists()
        ):
            record["extraction_status"] = "skipped_existing"
            extraction_rows.append(record)
            LOGGER.info("Extraction deja presente: %s", prepared_path.name)
            continue

        started = time.perf_counter()
        try:
            result = converter.convert(
                prepared_path,
                raises_on_error=True,
                max_num_pages=settings.docling_max_num_pages,
                max_file_size=settings.docling_max_file_size_mb * 1024 * 1024,
            )
            document = result.document
            doc_dict = document.export_to_dict()
            json_path.write_text(
                json.dumps(doc_dict, ensure_ascii=False, indent=2, default=str),
                encoding="utf-8",
            )
            markdown_path.write_text(
                document.export_to_markdown(), encoding="utf-8"
            )
            html_path.write_text(document.export_to_html(), encoding="utf-8")

            if prepared_path.suffix.lower() in {".xlsx", ".xlsm"}:
                audit_excel_workbook(prepared_path, excel_audit_path)
                record["excel_audit"] = str(excel_audit_path.resolve())

            record.update(
                {
                    "extraction_status": "success",
                    "extraction_seconds": round(time.perf_counter() - started, 3),
                    "num_pages": _safe_count(document, "pages"),
                    "num_tables": _safe_count(document, "tables"),
                    "num_text_items": _safe_count(document, "texts"),
                    "markdown_characters": markdown_path.stat().st_size,
                }
            )
            LOGGER.info(
                "Docling: %s | pages=%s | tables=%s | %.1fs",
                prepared["source_file"],
                record["num_pages"],
                record["num_tables"],
                record["extraction_seconds"],
            )
        except Exception as exc:
            LOGGER.exception("Echec Docling: %s", prepared_path)
            record.update(
                {
                    "extraction_status": "error",
                    "extraction_seconds": round(time.perf_counter() - started, 3),
                    "error": str(exc),
                }
            )
        extraction_rows.append(record)

    manifest_path = settings.extracted_dir / "extraction_manifest.jsonl"
    write_jsonl(manifest_path, extraction_rows)
    return extraction_rows

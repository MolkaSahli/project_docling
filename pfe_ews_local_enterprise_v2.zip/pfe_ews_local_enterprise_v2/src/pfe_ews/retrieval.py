from __future__ import annotations

import logging
from typing import Any

from pfe_ews.config import Settings
from pfe_ews.io_utils import read_jsonl
from pfe_ews.lexical_bm25 import BM25Index
from pfe_ews.queries import RETRIEVAL_TASKS, RetrievalTask
from pfe_ews.vector_store import LocalDenseStore

LOGGER = logging.getLogger(__name__)


class HybridRetriever:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.dense_store = LocalDenseStore(settings)
        chunks_path = settings.index_dir / "indexed_chunks.jsonl"
        self.chunks = list(read_jsonl(chunks_path))
        self.lexical_index = BM25Index(self.chunks)

    @property
    def counterparties(self) -> list[str]:
        return self.dense_store.counterparties

    def close(self) -> None:
        self.dense_store.close()

    def search(
        self,
        query: str,
        *,
        counterparty: str,
        final_top_k: int | None = None,
    ) -> list[dict[str, Any]]:
        dense = self.dense_store.search(
            query,
            top_k=self.settings.retrieval_dense_top_k,
            counterparty=counterparty,
        )
        lexical = self.lexical_index.search(
            query,
            top_k=self.settings.retrieval_lexical_top_k,
            counterparty=counterparty,
        )

        merged: dict[str, dict[str, Any]] = {}
        rrf_k = self.settings.rrf_k
        for modality, hits in (("dense", dense), ("lexical", lexical)):
            for rank, hit in enumerate(hits, start=1):
                chunk_id = str(hit["chunk_id"])
                entry = merged.setdefault(
                    chunk_id,
                    {
                        **hit,
                        "rrf_score": 0.0,
                        "dense_score": None,
                        "lexical_score": None,
                        "matched_modalities": [],
                        "dense_rank": None,
                        "lexical_rank": None,
                    },
                )
                entry["rrf_score"] += 1.0 / (rrf_k + rank)
                entry["matched_modalities"].append(modality)
                entry[f"{modality}_rank"] = rank
                if modality == "dense":
                    entry["dense_score"] = hit.get("dense_score")
                else:
                    entry["lexical_score"] = hit.get("lexical_score")

        ranked = sorted(
            merged.values(),
            key=lambda item: (
                float(item["rrf_score"]),
                float(item["dense_score"] or float("-inf")),
            ),
            reverse=True,
        )
        return ranked[: (final_top_k or self.settings.retrieval_final_top_k)]

    def retrieve_task(
        self, task: RetrievalTask, *, counterparty: str
    ) -> list[dict[str, Any]]:
        hits = self.search(
            task.query,
            counterparty=counterparty,
            final_top_k=self.settings.max_retrieved_chunks_per_task,
        )
        for hit in hits:
            hit["retrieval_task_id"] = task.task_id
            hit["retrieval_task_title"] = task.title
            hit["expected_categories"] = list(task.expected_categories)
        return hits

    def retrieve_all_tasks(
        self, *, counterparty: str
    ) -> dict[str, list[dict[str, Any]]]:
        result: dict[str, list[dict[str, Any]]] = {}
        for task in RETRIEVAL_TASKS:
            LOGGER.info("Retrieval %s / %s", counterparty, task.task_id)
            result[task.task_id] = self.retrieve_task(
                task, counterparty=counterparty
            )
        return result

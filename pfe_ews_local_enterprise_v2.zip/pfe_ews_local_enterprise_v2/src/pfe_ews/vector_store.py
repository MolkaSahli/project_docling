from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import Any

import numpy as np

from pfe_ews.config import Settings
from pfe_ews.embedding_profiles import model_choice_explanation, passage_text, query_text
from pfe_ews.enterprise_api import EnterpriseEmbeddingClient
from pfe_ews.io_utils import read_json, read_jsonl, write_json

LOGGER = logging.getLogger(__name__)


def _qdrant_point_id(chunk_id: str) -> str:
    raw = (chunk_id.replace("-", "") + "0" * 32)[:32]
    return str(uuid.UUID(hex=raw))


def _qdrant_available() -> bool:
    try:
        import qdrant_client  # noqa: F401
    except ImportError:
        return False
    return True


def _collection_exists(client: Any, collection_name: str) -> bool:
    if hasattr(client, "collection_exists"):
        return bool(client.collection_exists(collection_name=collection_name))
    collections = client.get_collections().collections
    return any(item.name == collection_name for item in collections)


def _build_qdrant(
    settings: Settings,
    chunks: list[dict[str, Any]],
    embeddings: np.ndarray,
) -> None:
    from qdrant_client import QdrantClient, models

    settings.qdrant_local_path.mkdir(parents=True, exist_ok=True)
    client = QdrantClient(path=str(settings.qdrant_local_path))
    try:
        if _collection_exists(client, settings.qdrant_collection):
            client.delete_collection(collection_name=settings.qdrant_collection)
        client.create_collection(
            collection_name=settings.qdrant_collection,
            vectors_config=models.VectorParams(
                size=int(embeddings.shape[1]),
                distance=models.Distance.COSINE,
            ),
        )

        batch_size = 128
        for start in range(0, len(chunks), batch_size):
            batch_chunks = chunks[start : start + batch_size]
            batch_vectors = embeddings[start : start + batch_size]
            points = []
            for chunk, vector in zip(batch_chunks, batch_vectors, strict=True):
                payload = {
                    "chunk_id": chunk["chunk_id"],
                    "document_id": chunk["document_id"],
                    "counterparty": chunk["counterparty"],
                    "source_file": chunk["source_file"],
                    "source_path": chunk.get("source_path"),
                    "prepared_path": chunk.get("prepared_path"),
                    "source_extension": chunk.get("source_extension"),
                    "prepared_extension": chunk.get("prepared_extension"),
                    "document_type": chunk.get("document_type"),
                    "chunk_index": chunk["chunk_index"],
                    "text": chunk["text"],
                    "raw_text": chunk.get("raw_text", ""),
                    "page_numbers": chunk.get("page_numbers", []),
                    "headings": chunk.get("headings", []),
                    "labels": chunk.get("labels", []),
                    "is_table": bool(chunk.get("is_table")),
                    "estimated_token_count": chunk.get("estimated_token_count"),
                }
                points.append(
                    models.PointStruct(
                        id=_qdrant_point_id(chunk["chunk_id"]),
                        vector=vector.tolist(),
                        payload=payload,
                    )
                )
            client.upsert(
                collection_name=settings.qdrant_collection,
                points=points,
                wait=True,
            )
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()


def build_local_vector_index(settings: Settings) -> dict[str, Any]:
    settings.ensure_directories()
    chunks_path = settings.chunks_dir / "chunks.jsonl"
    if not chunks_path.exists():
        raise FileNotFoundError(
            "Les chunks sont absents. Executez scripts/03_chunk_documents.py."
        )
    chunks = list(read_jsonl(chunks_path))
    if settings.target_counterparty:
        chunks = [
            row
            for row in chunks
            if row.get("counterparty") == settings.target_counterparty
        ]
    if not chunks:
        raise ValueError("Aucun chunk a indexer.")

    texts = [passage_text(settings, str(chunk["text"])) for chunk in chunks]
    embedding_client = EnterpriseEmbeddingClient(settings)
    embeddings = embedding_client.embed_batched(texts)
    if embeddings.shape[0] != len(chunks):
        raise ValueError("Nombre d'embeddings different du nombre de chunks.")

    embeddings_path = settings.index_dir / "embeddings.npy"
    indexed_chunks_path = settings.index_dir / "indexed_chunks.jsonl"
    from pfe_ews.io_utils import write_jsonl

    write_jsonl(indexed_chunks_path, chunks)

    requested_backend = settings.vector_store_backend
    actual_backend = requested_backend
    fallback_reason: str | None = None
    if requested_backend == "qdrant_local":
        if not _qdrant_available():
            if not settings.allow_numpy_fallback:
                raise RuntimeError(
                    "qdrant-client est absent et ALLOW_NUMPY_FALLBACK=false."
                )
            actual_backend = "numpy"
            fallback_reason = "qdrant-client non installe"
            LOGGER.warning("Qdrant indisponible; repli sur NumPy local.")
        else:
            try:
                _build_qdrant(settings, chunks, embeddings)
            except Exception as exc:
                if not settings.allow_numpy_fallback:
                    raise
                actual_backend = "numpy"
                fallback_reason = f"Qdrant local a echoue: {exc}"
                LOGGER.exception("Qdrant local a echoue; repli sur NumPy.")

    if actual_backend == "numpy" or settings.save_embeddings_copy:
        np.save(embeddings_path, embeddings.astype(np.float32))
    elif embeddings_path.exists():
        embeddings_path.unlink()

    metadata = {
        "requested_backend": requested_backend,
        "actual_backend": actual_backend,
        "fallback_reason": fallback_reason,
        "embedding": model_choice_explanation(settings.embedding_model),
        "embedding_model": settings.embedding_model,
        "chunk_count": len(chunks),
        "dimension": int(embeddings.shape[1]),
        "normalized": True,
        "distance": "cosine",
        "chunks_path": str(indexed_chunks_path.resolve()),
        "embeddings_path": (
            str(embeddings_path.resolve()) if embeddings_path.exists() else None
        ),
        "qdrant_local_path": str(settings.qdrant_local_path.resolve()),
        "qdrant_collection": settings.qdrant_collection,
        "external_vector_database_used": False,
    }
    write_json(settings.index_dir / "index_meta.json", metadata)
    return metadata


class LocalDenseStore:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        meta_path = settings.index_dir / "index_meta.json"
        chunks_path = settings.index_dir / "indexed_chunks.jsonl"
        if not meta_path.exists() or not chunks_path.exists():
            raise FileNotFoundError(
                "Index local incomplet. Executez scripts/04_build_local_vector_db.py."
            )
        self.meta = read_json(meta_path)
        self.chunks = list(read_jsonl(chunks_path))
        if self.meta.get("embedding_model") != settings.embedding_model:
            raise ValueError(
                "EMBEDDING_MODEL differe du modele utilise pour l'index. "
                "Reconstruisez l'index."
            )
        self.backend = str(self.meta["actual_backend"])
        self.embedding_client = EnterpriseEmbeddingClient(settings)
        self._chunk_by_id = {row["chunk_id"]: row for row in self.chunks}
        self._embeddings: np.ndarray | None = None
        self._qdrant_client: Any = None

        if self.backend == "numpy":
            self._embeddings = np.load(
                settings.index_dir / "embeddings.npy", mmap_mode="r"
            )
            if self._embeddings.shape[0] != len(self.chunks):
                raise ValueError("Index NumPy et chunks non synchronises.")
        elif self.backend == "qdrant_local":
            from qdrant_client import QdrantClient

            self._qdrant_client = QdrantClient(
                path=str(settings.qdrant_local_path)
            )
        else:
            raise ValueError(f"Backend inconnu: {self.backend}")

    @property
    def counterparties(self) -> list[str]:
        return sorted({str(row["counterparty"]) for row in self.chunks})

    def close(self) -> None:
        if self._qdrant_client is not None:
            close = getattr(self._qdrant_client, "close", None)
            if callable(close):
                close()

    def _search_numpy(
        self, query_vector: np.ndarray, counterparty: str | None, top_k: int
    ) -> list[dict[str, Any]]:
        assert self._embeddings is not None
        candidates = [
            index
            for index, chunk in enumerate(self.chunks)
            if counterparty is None or chunk["counterparty"] == counterparty
        ]
        if not candidates:
            return []
        candidate_array = np.asarray(candidates, dtype=np.int64)
        scores = self._embeddings[candidate_array] @ query_vector
        count = min(top_k, len(candidates))
        order = np.argsort(scores)[::-1][:count]
        return [
            {
                **self.chunks[int(candidate_array[int(local_index)])],
                "dense_score": float(scores[int(local_index)]),
            }
            for local_index in order
        ]

    def _search_qdrant(
        self, query_vector: np.ndarray, counterparty: str | None, top_k: int
    ) -> list[dict[str, Any]]:
        from qdrant_client import models

        query_filter = None
        if counterparty is not None:
            query_filter = models.Filter(
                must=[
                    models.FieldCondition(
                        key="counterparty",
                        match=models.MatchValue(value=counterparty),
                    )
                ]
            )
        client = self._qdrant_client
        try:
            response = client.query_points(
                collection_name=self.settings.qdrant_collection,
                query=query_vector.tolist(),
                query_filter=query_filter,
                limit=top_k,
                with_payload=True,
            )
            points = response.points
        except AttributeError:
            points = client.search(
                collection_name=self.settings.qdrant_collection,
                query_vector=query_vector.tolist(),
                query_filter=query_filter,
                limit=top_k,
                with_payload=True,
            )

        results: list[dict[str, Any]] = []
        for point in points:
            payload = dict(point.payload or {})
            chunk = self._chunk_by_id.get(str(payload.get("chunk_id")), payload)
            results.append({**chunk, "dense_score": float(point.score)})
        return results

    def search(
        self,
        query: str,
        *,
        top_k: int,
        counterparty: str | None = None,
    ) -> list[dict[str, Any]]:
        prepared_query = query_text(self.settings, query)
        matrix = self.embedding_client.embed([prepared_query])
        query_vector = matrix[0]
        if self.backend == "numpy":
            return self._search_numpy(query_vector, counterparty, top_k)
        return self._search_qdrant(query_vector, counterparty, top_k)

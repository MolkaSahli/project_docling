from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pfe_ews.config import Settings
from pfe_ews.queries import RetrievalTask


OUTPUT_SCHEMA_EXAMPLE = {
    "counterparty": "NOM_CONTREPARTIE",
    "task_id": "financials",
    "events": [
        {
            "event_id": None,
            "event_date": "2025-Q1",
            "date_precision": "quarter",
            "category": "financials",
            "subcategory": "liquidity",
            "title": "Pression sur la liquidite",
            "description": "La liquidite disponible a diminue au premier trimestre.",
            "risk_mechanism": "La baisse de liquidite reduit le coussin disponible pour les echeances court terme.",
            "direction": "negative",
            "status": "occurred",
            "severity": "medium",
            "is_ews_candidate": True,
            "is_official_status_marker": False,
            "rating_before": None,
            "rating_after": None,
            "quantitative_facts": ["Cash decreased from EUR 25m to EUR 14m"],
            "evidence": [
                {
                    "source_chunk_id": "CHUNK_ID_EXACT",
                    "quote": "Cash decreased from EUR 25m to EUR 14m.",
                    "source_file": None,
                    "page_numbers": [],
                    "headings": [],
                    "validation_score": None,
                }
            ],
            "confidence": 0.9,
            "source_task_id": "financials",
            "validation_notes": [],
        }
    ],
    "extraction_notes": [],
}


def load_system_prompt(settings: Settings) -> str:
    path = settings.project_root / "prompts" / "ews_system_prompt.txt"
    return path.read_text(encoding="utf-8")


def build_extraction_prompt(
    *,
    counterparty: str,
    task: RetrievalTask,
    chunks: list[dict[str, Any]],
) -> str:
    context_blocks: list[str] = []
    for rank, chunk in enumerate(chunks, start=1):
        metadata = {
            "rank": rank,
            "chunk_id": chunk["chunk_id"],
            "source_file": chunk["source_file"],
            "document_type": chunk.get("document_type"),
            "page_numbers": chunk.get("page_numbers", []),
            "headings": chunk.get("headings", []),
            "is_table": bool(chunk.get("is_table")),
            "rrf_score": round(float(chunk.get("rrf_score", 0.0)), 8),
        }
        context_blocks.append(
            "METADATA\n"
            + json.dumps(metadata, ensure_ascii=False)
            + "\nCONTENT\n"
            + str(chunk["text"])
        )

    return f"""
CONTREPARTIE: {counterparty}
TACHE: {task.task_id} - {task.title}
CATEGORIES PRINCIPALEMENT ATTENDUES: {', '.join(task.expected_categories)}

Extrais uniquement les evenements pertinents pour cette tache. Une sortie vide est correcte si aucune preuve suffisante n'est presente.

Le JSON doit respecter exactement cette structure et ces valeurs enumerees:
{json.dumps(OUTPUT_SCHEMA_EXAMPLE, ensure_ascii=False, indent=2)}

Valeurs autorisees:
- category: events, governance_geopolitical_eis, financials, esg, covenant_fbe, corporate_leverage, internal_rating, utp, grey_list, watchlist, npe, pd_100, new_potential_risk_driver
- date_precision: day, month, quarter, year, period, unknown
- direction: negative, positive, mixed, neutral, unknown
- status: occurred, ongoing, expected, planned, resolved, rumor, unknown
- severity: low, medium, high, critical, unknown

Rappels:
- counterparty doit etre exactement {counterparty!r}.
- task_id doit etre exactement {task.task_id!r}.
- source_task_id de chaque evenement doit etre {task.task_id!r}.
- source_chunk_id doit correspondre exactement a un identifiant ci-dessous.
- quote doit etre une courte citation reellement presente dans ce chunk.
- Ne duplique pas un meme fait dans ce lot.

CHUNKS FOURNIS
================
{chr(10).join(chr(10) + block + chr(10) + '----------------' for block in context_blocks)}
""".strip()


def build_json_repair_prompt(
    *, raw_output: str, validation_error: str, counterparty: str, task_id: str
) -> str:
    return f"""
Corrige la sortie ci-dessous pour produire uniquement un objet JSON valide conforme au schema demande. Ne cree aucun nouvel evenement et ne change aucun fait. Corrige seulement la syntaxe, les champs manquants et les valeurs enumerees.

counterparty attendu: {counterparty}
task_id attendu: {task_id}

ERREUR DE VALIDATION
{validation_error}

SORTIE A CORRIGER
{raw_output}
""".strip()

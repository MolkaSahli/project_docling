from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RetrievalTask:
    task_id: str
    title: str
    query: str
    expected_categories: tuple[str, ...]


RETRIEVAL_TASKS: tuple[RetrievalTask, ...] = (
    RetrievalTask(
        task_id="financials",
        title="Performance financiere et liquidite",
        query=(
            "degradation financiere, baisse du chiffre d'affaires, EBITDA, marge, "
            "rentabilite, pertes, cash-flow, liquidite, tresorerie, working capital, "
            "financial deterioration, revenue decline, EBITDA decline, margin pressure, "
            "cash flow deterioration, liquidity pressure, delayed payment"
        ),
        expected_categories=("financials", "new_potential_risk_driver"),
    ),
    RetrievalTask(
        task_id="covenant_fbe",
        title="Covenants et FBE",
        query=(
            "covenant breach, covenant headroom, waiver, financial breach event, FBE, "
            "non-respect covenant, faible marge de securite, DSCR, ICR, Net Debt EBITDA"
        ),
        expected_categories=("covenant_fbe",),
    ),
    RetrievalTask(
        task_id="corporate_leverage",
        title="Endettement et refinancement",
        query=(
            "corporate leverage, hausse de la dette, net debt, debt maturity, refinancing, "
            "refinancement, maturite de dette, bullet repayment, interest burden, "
            "acquisition finance, shareholder distribution, dividend, debt service"
        ),
        expected_categories=("corporate_leverage", "new_potential_risk_driver"),
    ),
    RetrievalTask(
        task_id="governance_geopolitical_eis",
        title="Gouvernance, geopolitique et EIS",
        query=(
            "governance issue, management departure, CEO CFO change, shareholder conflict, "
            "fraud, litigation, sanctions, geopolitical risk, country risk, war, strike, "
            "supply disruption, EIS, gouvernance, conflit actionnarial, depart dirigeant"
        ),
        expected_categories=("governance_geopolitical_eis", "events"),
    ),
    RetrievalTask(
        task_id="esg",
        title="ESG",
        query=(
            "ESG incident, environmental fine, pollution, climate transition risk, social "
            "controversy, health and safety, governance controversy, human rights, "
            "incident environnemental, social, securite, amende"
        ),
        expected_categories=("esg",),
    ),
    RetrievalTask(
        task_id="operational_legal_events",
        title="Evenements operationnels, commerciaux et juridiques",
        query=(
            "loss of key customer, contract termination, plant closure, production issue, "
            "cyber incident, legal dispute, tax dispute, restructuring, insolvency of client, "
            "perte client, rupture contrat, fermeture site, incident operationnel, litige"
        ),
        expected_categories=("events", "new_potential_risk_driver"),
    ),
    RetrievalTask(
        task_id="rating",
        title="Rating interne",
        query=(
            "internal rating, rating migration, downgrade, upgrade, note interne, "
            "degradation rating, changement de notation, grade, probability of default"
        ),
        expected_categories=("internal_rating",),
    ),
    RetrievalTask(
        task_id="official_status",
        title="Statuts officiels de risque",
        query=(
            "UTP, unlikely to pay, Grey list, gray list, Watchlist, WL, NPE, "
            "non-performing exposure, PD=100%, PD 100%, forbearance, statut officiel"
        ),
        expected_categories=(
            "utp",
            "grey_list",
            "watchlist",
            "npe",
            "pd_100",
        ),
    ),
    RetrievalTask(
        task_id="forward_looking",
        title="Facteurs de risque futurs et alertes potentielles",
        query=(
            "expected deterioration, forecast decline, downside scenario, risk outlook, "
            "limited headroom, upcoming maturity, potential risk, early warning, concern, "
            "degradation attendue, risque futur, alerte potentielle, prevision defavorable"
        ),
        expected_categories=("new_potential_risk_driver",),
    ),
)


def task_by_id(task_id: str) -> RetrievalTask:
    for task in RETRIEVAL_TASKS:
        if task.task_id == task_id:
            return task
    raise KeyError(task_id)

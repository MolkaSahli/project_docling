from __future__ import annotations

from dataclasses import dataclass

from pfe_ews.config import Settings


@dataclass(frozen=True, slots=True)
class EmbeddingProfile:
    family: str
    expected_dimension: int | None
    context_tokens: int | None
    multilingual: bool
    query_prefix: str = ""
    passage_prefix: str = ""
    default_query_instruction: str = ""
    note: str = ""


PROFILES: tuple[tuple[str, EmbeddingProfile], ...] = (
    (
        "qwen3-embedding-8b",
        EmbeddingProfile(
            family="qwen3_embedding",
            expected_dimension=4096,
            context_tokens=32768,
            multilingual=True,
            default_query_instruction=(
                "Given a credit-risk retrieval query, retrieve passages that contain "
                "factual evidence about financial deterioration, governance, ESG, "
                "covenants, leverage, ratings or official risk status."
            ),
            note="Mode qualite; plus lourd et vecteurs plus volumineux.",
        ),
    ),
    (
        "bge-m3",
        EmbeddingProfile(
            family="bge_m3",
            expected_dimension=1024,
            context_tokens=8192,
            multilingual=True,
            note="Choix par defaut: multilingue, 8K et efficace pour FR/EN.",
        ),
    ),
    (
        "multilingual-e5-large",
        EmbeddingProfile(
            family="multilingual_e5",
            expected_dimension=1024,
            context_tokens=512,
            multilingual=True,
            query_prefix="query: ",
            passage_prefix="passage: ",
            note="Bonne baseline multilingue, mais contexte limite a 512 tokens.",
        ),
    ),
    (
        "bge-large-en-v1.5",
        EmbeddingProfile(
            family="bge_large_en",
            expected_dimension=1024,
            context_tokens=512,
            multilingual=False,
            note="A reserver aux corpus strictement anglais.",
        ),
    ),
)


def profile_for(model_name: str) -> EmbeddingProfile:
    lowered = model_name.lower()
    for marker, profile in PROFILES:
        if marker in lowered:
            return profile
    return EmbeddingProfile(
        family="generic",
        expected_dimension=None,
        context_tokens=None,
        multilingual=True,
        note="Profil generique: verifier les exigences du modele avec l'equipe plateforme.",
    )


def passage_text(settings: Settings, text: str) -> str:
    profile = profile_for(settings.embedding_model)
    prefix = settings.embedding_passage_prefix or profile.passage_prefix
    return f"{prefix}{text}" if prefix else text


def query_text(settings: Settings, text: str) -> str:
    profile = profile_for(settings.embedding_model)
    prefix = settings.embedding_query_prefix or profile.query_prefix
    instruction = (
        settings.embedding_query_instruction or profile.default_query_instruction
    )
    if profile.family == "qwen3_embedding" and instruction:
        return f"Instruct: {instruction}\nQuery: {text}"
    return f"{prefix}{text}" if prefix else text


def model_choice_explanation(model_name: str) -> dict[str, object]:
    profile = profile_for(model_name)
    return {
        "model": model_name,
        "family": profile.family,
        "expected_dimension": profile.expected_dimension,
        "context_tokens": profile.context_tokens,
        "multilingual": profile.multilingual,
        "note": profile.note,
    }

"""Pipeline local et auditable d'extraction de candidats EWS."""

__version__ = "0.2.0"

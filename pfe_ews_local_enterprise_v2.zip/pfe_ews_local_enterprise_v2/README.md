# PFE EWS — pipeline local Docling + RAG hybride + LLM interne

Ce projet transforme plusieurs documents d'une contrepartie en un **rapport PDF d'evenements candidats Early Warning Signals**, avec preuves, categories et sources.

Il accepte :

- PDF ;
- Word (`.docx`, `.doc`) : conversion locale obligatoire en PDF avec LibreOffice par defaut ; un repli direct Docling peut etre active explicitement ;
- Excel (`.xlsx`, `.xlsm`, `.xls`) : extraction directe par Docling, audit des feuilles par `openpyxl`, conversion locale des anciens `.xls` ;
- CSV.

Aucune base vectorielle externe n'est appelee. Les vecteurs sont stockes soit dans **Qdrant embarque localement dans le processus Python**, soit dans des fichiers NumPy locaux.

## 1. Architecture

```text
Documents de plusieurs contreparties
        |
        v
01_prepare_documents.py
PDF copies | Word -> PDF | XLS -> XLSX
        |
        v
02_extract_with_docling.py
Docling local + TableFormer Accurate + OCR local
        |
        +--> JSON Docling structurel
        +--> Markdown de controle
        +--> HTML de controle des tableaux fusionnes
        |
        v
03_chunk_documents.py
Docling HybridChunker + en-tetes de tableaux repetes
        |
        v
04_build_local_vector_db.py
Embeddings via modele interne
        |
        +--> Qdrant embedded local (par defaut)
        +--> embeddings.npy (copie/repli)
        |
        v
05_test_retrieval.py
Dense + BM25 local + Reciprocal Rank Fusion
        |
        v
06_extract_ews_events.py
LLM interne -> JSON structure -> preuves -> validation -> deduplication
        |
        v
07_generate_pdf_reports.py
Rapport PDF par contrepartie
```

## 2. Choix par defaut

### Embeddings : `bge-m3-ITG`

C'est le choix de depart parce que le corpus est francais/anglais, que les chunks contiennent du texte et des tableaux, et que son contexte de 8K est largement suffisant pour des chunks de 700 tokens. Ses vecteurs de 1024 dimensions restent moins lourds que les vecteurs jusqu'a 4096 dimensions de `qwen3-embedding-8b`.

`qwen3-embedding-8b` reste une excellente configuration de comparaison en mode qualite. Le choix final doit etre fait avec votre **Recall@5 / Recall@10** sur des evenements bancaires annotes.

### LLM : `mistral-medium-2508-ITG`

C'est une hypothese de travail equilibree pour l'extraction structuree FR/EN : plus robuste qu'un petit modele attendu, mais moins couteux qu'un tres grand modele tel que `gpt-oss-120b-ITG`. Cette preference doit etre confirmee par un test de precision, rappel, dates et citations dans votre environnement.

### Vector store : Qdrant embedded local

Le code utilise :

```python
QdrantClient(path="data/index/qdrant")
```

Il n'y a donc ni Qdrant Cloud, ni serveur Qdrant, ni cle API Qdrant. Tout est persiste dans le dossier du projet. Si `qdrant-client` n'est pas disponible, le projet peut utiliser `embeddings.npy` et NumPy.

### Retrieval : hybride local

Le retrieval combine :

- recherche dense pour les formulations semantiques ;
- BM25 local pour les termes exacts tels que `UTP`, `NPE`, `FBE`, `PD=100%`, `DSCR`, `WL` ;
- Reciprocal Rank Fusion pour combiner les classements.

## 3. Installation

Python 3.11 ou 3.12 est recommande.

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt --index-url https://VOTRE-MIROIR-PYPI-INTERNE/simple
Copy-Item .env.example .env
```

### Linux

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt --index-url https://VOTRE-MIROIR-PYPI-INTERNE/simple
cp .env.example .env
```

Les modeles Docling/TableFormer/EasyOCR doivent etre disponibles localement. Pour un environnement sans Internet, l'equipe plateforme peut les precharger dans un dossier et vous donner ce chemin dans `DOCLING_ARTIFACTS_PATH`.

## 4. Organisation des documents

Un sous-dossier = une contrepartie :

```text
data/input/
├── ENTREPRISE_A/
│   ├── local_minutes_2024.pdf
│   ├── credit_decision_2025.docx
│   └── financials_2024.xlsx
└── ENTREPRISE_B/
    ├── provisioning_note.pdf
    └── covenants.xlsx
```

Un fichier place directement dans `data/input/` recevra `DEFAULT_COUNTERPARTY`.

## 5. Configuration `.env`

Minimum a demander a l'equipe plateforme :

```env
EMBEDDING_BASE_URL=https://gateway-interne.exemple/v1
EMBEDDING_ENDPOINT_PATH=/embeddings
EMBEDDING_API_KEY=SECRET_INTERNE
EMBEDDING_AUTH_MODE=bearer
EMBEDDING_MODEL=bge-m3-ITG

LLM_BASE_URL=https://gateway-interne.exemple/v1
LLM_ENDPOINT_PATH=/chat/completions
LLM_API_KEY=SECRET_INTERNE
LLM_AUTH_MODE=bearer
LLM_MODEL=mistral-medium-2508-ITG
```

La cle est celle de la passerelle **interne de l'entreprise**, pas une cle d'un service public. Si l'endpoint local n'utilise pas de cle :

```env
EMBEDDING_AUTH_MODE=none
LLM_AUTH_MODE=none
```

Pour un certificat interne :

```env
TLS_VERIFY=true
CA_BUNDLE_PATH=C:\certificats\ca-entreprise.pem
```

Ne commitez jamais `.env`.

## 6. Execution fichier par fichier

Toujours depuis la racine du projet :

```powershell
python scripts/00_check_environment.py
python scripts/01_prepare_documents.py
python scripts/02_extract_with_docling.py
python scripts/03_chunk_documents.py
python scripts/04_build_local_vector_db.py
python scripts/05_test_retrieval.py
python scripts/06_extract_ews_events.py
python scripts/07_generate_pdf_reports.py
```

Il n'y a volontairement aucune commande `ews-rag ...`.

Avant l'etape 06, verifiez manuellement :

1. les `.md` et `.html` de `data/extracted/` ;
2. les chunks dans `data/chunks/chunks.jsonl` ;
3. le Top 5/10 obtenu dans `05_test_retrieval.py`.

## 7. Sorties

Pour chaque contrepartie :

```text
data/outputs/entreprise-a/
├── entreprise-a_ews_events.json
├── entreprise-a_ews_events.csv
├── entreprise-a_ews_report.pdf
└── audit/
    ├── retrieved_chunks.json
    ├── llm_batches.json
    ├── rejected_events.json
    └── validated_events_before_dedup.json
```

### Le retour final principal

Le fichier principal pour un lecteur humain est :

```text
<contrepartie>_ews_report.pdf
```

Il contient :

- synthese des candidats EWS ;
- timeline ;
- evenements regroupes par categorie ;
- severite et statut temporel ;
- citations, fichiers et pages ;
- rating et statuts officiels dans une section separee ;
- methode et limites.

Le JSON est la source structuree pour la suite du projet. Le CSV sert aux controles et analyses dans Excel.

## 8. Categories finales

- `events`
- `governance_geopolitical_eis`
- `financials`
- `esg`
- `covenant_fbe`
- `corporate_leverage`
- `internal_rating`
- `utp`
- `grey_list`
- `watchlist`
- `npe`
- `pd_100`
- `new_potential_risk_driver`

UTP, Grey list, Watchlist, NPE et PD=100% sont conserves comme **marqueurs officiels**, toujours non candidats EWS. Le rating est conserve sur une trajectoire parallele.

## 9. Securite

Le projet force Docling a ne pas utiliser de service distant. Les fichiers, representations Docling, chunks, index Qdrant/NumPy, audits et rapports restent dans le projet.

La seule transmission potentielle est vers les URL configurees pour les modeles d'embeddings et le LLM. Elles doivent pointer exclusivement vers une passerelle interne approuvee.

## 10. Limites a mesurer

- extraction incorrecte d'un tableau ;
- passage non retrouve par le RAG ;
- mauvaise interpretation par le LLM ;
- citation presente mais evenement non materiel pour le credit ;
- valeurs Excel mises en cache et non recalculees ;
- dates absentes des sources.

Le rapport est un outil d'aide a l'analyse et doit rester valide par un analyste.

# Configuration de la passerelle interne

## Informations a demander a l'equipe plateforme

Pour les embeddings :

1. Base URL interne ;
2. chemin de l'endpoint ;
3. methode d'authentification ;
4. nom exact du modele ;
5. format de requete/reponse ;
6. certificat CA interne si necessaire ;
7. limite de taille par lot et quota.

Pour le LLM : les memes informations, plus la prise en charge eventuelle de `response_format={"type":"json_object"}`.

Le client fourni suppose une API **compatible OpenAI** :

```json
POST /embeddings
{
  "model": "bge-m3-ITG",
  "input": ["texte 1", "texte 2"]
}
```

et :

```json
POST /chat/completions
{
  "model": "mistral-medium-2508-ITG",
  "messages": [
    {"role": "system", "content": "..."},
    {"role": "user", "content": "..."}
  ]
}
```

Si la passerelle de l'entreprise utilise un autre schema, le seul fichier a adapter est principalement `src/pfe_ews/enterprise_api.py`.

## Exemples d'authentification

### Bearer

```env
EMBEDDING_AUTH_MODE=bearer
EMBEDDING_API_KEY=secret
LLM_AUTH_MODE=bearer
LLM_API_KEY=secret
```

### X-API-Key

```env
EMBEDDING_AUTH_MODE=x-api-key
EMBEDDING_API_KEY=secret
LLM_AUTH_MODE=x-api-key
LLM_API_KEY=secret
```

### En-tete interne personnalise

```env
EMBEDDING_AUTH_MODE=custom
EMBEDDING_API_KEY_HEADER=X-Internal-Token
EMBEDDING_API_KEY=secret
```

### Aucun secret, endpoint local

```env
EMBEDDING_AUTH_MODE=none
LLM_AUTH_MODE=none
```

## En-tetes additionnels

```env
ENTERPRISE_EXTRA_HEADERS_JSON={"X-Project":"PFE-EWS","X-Environment":"DEV"}
```

## Corps additionnel

Certaines passerelles demandent des champs supplementaires :

```env
EMBEDDING_EXTRA_BODY_JSON={"encoding_format":"float"}
LLM_EXTRA_BODY_JSON={"top_p":1.0}
```

## Certificat interne

```env
TLS_VERIFY=true
CA_BUNDLE_PATH=C:\certificats\ca-banque.pem
```

Ne mettez `TLS_VERIFY=false` que dans un test local explicitement autorise.

## Modeles Docling en environnement air-gapped

L'equipe plateforme peut precharger les poids Docling/TableFormer/EasyOCR dans un dossier partage. Renseignez ensuite :

```env
DOCLING_ARTIFACTS_PATH=D:\modeles\docling
```

Le code fixe `enable_remote_services=False` : Docling n'envoie pas le contenu vers un service distant.

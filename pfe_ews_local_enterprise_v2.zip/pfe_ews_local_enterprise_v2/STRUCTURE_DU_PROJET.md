# Role de chaque fichier Python

## Scripts a executer

- `scripts/00_check_environment.py` : controle les dependances, chemins, endpoints et secrets sans les afficher.
- `scripts/01_prepare_documents.py` : decouvre tous les documents, convertit Word en PDF et les anciens XLS en XLSX.
- `scripts/02_extract_with_docling.py` : extrait PDF/Word fallback/Excel/CSV vers Docling JSON, Markdown et HTML.
- `scripts/03_chunk_documents.py` : charge les JSON Docling et cree les chunks RAG.
- `scripts/04_build_local_vector_db.py` : appelle le modele d'embeddings interne et construit Qdrant local/NumPy.
- `scripts/05_test_retrieval.py` : permet de verifier manuellement le Top-K avant le LLM.
- `scripts/06_extract_ews_events.py` : retrieval multi-categories, LLM, validation et export JSON/CSV.
- `scripts/07_generate_pdf_reports.py` : transforme les JSON valides en rapports PDF.

## Modules internes

- `config.py` : lit `.env`, resout les chemins et valide les options.
- `io_utils.py` : JSON/JSONL, identifiants stables, hash, normalisation.
- `logging_utils.py` : logs terminal + fichiers.
- `document_prep.py` : preparation et conversion locale des formats.
- `excel_audit.py` : inventaire des feuilles, cellules fusionnees et formules Excel.
- `docling_extractor.py` : configuration Docling/TableFormer/OCR et exports.
- `chunking.py` : HybridChunker, tokenizer local et metadonnees de provenance.
- `embedding_profiles.py` : prefixes/instructions selon BGE, Qwen ou E5.
- `enterprise_api.py` : appels HTTPS aux endpoints internes d'embeddings et LLM.
- `vector_store.py` : Qdrant embedded local, fallback NumPy et recherche dense.
- `lexical_bm25.py` : recherche lexicale locale sans service externe.
- `queries.py` : requetes metier par famille de risque.
- `retrieval.py` : fusion dense/BM25 avec RRF.
- `schemas.py` : schema Pydantic strict des evenements.
- `prompts.py` : construction des prompts a partir des chunks.
- `event_validation.py` : controle des citations, regles metier et deduplication.
- `event_extraction.py` : orchestration retrieval -> LLM -> validation.
- `exporters.py` : exports JSON et CSV.
- `pdf_report.py` : rapport PDF professionnel groupe par categorie.

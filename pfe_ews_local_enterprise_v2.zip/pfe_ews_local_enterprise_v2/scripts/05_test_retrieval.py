from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from pfe_ews.config import Settings  # noqa: E402
from pfe_ews.logging_utils import configure_logging  # noqa: E402
from pfe_ews.retrieval import HybridRetriever  # noqa: E402

# Modifiez ces deux valeurs pour votre test.
COUNTERPARTY: str | None = None
QUERY = (
    "degradation de l'EBITDA, pression de liquidite, covenant breach, FBE, "
    "hausse de la dette et risque de refinancement"
)


def main() -> None:
    settings = Settings.from_env()
    configure_logging(settings.logs_dir, "05_test_retrieval")
    retriever = HybridRetriever(settings)
    try:
        counterparty = COUNTERPARTY or settings.target_counterparty
        if not counterparty:
            if not retriever.counterparties:
                raise ValueError("Aucune contrepartie indexee.")
            counterparty = retriever.counterparties[0]
        hits = retriever.search(QUERY, counterparty=counterparty)
        compact = [
            {
                "rank": rank,
                "rrf_score": round(float(hit["rrf_score"]), 8),
                "dense_rank": hit.get("dense_rank"),
                "lexical_rank": hit.get("lexical_rank"),
                "chunk_id": hit["chunk_id"],
                "source_file": hit["source_file"],
                "pages": hit.get("page_numbers", []),
                "headings": hit.get("headings", []),
                "is_table": hit.get("is_table"),
                "text_preview": str(hit["text"])[:1000],
            }
            for rank, hit in enumerate(hits, start=1)
        ]
        print(json.dumps({"counterparty": counterparty, "query": QUERY, "hits": compact}, ensure_ascii=False, indent=2))
        print("\nControle attendu: les passages connus doivent apparaitre dans le Top 5/10.")
    finally:
        retriever.close()


if __name__ == "__main__":
    main()

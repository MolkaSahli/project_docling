from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from pfe_ews.config import Settings  # noqa: E402
from pfe_ews.logging_utils import configure_logging  # noqa: E402
from pfe_ews.vector_store import build_local_vector_index  # noqa: E402


def main() -> None:
    settings = Settings.from_env()
    configure_logging(settings.logs_dir, "04_build_local_vector_db")
    metadata = build_local_vector_index(settings)
    print(json.dumps(metadata, ensure_ascii=False, indent=2))
    print("\nAucune base vectorielle externe n'est utilisee.")
    print("Les vecteurs sont stockes dans data/index/qdrant/ ou embeddings.npy.")


if __name__ == "__main__":
    main()

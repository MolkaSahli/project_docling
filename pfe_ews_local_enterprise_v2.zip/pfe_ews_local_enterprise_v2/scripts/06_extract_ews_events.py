from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from pfe_ews.config import Settings  # noqa: E402
from pfe_ews.event_extraction import extract_all_counterparties  # noqa: E402
from pfe_ews.logging_utils import configure_logging  # noqa: E402


def main() -> None:
    settings = Settings.from_env()
    configure_logging(settings.logs_dir, "06_extract_ews_events")
    outputs = extract_all_counterparties(settings)
    summary = [
        {
            "counterparty": result.counterparty,
            "events": len(result.events),
            "candidats_ews": sum(event.is_ews_candidate for event in result.events),
            "statuts_officiels": sum(event.is_official_status_marker for event in result.events),
            "rejetes_sans_preuve": result.rejected_event_count,
            "json": str(json_path),
            "csv": str(csv_path),
        }
        for result, json_path, csv_path in outputs
    ]
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

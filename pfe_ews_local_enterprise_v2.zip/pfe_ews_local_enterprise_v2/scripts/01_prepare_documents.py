from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from pfe_ews.config import Settings  # noqa: E402
from pfe_ews.document_prep import prepare_documents  # noqa: E402
from pfe_ews.logging_utils import configure_logging  # noqa: E402


def main() -> None:
    settings = Settings.from_env()
    configure_logging(settings.logs_dir, "01_prepare_documents")
    rows = prepare_documents(settings)
    summary = {
        "documents_detectes": len(rows),
        "succes": sum(row["status"] == "success" for row in rows),
        "erreurs": sum(row["status"] == "error" for row in rows),
        "manifest": str(settings.prepared_dir / "prepared_manifest.jsonl"),
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

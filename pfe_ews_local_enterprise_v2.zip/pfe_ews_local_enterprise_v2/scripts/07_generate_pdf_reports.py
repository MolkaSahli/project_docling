from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from pfe_ews.config import Settings  # noqa: E402
from pfe_ews.io_utils import read_json  # noqa: E402
from pfe_ews.logging_utils import configure_logging  # noqa: E402
from pfe_ews.pdf_report import generate_pdf_report  # noqa: E402
from pfe_ews.schemas import CounterpartyResult  # noqa: E402


def main() -> None:
    settings = Settings.from_env()
    configure_logging(settings.logs_dir, "07_generate_pdf_reports")
    json_files = sorted(settings.outputs_dir.rglob("*_ews_events.json"))
    if settings.target_counterparty:
        json_files = [
            path
            for path in json_files
            if read_json(path).get("counterparty") == settings.target_counterparty
        ]
    reports = []
    for json_path in json_files:
        result = CounterpartyResult.model_validate(read_json(json_path))
        pdf_path = generate_pdf_report(settings, result)
        reports.append(
            {
                "counterparty": result.counterparty,
                "pdf": str(pdf_path),
                "events": len(result.events),
            }
        )
    if not reports:
        raise FileNotFoundError(
            "Aucun fichier *_ews_events.json. Executez scripts/06_extract_ews_events.py."
        )
    print(json.dumps(reports, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

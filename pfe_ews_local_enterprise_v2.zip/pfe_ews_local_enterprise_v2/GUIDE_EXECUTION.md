# Guide d'execution detaille

## Etape 0 — verifier l'environnement

```powershell
python scripts/00_check_environment.py
```

Ce script ne traite aucune donnee. Il controle les dependances, LibreOffice, les chemins, les modeles configures, l'existence des URL internes et la presence des fichiers d'entree. Les tests reseau ne sont executes que si `RUN_CONNECTIVITY_TESTS=true`.

## Etape 1 — preparer les fichiers

```powershell
python scripts/01_prepare_documents.py
```

- PDF : copie locale ;
- DOC/DOCX : conversion PDF obligatoire avec LibreOffice par defaut ;
- XLS : conversion XLSX avec LibreOffice ;
- XLSX/XLSM/CSV : copie locale.

Sortie : `data/prepared/prepared_manifest.jsonl`.

## Etape 2 — extraire avec Docling

```powershell
python scripts/02_extract_with_docling.py
```

Pour les PDF, le code active :

- OCR EasyOCR local en francais/anglais ;
- structure de tableaux ;
- TableFormer `ACCURATE` ;
- `do_cell_matching=true` par defaut ;
- services distants Docling desactives.

Chaque document produit :

- `.docling.json` : representation structurelle principale ;
- `.md` : controle lisible ;
- `.html` : controle utile pour les cellules fusionnees ;
- `.excel_audit.json` pour Excel.

## Etape 3 — chunker

```powershell
python scripts/03_chunk_documents.py
```

Le HybridChunker respecte la hierarchie et repete les en-tetes quand un tableau est partage. Les chunks visent 700 tokens. Un tokenizer local exact peut etre fourni par `CHUNK_TOKENIZER_PATH`; sinon un compteur conservateur local est utilise.

Sortie : `data/chunks/chunks.jsonl`.

## Etape 4 — construire l'index local

```powershell
python scripts/04_build_local_vector_db.py
```

Le texte des chunks est envoye uniquement a l'endpoint interne d'embeddings. Le vecteur retourne est normalise et stocke localement.

Par defaut :

```text
Qdrant embedded -> data/index/qdrant/
Copie NumPy      -> data/index/embeddings.npy
```

Aucune cle Qdrant n'est necessaire.

## Etape 5 — tester le retrieval

Editez les deux constantes en haut de `scripts/05_test_retrieval.py` :

```python
COUNTERPARTY = "ENTREPRISE_A"
QUERY = "liquidity pressure covenant FBE refinancing"
```

Puis :

```powershell
python scripts/05_test_retrieval.py
```

Ne passez a l'etape LLM que si les passages connus apparaissent dans le Top 5/10.

## Etape 6 — extraire les evenements

```powershell
python scripts/06_extract_ews_events.py
```

Le code effectue plusieurs recherches par famille de risque, appelle le LLM interne, exige un JSON structure, controle les chunk IDs et les citations, applique les regles metier puis deduplique.

## Etape 7 — produire le rapport PDF

```powershell
python scripts/07_generate_pdf_reports.py
```

Le PDF est genere a partir du JSON valide, sans nouvel appel au LLM.

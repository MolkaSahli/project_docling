Placez ici les documents d'une même contrepartie :
- PDF : .pdf
- Word : .docx ou .doc (converti localement en PDF)
- Excel : .xlsx, .xlsm ou .xls
- CSV : .csv

Pour une autre contrepartie, créez un autre sous-dossier au même niveau.
Le nom du sous-dossier devient l'identifiant de la contrepartie.

# Choix des modeles et de l'architecture

## Embeddings disponibles

### 1. `bge-m3-ITG` — choix par defaut

Utilisation recommandee pour la premiere baseline.

- multilingue ;
- contexte 8K ;
- vecteur attendu 1024 dimensions ;
- adapte aux textes francais/anglais et aux chunks de tableaux ;
- stockage et recherche plus legers que Qwen 8B avec dimension maximale.

### 2. `qwen3-embedding-8b` — benchmark qualite

- multilingue ;
- contexte 32K ;
- instructions de retrieval ;
- jusqu'a 4096 dimensions ;
- potentiellement plus performant, mais plus lourd en calcul, latence, memoire et stockage.

Le projet gere automatiquement une instruction de requete pour ce modele. Pour le tester :

```env
EMBEDDING_MODEL=qwen3-embedding-8b
```

Il faut ensuite reconstruire entierement l'index.

### 3. `multilingual-e5-large-ITG` — baseline alternative

- multilingue ;
- 512 tokens ;
- prefixes `query:` et `passage:` appliques automatiquement.

Avec ce modele, reduisez `CHUNK_MAX_TOKENS` vers 430-480.

### 4. `bge-large-en-v1.5-ITG`

A reserver a un corpus strictement anglais. Il n'est pas le meilleur premier choix si les documents contiennent du francais.

## LLM disponibles

### Par defaut : `mistral-medium-2508-ITG`

Choix de compromis pour l'extraction structuree. Il faut le comparer sur votre jeu de reference avec :

- precision des evenements ;
- recall ;
- exactitude des dates ;
- validite des citations ;
- respect des categories et regles UTP/WL/NPE.

### Mode plus rapide : `mistral-small-2506-ITG` ou `mistral-small-4-ITG`

A tester si la latence est prioritaire. Le contexte plus long de `mistral-small-4-ITG` n'est pas indispensable dans ce pipeline, car le RAG limite volontairement le contexte.

### Mode revue qualite : `gpt-oss-120b-ITG`

A envisager pour un benchmark ou une deuxieme passe de revue si les ressources internes le permettent. Le projet ne l'active pas automatiquement afin de conserver une baseline simple et mesurable.

### `mistral-ocr-*`

Non retenu dans la baseline principale : Docling + OCR local + TableFormer assure deja l'extraction et la structure. Un OCR LLM peut devenir un fallback cible pour des pages particulierement difficiles, mais ne doit pas etre ajoute avant de mesurer les erreurs Docling.

## Pourquoi pas une base externe

Les contraintes bancaires imposent de garder l'index local. Qdrant est utilise en mode embarque :

```python
QdrantClient(path="data/index/qdrant")
```

Le processus Python lit/ecrit directement les fichiers locaux. Aucun compte, serveur ou token Qdrant n'est utilise.

## Pourquoi conserver NumPy

`embeddings.npy` sert :

- de repli si `qdrant-client` n'est pas installe ;
- de copie d'audit ;
- de baseline simple pour comparer les resultats.

## Critere de choix final

Construisez un jeu d'environ 30 a 50 evenements connus avec fichier, page et citation. Comparez :

```text
BGE-M3 + dense
BGE-M3 + dense/BM25
Qwen3-Embedding-8B + dense/BM25
Multilingual-E5-Large + dense/BM25
```

Mesures : Recall@5, Recall@10, MRR, latence et taille de l'index. Le meilleur modele est celui qui retrouve les passages sources de votre corpus, pas seulement celui qui domine un benchmark general.
